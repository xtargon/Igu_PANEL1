<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Local;
use App\Models\Transaction;


class Machine extends Model
{
    use HasFactory;

    protected $fillable = ['id', 'tkn_jackpots', 'jackpots', 'owner', 'local', 'transactions', 'filters', 'state', 'nombre', 'juego', 'p_p', 'parcial_in', 'parcial_out', 'total_in', 'total_out', 'balance', 'ac1', 'ac2', 'ac3', 'acumulated1', 'acumulated2', 'acumulated3', 'acumulated1_2', 'acumulated1_3', 'acumulated1_4', 'acumulated1_5', 'acumulated2_2', 'acumulated2_3', 'acumulated2_4', 'acumulated2_5', 'acumulated3_2', 'acumulated3_3', 'acumulated3_4', 'acumulated3_5', 'door_acumulated', 'ia_balance'];


    protected $casts = [
        'jackpots' => 'boolean', 
    ];

    /**
     * Relación con el usuario propietario.
     */
     
    public function local()
    {
        return $this->belongsTo(Local::class, 'local');
    }
     
    public function transacciones()
    {
        return $this->hasMany(Transaction::class, 'machine_id', 'id');
    }


     
    public function user()
    {
        return $this->belongsTo(User::class, 'owner', 'name');  // Suponiendo que 'name' es el campo del usuario
    }
}




