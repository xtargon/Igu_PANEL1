                        @foreach ($machines as $machine)
                            <tr data-machine-id="{{ $machine->id }}" class="transition">
                                
                                <td class="px-3 py-2  text-sm text-gray-700">{{ $machine->nombre }}</td>
                                <td class="px-3 py-2  text-sm text-gray-700">
                                    @if ($machine->state == '1')
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Activo</span>
                                    @else
                                        @if($machine->state == '0')
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Inactivo</span>
                                        @else
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Reset</span>
                                        @endif
                                            
                                    @endif
                                </td>
                                <td class="px-3 py-2  text-sm text-gray-700">{{ $machine->juego }}</td>
                                <td class="px-3 py-2  text-sm text-gray-700">{{ $machine->filters }}</td>
                                <td class="px-3 py-2  text-sm text-gray-700">{{ $machine->balance }}</td>
                             @if($empresa->ia_picture === 'on')
                                  <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                                    <button 
                                        class="openModalBtnss bg-blue-500 text-white px-3 py-1 rounded-md"
                                        data-machine-filter="{{ $machine->filters }}"
                                        data-machine-p_p="{{ $machine->p_p }}"
                                        data-machine-local="{{ $machine->local }}"
                                        data-machine-owner="{{ $machine->owner }}"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                          <path stroke-linecap="round" stroke-linejoin="round" d="m9 14.25 6-6m4.5-3.493V21.75l-3.75-1.5-3.75 1.5-3.75-1.5-3.75 1.5V4.757c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0 1 11.186 0c1.1.128 1.907 1.077 1.907 2.185ZM9.75 9h.008v.008H9.75V9Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm4.125 4.5h.008v.008h-.008V13.5Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
                                        </svg>
            
            
                                    </button>
                                  </td>
                             @else
                                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                                        <center>
                                           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                              <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
                                           </svg>
                                        </center>
                                    </td>
                             @endif                  
                              
                              <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                                  <!-- Botones de acciones -->
                                  <label class="switch" style="margin-top: 10px; float: left; margin-right: 15px;">
                                      <input type="checkbox" name="state" class="state" data-machine-local="{{ $machine->local }}" data-machine-id="{{ $machine->id }}" {{ $machine->state == 1 ? 'checked' : '' }}>
                                      <span class="slider round"></span>
                                  </label>
                                  <button class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn" data-machine-ai="{{ $machine->ia_balance }}" data-machine-p_p="{{ $machine->p_p }}" data-machine-ac1="{{ $machine->ac1 }}" data-machine-ac2="{{ $machine->ac2 }}" data-machine-ac3="{{ $machine->ac3 }}" data-machine-acumulated1="{{ $machine->acumulated1 }}" data-machine-acumulated1_2="{{ $machine->acumulated1_2 }}" data-machine-acumulated1_3="{{ $machine->acumulated1_3 }}" data-machine-acumulated2="{{ $machine->acumulated2 }}" data-machine-acumulated2_2="{{ $machine->acumulated2_2 }}" data-machine-acumulated2_3="{{ $machine->acumulated2_3 }}" data-machine-acumulated3="{{ $machine->acumulated3 }}" data-machine-acumulated3_2="{{ $machine->acumulated3_2 }}" data-machine-acumulated3_3="{{ $machine->acumulated3_3 }}" data-machine-acumulated1_4="{{ $machine->acumulated1_4 }}" data-machine-acumulated1_5="{{ $machine->acumulated1_5 }}" data-machine-acumulated2_4="{{ $machine->acumulated2_4 }}" data-machine-acumulated2_5="{{ $machine->acumulated2_5 }}" data-machine-acumulated3_4="{{ $machine->acumulated3_4 }}" data-machine-acumulated3_5="{{ $machine->acumulated3_5 }}" data-machine-filters="{{ $machine->filters }}" data-machine-balance="{{ $machine->balance }}" data-machine-total_out="{{ $machine->total_out }}" data-machine-total_in="{{ $machine->total_in }}" data-machine-parcial_out="{{ $machine->parcial_out }}" data-machine-parcial_in="{{ $machine->parcial_in }}" data-machine-local="{{ $machine->local }}" data-machine-state="{{ $machine->state }}" data-machine-name="{{ $machine->nombre }}" data-machine-id="{{ $machine->id }}" style="margin-top:3px;">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                                  <path stroke-linecap="round" stroke-linejoin="round" d="M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93.398.164.855.142 1.205-.108l.737-.527a1.125 1.125 0 0 1 1.45.12l.773.774c.39.389.44 1.002.12 1.45l-.527.737c-.25.35-.272.806-.107 1.204.165.397.505.71.93.78l.893.15c.543.09.94.559.94 1.109v1.094c0 .55-.397 1.02-.94 1.11l-.894.149c-.424.07-.764.383-.929.78-.165.398-.143.854.107 1.204l.527.738c.32.447.269 1.06-.12 1.45l-.774.773a1.125 1.125 0 0 1-1.449.12l-.738-.527c-.35-.25-.806-.272-1.203-.107-.398.165-.71.505-.781.929l-.149.894c-.09.542-.56.94-1.11.94h-1.094c-.55 0-1.019-.398-1.11-.94l-.148-.894c-.071-.424-.384-.764-.781-.93-.398-.164-.854-.142-1.204.108l-.738.527c-.447.32-1.06.269-1.45-.12l-.773-.774a1.125 1.125 0 0 1-.12-1.45l.527-.737c.25-.35.272-.806.108-1.204-.165-.397-.506-.71-.93-.78l-.894-.15c-.542-.09-.94-.56-.94-1.109v-1.094c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.765-.383.93-.78.165-.398.143-.854-.108-1.204l-.526-.738a1.125 1.125 0 0 1 .12-1.45l.773-.773a1.125 1.125 0 0 1 1.45-.12l.737.527c.35.25.807.272 1.204.107.397-.165.71-.505.78-.929l.15-.894Z" />
                                                  <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                                </svg>
                                  </button>
                                  <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-machine-id="{{ $machine->id }}" style="margin-top:3px;">
                                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                          <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                      </svg>
                                  </button>
                                  <button class="bg-green-500 text-white px-3 py-1 rounded-md view-transactions-btn" data-local-id="{{ $machine->local }}" style="margin-top:3px;">
                                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                          <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" />
                                      </svg>
                                  </button>
                              </td>
                            </tr>
                        @endforeach
                        
<script>
    function assignActionListeners() {
        
        $('.state').off('change').on('change', function () {
            let newState = $(this).is(':checked') ? 1 : 0;
            let machineId = $(this).data('machine-id');
            let localMachine = $(this).data('machine-local');

            $.ajaxSetup({
              headers: {
                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
            });
            
            $.ajax({
                url: `/machines/state/${machineId}`,
                type: 'PUT',
                data: { 
                  state: newState,
                  id: machineId 
                },
                success: function(response) {
                    console.log("Actualizado exitosamente");
                        refreshMachinesForLocal(localMachine);
                },
                error: function(xhr, status, error) {
                    console.error("Error al actualizar: " + error);
                    // Aquí puedes manejar los errores, mostrar notificaciones, etc.
                }
            });
        });        
        
        $('.edit-btn').off('click').on('click', function (e) {
            
            const machineId = $(this).data('machine-id');
            const name = $(this).data('machine-name');
            const total_in = $(this).data('machine-total_in');
            const total_out = $(this).data('machine-total_out');
            const balance = $(this).data('machine-balance');
            const filters = $(this).data('machine-filters');
            const LocalX = $(this).data('machine-local');
            const ac1 = $(this).data('machine-ac1');
            const ac2 = $(this).data('machine-ac2');
            const ac3 = $(this).data('machine-ac3');
            const acumulated1 = $(this).data('machine-acumulated1');
            const acumulated1_2 = $(this).data('machine-acumulated1_2');
            const acumulated1_3 = $(this).data('machine-acumulated1_3');
            const acumulated1_4 = $(this).data('machine-acumulated1_4');
            const acumulated1_5 = $(this).data('machine-acumulated1_5');
            const acumulated2 = $(this).data('machine-acumulated2');
            const acumulated2_2 = $(this).data('machine-acumulated2_2');
            const acumulated2_3 = $(this).data('machine-acumulated2_3');
            const acumulated2_4 = $(this).data('machine-acumulated2_4');
            const acumulated2_5 = $(this).data('machine-acumulated2_5');
            const acumulated3 = $(this).data('machine-acumulated3');
            const acumulated3_2 = $(this).data('machine-acumulated3_2');
            const acumulated3_3 = $(this).data('machine-acumulated3_3');       
            const acumulated3_4 = $(this).data('machine-acumulated3_4');
            const acumulated3_5 = $(this).data('machine-acumulated3_5'); 
            const p_p = $(this).data('machine-p_p');
            const IA = $(this).data('machine-ai');
            
            $("#btn-reset").off('click').on('click', function(){
                e.preventDefault();
                $.ajaxSetup({
                  headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
                });
                
                $.ajax({
                    url: `/reset/${machineId}`,
                    method: 'POST',
                    data: {caracter: 0},
                    success: function (res) {
                    },
                    error: function (xhr) {
                        alert('ocurrio un error en el reset')
                    }
                });                
            })


            $('#editModal').removeClass('hidden');
            $('#name').val(name);
            $('#editMachineId').val(machineId);
            $('#t_in').val(total_in);
            $('#t_out').val(total_out);
            $('#balance').val(balance);
            $('#filters').val(filters);
            $('#filtersMachineByPicture').val(filters);
            $('#ac1').val(ac1);
            $('#ac2').val(ac2);
            $('#ac3').val(ac3);
            
            $('#acumulated1').val(acumulated1);
            $('#acumulated1_2').val(acumulated1_2);
            $('#acumulated1_3').val(acumulated1_3);
            $('#acumulated1_4').val(acumulated1_4);
            $('#acumulated1_5').val(acumulated1_5);
            $('#acumulated2').val(acumulated2);
            $('#acumulated2_2').val(acumulated2_2);
            $('#acumulated2_3').val(acumulated2_3);
            $('#acumulated2_4').val(acumulated2_4);
            $('#acumulated2_5').val(acumulated2_5);
            $('#acumulated3').val(acumulated3);
            $('#acumulated3_2').val(acumulated3_2);
            $('#acumulated3_3').val(acumulated3_3);
            $('#acumulated3_4').val(acumulated3_4);
            $('#acumulated3_5').val(acumulated3_5);
            $('#p_p').val(p_p);

            let editLocal = $("#localAdd2");
            
            $.get('/locals_getting', function (data) {
                editLocal.empty(); 
                let LocalNot = `<option value="" style="color:red;">SIN LOCAL</option>`;
                editLocal.append(LocalNot);
                data.forEach(loc => {
                    let rowLocal = `<option value="${loc.id}">${loc.nombre}</option>`;
                    editLocal.append(rowLocal);
                });
                 $("#localAdd2").val(LocalX);
            });

            $('#editMachineForm').on('submit', function (e) {
                e.preventDefault();
                const machineId = $('#editMachineId').val();
            
                let formData = $(this).serializeArray().reduce((obj, item) => {
                    obj[item.name] = item.value;
                    return obj;
                }, {});
            
                console.log(formData);
            
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            
                $.ajax({
                    url: `/machines/${machineId}`,
                    method: 'PUT',
                    data: formData,
                    success: function (res) {
                        console.log('edicion exitosa');
                        $('#editModal').addClass('hidden');
                        var btnHtmlPicture = '<center><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" /></svg></center>';
                        
                        if(empresaIA.ia_picture === "on"){
                            btnHtmlPicture = `<button class="openModalBtnss bg-blue-500 text-white px-3 py-1 rounded-md" data-machine-filter="${res.machine.filters}" data-machine-p_p="${res.machine.p_p}" data-machine-local="${res.machine.local}" data-machine-owner="${res.machine.owner}"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z" /></svg></button>`;
                        }
                        
                        
                        var currentState = $(`tr[data-machine-id="${machineId}"] input[name="state"]`).prop('checked');
                        refreshMachinesForLocal(LocalX);
                        assignPictureAction();
                        assignActionListeners();
                        loadNames();
                    },
                    error: function (xhr) {
                    }
                });
            });

        });

        $('.delete-btn').off('click').on('click', function () {
            const machineId = $(this).data('machine-id');
            $('#deleteModal').removeClass('hidden');
            $('#deleteUserId').val(machineId);

            $('#deleteUserForm').on('submit', function (e) {
                e.preventDefault();
                const machineId = $('#deleteUserId').val();

                $.ajax({
                    url: `/machines/${machineId}`,
                    method: 'DELETE',
                    data: $(this).serialize(),
                    success: function (response) {
                        $('#deleteModal').addClass('hidden');
                        $(`tr[data-machine-id="${machineId}"]`).remove();

                    },
                    error: function (xhr) {
                    }
                });
            });
        });

        $('.view-transactions-btn').off('click').on('click', function () {
            var localId = $(this).data('local-id');
            var URLs = `/machines/local/${localId}/`;

            $('#viewTransactionsModal').removeClass('hidden');

            function loadTransactions(M){
            console.log(M[0].id)
            var URLsM = `/transactions/${M[0].id}/`;

            $.ajax({
                url: URLsM,
                method: 'GET',
                success: function (res) {
                    if (res.transaction && res.transaction.length > 0) {
                        $('#transactionsList').html('');

                        let table = `
                            <table class="min-w-full bg-white">
                                <thead>
                                    <tr>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">ID</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">IN Parcial</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">OUT Parcial</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                        `;

                        res.transaction.forEach(function (transaction) {
                            table += `
                                <tr>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.id}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_in}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_out}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.fecha}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">
                                        <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-transaction-btn" data-transaction-id="${transaction.id}">Eliminar</button>
                                    </td>
                                </tr>
                            `;
                        });

                        table += `
                                </tbody>
                            </table>
                        `;

                        $('#transactionsList').html(table);

                        $('.delete-transaction-btn').on('click', function () {
                            const transactionId = $(this).data('transaction-id');
                            $('#deleteTransactionModal').removeClass('hidden');
                            $('#deleteTransactionId').val(transactionId); 
                        });
                    } else {
                        $('#transactionsList').html('<p class="text-gray-600">No hay transacciones para este usuario.</p>');
                    }
                },
                error: function (xhr) {
                    alert('Error al cargar las maquinas.');
                }
            });

                $('#deleteTransactionForm').on('submit', function (e) {
                e.preventDefault();
                    const transactionId = $('#deleteTransactionId').val();

                    $.ajax({
                        url: `/transactions/${transactionId}`,
                        method: 'DELETE',
                        data: $(this).serialize(),
                        success: function (response) {
                            alert('Transacci贸n eliminada correctamente.');
                            $('#deleteTransactionModal').addClass('hidden');
                        },
                        error: function (xhr) {
                            alert('Error al eliminar la transacci贸n.');
                        }
                    });
                });


            }

            $.ajax({
                url: URLs,
                method: 'GET',
                success: function (res) {
                    $('#transactionsList').html(res);
                    loadTransactions(res);
                },
                error: function (xhr) {
                    alert('Error al cargar las maquinas.');
                }
            });
        });
    }
    assignActionListeners();
    assignPictureAction();
</script>