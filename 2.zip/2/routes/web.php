<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\KingAdminController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\GameController;
use App\Http\Controllers\LocalController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\LogController;
use App\Http\Controllers\EmpresasController;
use App\Http\Controllers\MachineController;
use App\Http\Controllers\Api\APIController;
use App\Http\Controllers\payController;
use App\Http\Controllers\planController;
use App\Http\Controllers\StripeController;

use App\Models\User;
use App\Models\Machine;

use App\Middleware\CheckMembership;
use App\Http\Controllers\JackpotController;

Route::post('/jack_pots', [JackpotController::class, 'toggle'])->name('jackpots.toggle');
Route::get('/jack_pots/status_all', [JackpotController::class, 'statusAll'])->name('jackpots.status_all');

Route::get('/chart-data', [TransactionController::class, 'getChartData'])->name('chart.data');

Route::post('/post', [APIController::class, 'store']);
Route::middleware(['auth'])->group(function () {
    Route::get('/admin', [KingAdminController::class, 'index'])->name('admin.dashboard');
    Route::post('/clients', [KingAdminController::class, 'createUser']);
    Route::get('/admin/users', [KingAdminController::class, 'getUsers']);
    Route::post('/admin/clients/{id}', [KingAdminController::class, 'updateUser']);
    Route::post('/admin/update-coins', [KingAdminController::class, 'updateCoins'])->middleware('auth');

    Route::delete('/clients/{id}', [KingAdminController::class, 'destroy']);
    Route::get('/admin/transfers', [KingAdminController::class, 'getTransfers']);
    Route::get('/admin/movements', [KingAdminController::class, 'getMovements']);
    Route::get('/admin/machines', [KingAdminController::class, 'getMachines']);
    Route::get('/admin/locals', [KingAdminController::class, 'getLocals']);
    Route::get('/admin/games', [KingAdminController::class, 'getGames']);
    Route::get('/admin/logs', [KingAdminController::class, 'getLogs']);
    Route::get('/admin/me', [KingAdminController::class, 'getMe']);
});

Route::resource('users', UserController::class);
Route::get('/users', [UserController::class, 'index'])->middleware('auth')->name('users');
Route::middleware(['auth'])->group(function () {
    Route::get('/users', [UserController::class, 'index'])->name('users')->middleware(['auth', 'check.membership']);
    Route::get('/me', [UserController::class, 'index_me'])->name('users_me');
    Route::get('/gettin_user', [UserController::class, 'getting']);
    Route::get('/gettingUpdate/{id}', [UserController::class, 'gettingUpdate']);
    Route::post('/users', [UserController::class, 'store']);
    Route::put('/users/{id}', [UserController::class, 'update']);
    Route::post('/users/update_me', [UserController::class, 'update_me']);
    Route::delete('/users/{id}', [UserController::class, 'destroy'])->name('users.destroy');
    Route::post('/users/find', [UserController::class, 'find']);
    Route::get('/find_me', [UserController::class, 'show']);

    Route::get('/users/search', [UserController::class, 'search']);
});


Route::resource('locals', LocalController::class);
Route::get('/locals', [LocalController::class, 'index'])->middleware('auth')->name('locals')->middleware(['auth', 'check.membership']);
Route::middleware(['auth'])->group(function () {
    Route::get('/locals/{local}/machines-table', [LocalController::class, 'machinesTable'])
         ->name('locals.machinesTable');
    Route::get('/locals', [LocalController::class, 'index'])->name('locals')->middleware(['auth', 'check.membership']);
    Route::get('/locals_getting', [LocalController::class, 'getting']);
    Route::get('/location', [LocalController::class, 'localtion'])->middleware(['auth', 'check.membership']);
    Route::post('/locals', [LocalController::class, 'store']);
    Route::put('/locals/{id}', [LocalController::class, 'update']);
    Route::delete('/locals/{id}', [LocalController::class, 'destroy']);
    Route::post('/locals/find', [LocalController::class, 'find']);
    Route::get('/localsName/{id}', [LocalController::class, 'getName']);
    Route::get('/traking', [LocalController::class, 'localtionTracking'])->middleware(['auth', 'check.membership']);
    Route::get('/cars', [LocalController::class, 'cars'])->middleware(['auth', 'check.membership']);
    Route::post('/cars', [LocalController::class, 'carsCreate']);
    Route::delete('/car/{id}', [LocalController::class, 'carsDelete']);

});

Route::resource('payment', payController::class);
Route::get('/payment', [payController::class, 'index'])->name('payment');
Route::get('/payment/checkout', [payController::class, 'show']);
Route::post('/paypal/success', [payController::class, 'paypalSuccess'])->name('paypal.success');
Route::post('/payment/success', [payController::class, 'paymentSuccess'])->name('payment.success');


Route::resource('transactions', TransactionController::class);
Route::get('/transactions', [TransactionController::class, 'index'])->middleware('auth')->name('transactions')->middleware(['auth', 'check.membership']);
Route::middleware(['auth'])->group(function () {
    Route::get('/transactions/{id}', [TransactionController::class, 'show']);
    Route::get('/transactions/l/{id}', [TransactionController::class, 'showLocal']);
    Route::post('/transactions', [TransactionController::class, 'store']);
    Route::get('/buss/reload', [TransactionController::class, 'loadAjax']);
    Route::get('/transactionsDate', [TransactionController::class, 'filterTransactions'])->name('transactions.filter')->middleware(['auth', 'check.membership']);
    Route::delete('/transactions/{id}', [TransactionController::class, 'destroy']);
});

Route::resource('company', EmpresasController::class);
Route::get('/company', [EmpresasController::class, 'index'])->middleware('auth')->name('company')->middleware(['auth', 'check.membership']);
Route::middleware(['auth'])->group(function () {
    Route::get('/company_getting', [EmpresasController::class, 'show']);
    Route::post('/company', [EmpresasController::class, 'store']);
    Route::put('/company/{id}', [EmpresasController::class, 'update']);
    Route::delete('/company/{id}', [EmpresasController::class, 'destroy']);
    Route::get('/companyKing/{id}', [EmpresasController::class, 'findKing']);
});

Route::resource('logs', LogController::class);
Route::get('/logs', [LogController::class, 'index'])->middleware('auth')->name('logs')->middleware(['auth', 'check.membership']);
Route::middleware(['auth'])->group(function () {
    Route::get('/logs', [LogController::class, 'index'])->name('logs')->middleware(['auth', 'check.membership']);
    Route::get('/logs_getting', [LogController::class, 'getting']);
    Route::post('/logs', [LogController::class, 'store']);
    Route::put('/logs/{id}', [LogController::class, 'update']);
    Route::delete('/logs/{id}', [LogController::class, 'destroy']);
    Route::post('/logs/find', [LogController::class, 'find']);
    Route::get('/logs/search', [LogController::class, 'search']);
});

 Route::resource('games', GameController::class);
 Route::get('/games', [GameController::class, 'index'])->middleware('auth')->name('games')->middleware(['auth', 'check.membership']);
 Route::middleware(['auth'])->group(function () {
     Route::get('/games', [GameController::class, 'index'])->name('games')->middleware(['auth', 'check.membership']);
     Route::get('/games_getting', [GameController::class, 'getting']);
     Route::post('/games', [GameController::class, 'store']);
     Route::put('/games/{id}', [GameController::class, 'update']);
     Route::delete('/games/{id}', [GameController::class, 'destroy']);
     Route::post('/games/find', [GameController::class, 'find']);
     Route::get('/games/search', [GameController::class, 'search']);
     Route::get('/gamesName/{id}', [GameController::class, 'getName']);

 });


Route::get('/', [AuthController::class, 'showLogin'])->name('login');
Route::post('/', [AuthController::class, 'login']);    

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard')->middleware(['auth', 'check.membership']);

Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

Route::post('/machines', [MachineController::class, 'store'])->name('machines.store');
Route::get('/machines/{machine}', [MachineController::class, 'edit'])->name('machines.find'); 
Route::middleware('auth')->group(function () {
    Route::get('/machines', [MachineController::class, 'index'])->name('machines')->middleware(['auth', 'check.membership']);
    Route::get('/machine', [MachineController::class, 'find'])->name('machine');
    Route::get('/machines/local/{id}', [MachineController::class, 'show']); 
    Route::post('/reset/{machine}', [MachineController::class, 'reset']); 
    Route::get('/machines/{machine}', [MachineController::class, 'edit']); 
    Route::put('/machines/{machine}', [MachineController::class, 'update']);
    Route::put('/machines/state/{machine}', [MachineController::class, 'updateStatus']);
    Route::delete('/machines/{machine}', [MachineController::class, 'destroy']);
    Route::get('/jackpots', [MachineController::class, 'jackpots'])->middleware(['auth', 'check.membership']);

    
});

Route::middleware(['auth'])->group(function () {

    Route::get('/plans', [planController::class, 'show'])->name('planes.index');
    Route::get('/plans-data', [planController::class, 'fetchData'])->name('planes.fetch');
    Route::get('/plan/{id}', [planController::class, 'find'])->name('planes.find');
    Route::post('/plan', [planController::class, 'store'])->name('planes.store');
    Route::put('/plan/{id}', [planController::class, 'update'])->name('planes.update');
    Route::delete('/plan/{id}', [planController::class, 'destroy'])->name('planes.destroy');    
    Route::get('/api/planes', [planController::class, 'getPlansAjax']);

});










