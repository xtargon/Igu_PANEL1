<div id="map" style="width: 100%; height: 640px;"></div>


<a href="https://play.google.com/store/apps/details?id=com.tuapp" target="_blank"
   class="w-1/5 group relative inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition duration-300" style="margin-top:20px;">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8 ml-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style="margin-right:20px;">
      <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
      <path stroke-linecap="round" stroke-linejoin="round" d="M15.91 11.672a.375.375 0 0 1 0 .656l-5.603 3.113a.375.375 0 0 1-.557-.328V8.887c0-.286.307-.466.557-.327l5.603 3.112Z" />
    </svg>
    Descargar Aplicación
</a>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@v10.4.0/ol.css">
<script src="https://cdn.jsdelivr.net/npm/ol@v10.4.0/dist/ol.js"></script>

<script>
var map;
var vectorSource = new ol.source.Vector({});
var vectorLayer = new ol.layer.Vector({ source: vectorSource });
var markersMap = new Map();
var trackingMarker = null;  

// Función para inicializar el mapa
function initMap(lon, lat) {
  map = new ol.Map({
    target: 'map',
    layers: [
      new ol.layer.Tile({
        source: new ol.source.OSM()
      })
    ],
    view: new ol.View({
      center: ol.proj.fromLonLat([lon, lat]),
      zoom: 14
    })
  });
  
  map.addLayer(vectorLayer);
}

// Función para agregar los marcadores FIJOS de los locales
function addMarker(id, lon, lat, info) {
  var marker = new ol.Feature({
    geometry: new ol.geom.Point(ol.proj.fromLonLat([lon, lat])),
    info: info
  });

  marker.setStyle(new ol.style.Style({
    image: new ol.style.Icon({
      src: 'https://img.icons8.com/?size=100&id=wzm7F3RJXm01&format=png&color=FA5252',
      anchor: [0.5, 1],
      scale: 0.4
    })
  }));

  vectorSource.addFeature(marker);
  markersMap.set(id, marker);
}

// Función para el marcador dinámico (tracking)
function updateTrackingMarker(lon, lat, name, last) {
  let newMarker = new ol.Feature({
    geometry: new ol.geom.Point(ol.proj.fromLonLat([lon, lat])),
  });

    var txt = name+" - "+last;

  newMarker.setStyle(new ol.style.Style({
    image: new ol.style.Icon({
      src: 'https://img.icons8.com/?size=100&id=cvsTum2aBINb&format=png&color=FA5252',
      anchor: [0.5, 1], 
      scale: 0.4      
    }),
    text: new ol.style.Text({
      text: txt, 
      offsetY: 1, 
      font: '12px Arial', 
      fill: new ol.style.Fill({ color: 'rgba(0, 0, 0, 0.6)' }), 
      stroke: new ol.style.Stroke({ color: 'rgba(255, 255, 255, 0.5)', width: 3 }), 
      backgroundFill: new ol.style.Fill({ color: 'rgba(255, 255, 255, 0.5)' }), 
      padding: [4, 6, 4, 6],
      scale: 0.9 
    })
  }));

  vectorSource.addFeature(newMarker);

  // Eliminar el marcador después de 60 segundos
  setTimeout(() => {
    vectorSource.removeFeature(newMarker);
  }, 14500); 
}


/**
 * Función para geocodificar una dirección usando el servicio Nominatim de OpenStreetMap.
 * @param {string} address - Dirección completa (ciudad, avenida, calle, etc.)
 * @param {function} callback - Función a ejecutar con las coordenadas obtenidas
 */
function geocodeAddress(address, callback) {
  var url = "https://nominatim.openstreetmap.org/search?format=json&q=" + encodeURIComponent(address);
  
  fetch(url)
    .then(function(response) {
      return response.json();
    })
    .then(function(data) {
      if (data && data.length > 0) {
        var lon = parseFloat(data[0].lon);
        var lat = parseFloat(data[0].lat);
        callback(lon, lat);
      } else {
        console.error("No se encontraron resultados para: " + address);
      }
    })
    .catch(function(err) {
      console.error(err);
    });
}

// Cargar los locales fijos al inicio
function cargarLocales() {
  $.ajax({
    url: `/locals_getting`,
    method: 'GET',
    success: function(data) {
      console.log("Primera ciudad en la data, para centrar el mapa -> " + data[0]['ciudad']);
      const coordenadas = [];
      
      const promises = data.map(local => {
          console.log(local['lat'] +" --- "+ local['lon'])
        return new Promise((resolve, reject) => {
            console.log("asdasd "+local['lat'])
            if(local['lat'] !== null && local['lon'] !== null){
                var info = `<strong>${local['nombre']}</strong><br>${local['ciudad']}<br>Estado: ${local['estado']}`;
                addMarker(local['id'], local['lon'], local['lat'], info);
                resolve();
            }
            else{
                geocodeAddress(local['ciudad'], function(lon, lat) {
                    var info = `<strong>${local['nombre']}</strong><br>${local['ciudad']}<br>Estado: ${local['estado']}`;
                    
                    coordenadas.push({ lat: lat, lon: lon });
                    addMarker(local['id'], lon, lat, info);
                    resolve();
              });   
            }            
        });
      });
      
      Promise.all(promises)
        .then(() => {
          const centro = calcularCentro(coordenadas);
          console.log("Centro:", centro);
          initMap(centro.lon, centro.lat);
        })
        .catch(err => {
          console.error("Error al geocodificar:", err);
        });
    },
    error: function(err) {
      console.error("Error al cargar los locales:", err);
    }
  });
}

function calcularCentro(coordenadas) {
  let sumaLat = 0;
  let sumaLng = 0;
  let total = coordenadas.length;
  
  coordenadas.forEach(coord => {
    sumaLat += coord.lat;
    sumaLng += coord.lon;
  });
  
  return {
    lat: sumaLat / total,
    lon: sumaLng / total
  };
}

// Función para hacer tracking del objeto en movimiento
function trackObject() {
  $.ajax({
    url: `/traking`,
    method: 'GET',
    success: function(data) {
      data.forEach(function(doc) {
        var lon = doc.lon;
        var lat = doc.lat;
        var name = doc.name;
        
        
        var lastLocation = moment(doc.updated_at).format('DD/MM/YYYY HH:mm:ss');
        
        
        
        console.log(lon+" --> "+lat+" --> "+name)
        updateTrackingMarker(lon, lat, name, lastLocation);
      });
    },
    error: function(err) {
      console.error("Error en el tracking:", err);
    }
  });
}


setInterval(trackObject, 15000);
trackObject();
cargarLocales(); 

</script>