<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Plans;
use Illuminate\Support\Facades\Auth;

class PlanController extends Controller
{
    // Guardar nuevo plan
    public function store(Request $request)
    {

        $plan = Plans::create([
            'name' => $request->name,
            'machines' => $request->machines,
            'locals' => $request->locals,
            'price' => $request->price,
            'owner' => Auth::id(),
        ]);

        return response()->json(['success' => true, 'plan' => $plan]);
    }

    public function find($id)
    {
        $plan = Plans::findOrFail($id);
        return response()->json($plan);
    }
    
    public function getPlansAjax()
    {
        $planes = Plans::select('id', 'name')->get();
        return response()->json($planes);
    }

    public function update(Request $request, $id)
    {

        $plan = Plans::findOrFail($id);
        $plan->update($request->only(['name', 'machines', 'locals', 'price']));

        return response()->json(['success' => true]);
    }

    // Mostrar todos los planes
    public function show()
    {
        return view('plans.index');
    }

    public function fetchData(Request $request)
    {
        $query = $request->q ?? '';
    
        $plans = Plans::where('name', 'LIKE', "%{$query}%")
            ->orderBy('id', 'desc')
            ->paginate(6);
    
        return response()->json([
            'plans' => $plans->items(),
            'paginationHtml' => $plans->appends(['q' => $query])
                                     ->links('pagination::tailwind')->render(),
        ]);
    }
    
    public function destroy($id)
    {
        $plan = Plans::findOrFail($id);
        $plan->delete();
    
        return response()->json(['message' => 'Plan eliminado correctamente']);
    }
    
}