@extends('layouts.app')
@section('content')
<style>
    .M_E_p::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
        .pagination-btn {
            transition: background-color 0.3s ease;
        }
        .pagination-btn:hover {
            background-color: #2563eb; /* Cambia el color al pasar el mouse */
        }
        .pagination-btn.bg-blue-700 {
            background-color: #1e40af; /* Color para el botón activo */
        }
</style>
   <div class="M_E_p" style="overflow-x:scroll;">
   <div class="mb-4">
        <label for="searchInput" class="block text-gray-700 text-lg font-medium">LOGS</label>
        <input style=" width:60%;height:8;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-full px-4 py-5 mt-5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required="">
    </div>
    <style>
    .small-table {
        font-size: 12px; /* Reducir el tamaño de la fuente */
    }
    .small-table th, .small-table td {
        padding: 4px 8px; /* Reducir el padding */
    }
    .small-table th {
        white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
    }
    .small-table td {
        white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
    }
    .small-table {
        width: 100%; /* Ajustar el ancho de la tabla */
        overflow-x: auto; /* Permitir scroll horizontal si es necesario */
    }
</style>

<table class="small-table" style=" width:100%; min-width:100px;" class="min-w-full leading-normal">
    <thead>
            <tr>
                <th class="px-5 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Descripción
                </th>
                <th class="px-5 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Fecha
                </th>
                <th class="px-5 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Acciones
                </th>
            </tr>
        </thead>
        <tbody id="logs-table">
            @foreach($logs as $log)
                <tr class="GGG" data-log-id="{{ $log->id }}">
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
                        {{ $log->descript }}
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
                        {{ $log->fecha }}
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
                        <!-- Botones de acciones -->
                        <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn" data-log-descript="{{$log->descript}}" data-log-owner="{{$log->owner}}" data-log-fecha="{{$log->fecha}}" data-log-id="{{ $log->id }}"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" /></svg></button>
                        <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-log-id="{{ $log->id }}"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" /></svg></button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div id="pagination" class="flex justify-center mt-4"></div>
@include('admin.modals.edit_log')
@include('admin.modals.create_log')
@include('admin.modals.delete')


<script>
$(document).ready(function () {

    const rowsPerPage = 10; 
    const $rows = $('#logs-table tr.GGG'); 
    const totalRows = $rows.length; 
    const totalPages = Math.ceil(totalRows / rowsPerPage); 

    function showPage(page) {
        $rows.hide(); 
        $rows.slice((page - 1) * rowsPerPage, page * rowsPerPage).show(); 
    }

    function createPaginationButtons() {
        let buttons = '';
        for (let i = 1; i <= totalPages; i++) {
            buttons += `<button class="px-4 py-2 mx-1 bg-blue-500 text-white rounded-md pagination-btn" data-page="${i}">${i}</button>`;
        }
        $('#pagination').html(buttons);
    }

    showPage(1);
    createPaginationButtons();

    $('#pagination').on('click', '.pagination-btn', function () {
        const page = $(this).data('page'); 
        showPage(page); 

        $('.pagination-btn').removeClass('bg-blue-700').addClass('bg-blue-500');
        $(this).removeClass('bg-blue-500').addClass('bg-blue-700');
    });

    $("#searchInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#logs-table tr").filter(function() {
            $(this).toggle(
                $(this).find("td:nth-child(0)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(4)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(1)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(3)").text().toLowerCase().indexOf(value) > -1   
            );
        });
    });

    $('.close-modal').on('click', function () {
        $(this).closest('#editModal').addClass('hidden');
        $(this).closest('#deleteModal').addClass('hidden');
        $(this).closest('#viewTransactionsModal').addClass('hidden');
    });
});
</script>

@endsection