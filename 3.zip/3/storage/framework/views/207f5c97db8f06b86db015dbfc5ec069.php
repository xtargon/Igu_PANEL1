<style>
.switch {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 20px;
    
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
    border-radius: 20px;
}

.slider:before {
    position: absolute;
    content: "";
    height: 14px;
    width: 14px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: .4s;
    border-radius: 50%;
}

input:checked + .slider {
    background-color: #4CAF50;
}

input:checked + .slider:before {
    transform: translateX(20px);
}
</style>


<div id="createMachineModal" class="fixed inset-0 hidden bg-gray-800 bg-opacity-50 flex justify-center items-center p-4" style="
    height: 100%;
    overflow-y: scroll;
    margin-top:45px;
" style="z-index:1000;">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg h-5/6 overflow-y-auto">
        <h2 class="text-xl font-bold mb-4 text-center">Registrar nueva maquina</h2>
        <form id="createMachineForm" class="space-y-4">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

            <div>
                <label class="block text-gray-700">Nombre</label>
                <input type="text" name="nombre" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>

            <div>
                <label class="block text-gray-700">Local</label>
                <select name="local" id="localAdd" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    
                </select>
            </div>

            <div>
                <label class="block text-gray-700">Juegos</label>
                <select name="juego" id="gameAdd" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></select>
            </div>

            <div>
                <label class="block text-gray-700">P/P</label>
                <input type="number" name="p_p" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
   
               <div>
                <label class="block text-gray-700">Acumulados</label>
                <input style="margin:5px;" type="number" id="ac1" name="ac1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1" required>
                <input style="margin:5px;" type="number" id="ac2" name="ac2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2" required>
                <input style="margin:5px;" type="number" id="ac3" name="ac3" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3" required>
            </div>
            
            <div>
                <label class="block text-gray-700">Acumulado 1</label>
                <input style="margin:5px;" type="number" id="acumulated1" name="acumulated1_1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 inicial" required>
                <input style="margin:5px;" type="number" id="acumulated1_2" name="acumulated1_2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 actual" required>
                <input style="margin:5px;" type="number" id="acumulated1_3" name="acumulated1_3" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 maximo" required>
                <input style="margin:5px;" type="number" id="acumulated1_4" name="acumulated1_4" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 aumento %" required>
                <input style="margin:5px;" type="number" id="acumulated1_5" name="acumulated1_5" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 ganancia para pagar" required>
            </div>
            
            <div>
                <label class="block text-gray-700">Acumulado 2</label>
                <input style="margin:5px;" type="number" id="acumulated2" name="acumulated2_1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 inicial" required>
                <input style="margin:5px;" type="number" id="acumulated2_2" name="acumulated2_2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 actual" required>
                <input style="margin:5px;" type="number" id="acumulated2_3" name="acumulated2_3" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 maximo" required>
                <input style="margin:5px;" type="number" id="acumulated2_4" name="acumulated2_4" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 aumento %" required>
                <input style="margin:5px;" type="number" id="acumulated2_5" name="acumulated2_5" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 ganancia para pagar" required>
            </div>
            
            <div>
                <label class="block text-gray-700">Acumulado 3</label>
                <input style="margin:5px;" type="number" id="acumulated3" name="acumulated3_1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 inicial" required>
                <input style="margin:5px;" type="number" id="acumulated3_2" name="acumulated3_2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 actual" required>
                <input style="margin:5px;" type="number" id="acumulated3_3" name="acumulated3_3" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 maximo" required>
                <input style="margin:5px;" type="number" id="acumulated3_4" name="acumulated3_4" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 aumento %" required>
                <input style="margin:5px;" type="number" id="acumulated3_5" name="acumulated3_5" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 ganancia para pagar" required>
            </div>

            <!-- Botones -->
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" id="closeCreateModal" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>
<script>
    $('#openCreateModal').click(function () {
        let createInput1 = $("#localAdd");
        let createInput2 = $("#gameAdd");

        $.get('/locals_getting', function (data) {
            createInput1.empty(); 
            let LocalNot = `<option value="" style="color:red;">SIN LOCAL</option>`;
            createInput1.append(LocalNot);
            data.forEach(loc => {
                let rowLocal = `<option value="${loc.id}">${loc.nombre}</option>`;
                createInput1.append(rowLocal);
            });
        });

        $.get('/games_getting', function (data) {
            createInput2.empty(); 
            data.games.forEach(loc => {
                let rowGame = `<option value="${loc.id}">${loc.nombre}</option>`;
                createInput2.append(rowGame);
            });
        });

        $('#createMachineModal').removeClass('hidden');
    });

    $('#closeCreateModal').click(function () {
        $('#createMachineModal').addClass('hidden');
    });

    $('#createMachineForm').submit(function (e) {
        e.preventDefault();
        $.ajax({
            url: '/machines', 
            type: 'POST',
            data: $(this).serialize(),
            success: function (res) {
                $('#createMachineModal').addClass('hidden');
                Swal.fire({
                    icon: 'success',
                    title: '¡Máquina creada con éxito!',
                    showConfirmButton: false,
                    timer: 2000
                });
                var l = $("#localAdd").val();
                refreshMachinesForLocal(l);
                $('#createMachineForm')[0].reset();
                loadNames();
                assignActionListeners();
                assignPictureAction();
            },
            error: function (xhr) {
                alert('Error al crear la máquina');
            }
        });
    });
</script>
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/modals/create_machine.blade.php ENDPATH**/ ?>