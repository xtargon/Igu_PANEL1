<?php
    $globalBalance = 0;
    $globalIn = 0;
    $globalOut = 0;
?>
<style>
    .Counts{
        text-align:right;
    }
</style>
<?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div x-data="{ open: false }" class="local-item mb-6 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
  <!-- Header del Local -->
  <div class="bg-gray-100 dark:bg-gray-800 px-4 py-3 flex flex-col md:flex-row justify-between items-center cursor-pointer" @click="open = !open">
    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-2 md:mb-0" style="color: #6b7c84 !important;">
      <?php echo e($local->nombre); ?>

      <div class="Counts inline-block ml-2">
        <span class="font-normal text-green-600">
          <?php
            $totalMachine_in = 0;
            $totalLocal_in = 0;
            $totalMachine_out = 0;
            $totalLocal_out = 0;
            
            foreach($local->machines as $machine){
              foreach($machine->transacciones as $transaction){
                  $totalMachine_in += $transaction->parcial_in;
                  $totalMachine_out += $transaction->parcial_out;
              }
              $totalLocal_in += $totalMachine_in;
              $totalLocal_out += $totalMachine_out;
            }
            
            $globalBalance += $totalMachine_in - $totalMachine_out;
            $globalIn += $totalMachine_in;
            $globalOut += $totalMachine_out;
            
            echo "Entrada ".$totalMachine_in;
          ?>
        </span> 
        - <span class="font-normal" style="color:gray;">
          Salida <?php echo e($totalMachine_out); ?>

        </span>
        <span class="font-normal" style="color:rgb(44, 101, 226);">
          Balance <?php echo e($totalMachine_in - $totalMachine_out); ?>

        </span>
      </div>
    </h2>
    <!-- Íconos de flecha -->
    <div class="flex-shrink-0">
      <svg x-show="!open" class="w-5 h-5 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
      </svg>
      <svg x-show="open" class="w-5 h-5 transform rotate-180 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
      </svg>
    </div>
  </div>
  <!-- Contenido del Local -->
  <div x-show="open" class="px-4 py-3" x-transition>
    <?php $__currentLoopData = $local->machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div x-data="{ machineOpen: false }" class="mb-4 border border-gray-100 dark:border-gray-700 rounded-lg shadow">
        <!-- Header de la Máquina -->
        <div class="bg-white dark:bg-gray-800 px-4 py-2 flex flex-col md:flex-row justify-between items-center cursor-pointer" @click="machineOpen = !machineOpen">
          <div class="mb-2 md:mb-0">
            <span class="font-bold text-gray-800 dark:text-gray-100" style="color: #6b7c84 !important;"><?php echo e($machine->nombre); ?></span>
            
            <span class="text-green-600">
              <?php
                $totalMchineTransactionIn = 0;
                $totalMchineTransactionOut = 0;
                foreach($machine->transacciones as $transaction){
                   $totalMchineTransactionIn += $transaction->parcial_in;
                   $totalMchineTransactionOut += $transaction->parcial_out;
                }
                echo $totalMchineTransactionIn;
              ?>
            </span>
            <span style="color:gray;">
              <?php echo e($totalMchineTransactionOut); ?>

            </span>
            <span class="font-normal" style="color:rgb(44, 101, 226);">
              <?php echo e($totalMchineTransactionIn - $totalMchineTransactionOut); ?>

            </span>
          </div>
          
          <button type="button" class="text-blue-500 focus:outline-none" @click.stop="machineOpen = !machineOpen">
            <span x-show="!machineOpen"></span>
            <span x-show="machineOpen">Ocultar transacciones</span>
          </button>
          
                 <?php if($company->ia_picture === 'on'): ?>
                        <button 
                            class="openModalBtnss text-green-500 px-3 py-1 rounded-md"
                            data-machine-filter="<?php echo e($machine->filters); ?>"
                            data-machine-p_p="<?php echo e($machine->p_p); ?>"
                            data-machine-local="<?php echo e($machine->local); ?>"
                            data-machine-owner="<?php echo e($machine->owner); ?>"
                            style="float:right;"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z" />
                              <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z" />
                            </svg>

                        </button>
                 <?php else: ?>
                            <center>
                               <svg style="margin-left: 38%;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
                               </svg>
                            </center>
                 <?php endif; ?>  
        </div>
        <!-- Tabla de Transacciones de la Máquina -->
        <div x-show="machineOpen" class="overflow-x-auto" x-transition>
          <table class="min-w-full divide-y divide-gray-200 mt-2">
            <thead class="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Fecha</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-green-600 uppercase tracking-wider">Entrada</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-red-600 uppercase tracking-wider" style="color: #6b7c84 !important;">Salida</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Balance</th>
              </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200">
              <?php $__currentLoopData = $machine->transacciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100" style="color: #6b7c84 !important;"><?php echo e($transaction->fecha); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap text-sm text-green-900 dark:text-green-200" style="color: rgb(24 255 116);">
                    <?php echo e($transaction->parcial_in); ?>

                  </td>
                  <td class="px-4 py-2 whitespace-nowrap text-sm text-red-900 dark:text-gray-300" style="color: #6b7c84 !important;">
                    <?php echo e($transaction->parcial_out); ?>

                  </td>
                  <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100" style="color: #6b7c84 !important;">
                    <?php echo e($transaction->parcial_in - $transaction->parcial_out); ?>

                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="mt-6 p-4 bg-blue-50 dark:bg-gray-900 rounded-lg shadow" style="width:60%; text-align:center !important; float:right;">
  <h4 class="text-xl font-semibold text-blue-700 dark:text-blue-400 mb-4">Resumen General</h4>
  <div class="">
    <div class="bg-white dark:bg-gray-800 cursor-pointer rounded-lg p-3 shadow">
      <div>
        <span class="text-green-600 dark:text-green-400" style="font-size:25px; margin:3%;">
          <svg style="display: inline-flex;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
          </svg>
          <?php echo e($globalIn); ?>

        </span>
        <span style="font-size:25px; margin:3%;" class="text-gray-600 dark:text-gray-300"> 
          <svg style="display: inline-flex;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 4.5 4.5M12 3v13.5" />
          </svg> 
          <?php echo e($globalOut); ?>

        </span>
        <p style="display: inline-flex; color:transparent;"> = </p>
        <span class="text-blue-600 dark:text-blue-400" style="font-size:25px; margin:3%;"> 
          <?php echo e($globalBalance); ?>

        </span>
      </div>
    </div>
  </div>
</div>

<?php if($company->ia_picture === 'on'): ?>
<div id="modalOverlay" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
    <div id="modalContent" class="bg-white w-full max-w-md mx-4 rounded-2xl shadow-xl p-6 relative scale-90 opacity-0 transition-all duration-300" style="margin-top:30px !important;">
        <button id="closeModalBtnPic" class="absolute top-4 right-4 text-gray-600 hover:text-gray-800 transition duration-200">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
    </button>
        <h2 class="text-xl font-semibold mb-4">Balaces por imagen</h2>
                <div>
                    <label for="image" class="block text-gray-700 font-medium">Selecciona una imagen:</label>
                    <input type="file" id="image" name="image" accept="image/*" required 
                        class="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-300">
                </div>
                <form id="uploadForm" enctype="multipart/form-data" class="space-y-4">

                <div>
                    <label for="t_in" class="block text-sm font-medium text-gray-700">Total IN</label>
                    <input type="number" id="t_inIMG" name="total_in" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
                </div>
    
                <div>
                    <label for="t_out" class="block text-sm font-medium text-gray-700">Total OUT</label>
                    <input type="number" id="t_outIMG" name="total_out" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
                </div>
        
                <input type="hidden" id="filtersMachineByPictureBalance" name="filtermachine" required 
                        class="hiiden w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-300">

                <button type="submit" id="regTransac" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-all">
                   Registrar transaccion
                </button>
            </form>
        <div id="loader" class="hidden flex justify-center mt-4">
            <div class="w-8 h-8 border-4 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
        <div id="result" class="hidden mt-4 bg-gray-100 p-4 rounded shadow"></div>
    </div>
</div>

<script>
        function assignPictureAction(){
            $('.openModalBtnss').off('click').on('click', function () {
                var $btn = $(this);
                var machine_fil = $btn.data('machine-filter');
                
                currentModalData.buttonData = {
                    machine_fil: $btn.data('machine-filter'),
                    machine_p_p: $btn.data('machine-p_p'),
                    machine_owner: $btn.data('machine-owner'),
                    machine_local: $btn.data('machine-local')
                };
                
                $('#filtersMachineByPictureBalance').val(machine_fil);
                 
                $('#modalOverlay').removeClass('hidden');
                
                setTimeout(() => {
                    $('#modalContent').removeClass('scale-90 opacity-0').addClass('scale-100 opacity-100');
                }, 10);
                
                $('#image').on('change', function () {
                    var fileInput = this;
                
                    if (fileInput.files && fileInput.files[0]) {
                        var formData = new FormData();
                        formData.append('image', fileInput.files[0]);
                        formData.append('filter', machine_fil);
                
                        $.ajax({
                            url: '/apis.php',
                            type: 'POST',
                            data: formData,
                            processData: false,  // Importante para FormData
                            contentType: false,  // Importante para FormData
                            success: function (data) {
                                $('#t_inIMG').val(data.news.newIn);
                                $('#t_outIMG').val(data.news.newOut);
                                $('#balanceIMG').val(data.news.newBalance);
                                var params = {
                                    machine_id:       $btn.data('machine-filter'),
                                    parcial_balance:  data.diferencias.balance,
                                    parcial_in:       data.diferencias.in,
                                    parcial_out:      data.diferencias.out,
                                    percentage_pay:   $btn.data('machine-p_p'),
                                    owner:            $btn.data('machine-owner'),
                                    local_id:         $btn.data('machine-local'),
                                    total_in:         data.news.newIn,
                                    total_out:        data.news.newOut,
                                    total_balance:    data.news.newIn - data.news.newOut,
                                };
                                $('#regTransac').prop('disabled', false);
                                document.getElementById('uploadForm').addEventListener('submit', async function(e) {
                                    e.preventDefault();
                                    sendTransaction(params)
                                });                        
                                
                                
                            },
                            error: function (xhr, status, error) {
                                console.error('Error al enviar la imagen:', error);
                            }
                        });
                    }
                });
            });
    
            // Cerrar modal con animación
            $('#closeModalBtnPic').click(function () {
                $('#modalContent').removeClass('scale-100 opacity-100').addClass('scale-90 opacity-0');
                setTimeout(() => {
                    $('#modalOverlay').addClass('hidden');
                }, 300);
            });
        }
        
        $('#uploadForm').off('submit').on('submit', function(e) {
            e.preventDefault();
            
            const $btn = $('#regTransac');
            $btn.prop('disabled', true);
            $btn.text('Procesando...');
            $btn.addClass('opacity-50 cursor-not-allowed');
                
            if (currentModalData.paramsForSendTransaction) {
                sendTransaction(currentModalData.paramsForSendTransaction);
            } else {
                const t_in = $('#t_inIMG').val();
                const t_out = $('#t_outIMG').val();
                const balance = t_in - t_out;
                const machine_id = $('#filtersMachineByPictureBalance').val();
    
                if (t_in && t_out && balance && machine_id) {
                    const manualData = {
                        machine_id: machine_id,
                        parcial_balance: balance,
                        parcial_in: t_in,
                        parcial_out: t_out,
                        percentage_pay: currentModalData.buttonData?.machine_p_p || 0,
                        owner: currentModalData.buttonData?.machine_owner || '',
                        local_id: currentModalData.buttonData?.machine_local || '',
                        total_in: t_in,
                        total_out: t_out,
                        total_balance: t_in - t_out
                    };
                    sendTransaction(manualData);
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Datos incompletos',
                        text: 'Por favor, completa manualmente los campos IN, OUT y Balance o carga una imagen.'
                    });
                }
            }
        });
        assignPictureAction();
</script>

<?php endif; ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/transactions/partials/locales.blade.php ENDPATH**/ ?>