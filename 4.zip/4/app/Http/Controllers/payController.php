<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pay;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

use App\Models\Plans;
use App\Models\Empresas;
use App\Models\Machine;
use App\Models\Local;

class payController extends Controller
{
    public function index(Request $request){
        return view('payment');
    }

    public function paymentSuccess(Request $request){
        
    } 
    
    public function paypalSuccess(Request $request)
    {
        $request->validate([
            'orderID' => 'required|string',
            'payerID' => 'required|string',
        ]);
    
        $orderID = $request->orderID;
    
        // Autenticación con PayPal
        $clientId = env('PAYPAL_CLIENT_ID');
        $secret = env('PAYPAL_SECRET');
        $auth = base64_encode("$clientId:$secret");
    
        $tokenResponse = Http::asForm()->withHeaders([
            'Authorization' => "Basic $auth",
        ])->post('https://api-m.sandbox.paypal.com/v1/oauth2/token', [
            'grant_type' => 'client_credentials',
        ]);
    
        if (!$tokenResponse->ok()) {
            return response()->json(['success' => false, 'message' => 'No se pudo autenticar con PayPal'], 500);
        }
    
        $accessToken = $tokenResponse['access_token'];
    
        // Obtener detalles de la orden
        $orderResponse = Http::withToken($accessToken)
            ->get("https://api-m.sandbox.paypal.com/v2/checkout/orders/{$orderID}");
    
        if (!$orderResponse->ok()) {
            return response()->json(['success' => false, 'message' => 'No se pudo obtener la orden'], 500);
        }
    
        $orderData = $orderResponse->json();
    
        if ($orderData['status'] !== 'COMPLETED') {
            return response()->json(['success' => false, 'message' => 'El pago no está completado'], 400);
        }
    
        // Monto pagado por PayPal (ej. "10.00")
        $paidAmount = $orderData['purchase_units'][0]['amount']['value'];
    
        // Obtener empresa y plan
        $company = Empresas::where('id', Auth::user()->company_id)->first();
        $plan = Plans::find($company->share);
    
        // Convertir precio del plan (10) a "10.00"
        $expectedAmount = number_format($plan->price, 2, '.', '');
    
        if ($paidAmount === $expectedAmount) {
            // Aumentar monedas
            $company->coins += floatval($paidAmount);
            $company->save();
    
            return response()->json([
                'success' => true,
                'message' => 'Pago verificado y monedas añadidas.'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => "Monto incorrecto: esperado $expectedAmount, recibido $paidAmount"
            ], 400);
        }
    }
    
    public function show(Request $request){
        $user = Auth::user();
        $company = Empresas::where('id', Auth::user()->company_id)->first();
        
        $plan = Plans::find($company->share);
        

        $totalMaquinas = Machine::where('owner', $company->id)->count();
        $totalLocales  = Local::where('company_id', $company->id)->count();
    
        $limiteMaquinasPlan = $plan ? $plan->machines : 0;
        $limiteLocalesPlan  = $plan ? $plan->locals : 0;
        $precioPlan = $plan ? $plan->price : 0;

        $resultadoMaquinas = $totalMaquinas * $limiteMaquinasPlan;
        $resultadoLocales  = $totalLocales * $limiteLocalesPlan;
    
        $totalFinal = $precioPlan + $resultadoMaquinas + $resultadoLocales;        
        
        return view('checkout',  compact(
            'plan', 'company', 'totalMaquinas', 'totalLocales',
            'limiteMaquinasPlan', 'limiteLocalesPlan',
            'precioPlan', 'resultadoMaquinas', 'resultadoLocales', 'totalFinal'
        ));
    }
    
   
    
}
















