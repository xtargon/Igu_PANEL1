<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Transacciones por Rango de Fechas</title>
  <!-- Tailwind CSS -->
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <!-- Flatpickr CSS para el selector de fecha -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body class="bg-gray-100">
  <div class="container mx-auto p-4">
    <div class="bg-white shadow rounded-lg p-6">
      <h1 class="text-2xl font-bold mb-4 text-center">Buscar Transacciones</h1>
      <form action="<?php echo e(route('transactionsDate.search')); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <div class="flex flex-col sm:flex-row gap-4">
          <div class="flex-1">
            <label for="start_date" class="block text-gray-700 font-semibold">Fecha de Inicio</label>
            <input type="text" id="start_date" name="start_date" 
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" 
              placeholder="Selecciona fecha de inicio"
              value="<?php echo e(old('start_date', isset($start_date) ? $start_date : '')); ?>">
          </div>
          <div class="flex-1">
            <label for="end_date" class="block text-gray-700 font-semibold">Fecha Tope</label>
            <input type="text" id="end_date" name="end_date" 
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" 
              placeholder="Selecciona fecha tope"
              value="<?php echo e(old('end_date', isset($end_date) ? $end_date : '')); ?>">
          </div>
        </div>
        <div class="text-center">
          <button type="submit" class="mt-4 px-6 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition duration-200">
            Buscar
          </button>
        </div>
      </form>
    </div>

    <?php if(isset($transactions)): ?>
    <div class="mt-8 bg-white rounded-lg shadow overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total In</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Out</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Balance</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parcial Balance</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parcial In</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parcial Out</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Percentage Pay</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created At</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Updated At</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Owner</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Machine ID</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Local ID</th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->id); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->total_in); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->total_out); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->total_balance); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->parcial_balance); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->parcial_in); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->parcial_out); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->percentage_pay); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->created_at); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->updated_at); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->owner); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->fecha); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->machine_id); ?></td>
            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaction->local_id); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="14" class="px-6 py-4 text-center text-gray-500">No se encontraron transacciones en este rango de fechas.</td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- Flatpickr JS para el selector de fecha -->
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  <script>
    flatpickr("#start_date", {
      dateFormat: "Y-m-d",
      locale: "es"
    });
    flatpickr("#end_date", {
      dateFormat: "Y-m-d",
      locale: "es"
    });
  </script>
</body>
</html>
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/transactions/index.blade.php ENDPATH**/ ?>