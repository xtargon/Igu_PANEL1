<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Machine;
use App\Models\User;
use App\Models\Game;
use App\Models\Local;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    /**
     * Muestra la vista del dashboard con los datos de las máquinas y usuarios.
     */
    public function index()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if( auth()->user()->created === 23){
            return redirect('/admin');
        }
        
        $authenticatedUser = Auth::user();
        $machinesG = Machine::where('owner', $authenticatedUser->company_id)->get();
        $gamesG = Game::where('owner', $authenticatedUser->company_id)->get();
        $localsG = Local::where('company_id', $authenticatedUser->company_id)->get();
        $transactionsG = Transaction::where('owner', $authenticatedUser->company_id)->get();

        $machines = $machinesG->count();
        $games = $gamesG->count();
        $locals = $localsG->count();
        $transactions = $transactionsG->count();

        return view('dashboard', compact('machines', 'transactions', 'games', 'locals'));


    }
}
