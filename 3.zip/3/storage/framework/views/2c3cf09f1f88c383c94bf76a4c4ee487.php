<div id="createGameModal" class="fixed inset-0 hidden bg-gray-800 bg-opacity-50 flex justify-center items-center p-4" style="
    height: 100%;
    overflow-y: scroll;
        margin-top:45px;

" style="z-index:1000;">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg md:w-1/2 lg:w-1/3">
        <h2 class="text-xl font-bold mb-4 text-center">Crear Nuevo Juego</h2>
        <form id="createGameForm">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            
            <div class="mb-2">
                <label class="block text-gray-700">Nombre</label>
                <input type="text" name="nombre" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required>
            </div>
            
            <div class="mb-2">
                <label class="block text-gray-700">Fabricante</label>
                <input type="text" name="fabricante" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required>
            </div>
            
            <div class="mb-2">
                <label class="block text-gray-700">Matematica</label>
                <input type="text" name="matematica" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required>
            </div>
            
            <div class="mb-2">
                <label class="block text-gray-700">Estado</label>
                <select name="state" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                </select>
            </div>
            
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" id="closeCreateModal" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function () {
        // Función para asignar event listeners a los botones de acciones
                function assignActionListeners() {
                    $('.edit-btn').off('click').on('click', function () {
                        const gameId = $(this).data('game-id');
                        const nombre = $(this).data('game-nombre');
                        const fabricante = $(this).data('game-fabricante');
                        const matematica = $(this).data('game-matematica');
                        const state = $(this).data('game-state');
                        $('#editModal').removeClass('hidden');
                        $('#editGameId').val(gameId);
                        $('#nombre').val(nombre);
                        $('#fabricante').val(fabricante);
                        $('#matematica').val(matematica);
                        $('#state').val(state);
                    });
                    
                    $('.delete-btn').off('click').on('click', function () {
                        const gameId = $(this).data('game-id');
                        $('#deleteModal').removeClass('hidden');
                        $('#deleteUserId').val(gameId);
                    });
                }
                
                $('#deleteUserForm').on('submit', function (e) {
                    e.preventDefault();
                    const gameId = $('#deleteUserId').val();

                    $.ajax({
                        url: `/games/${gameId}`,
                        method: 'DELETE',
                        data: $(this).serialize(),
                        success: function (response) {
                            $('#deleteModal').addClass('hidden');
                            $(`tr[data-game-id="${gameId}"]`).remove();
                            assignActionListeners();
                        },
                        error: function (xhr) {
                            console.error(xhr.responseText);
                        }
                    });
                });

                $('#editGameForm').on('submit', function (e) {
                    e.preventDefault();
                    const gameId = $('#editGameId').val();

                    $.ajax({
                        url: `/games/${gameId}`,
                        method: 'PUT',
                        data: $(this).serialize(),
                        success: function (res) {
                            $('#editModal').addClass('hidden');
                            $(`tr[data-game-id="${gameId}"]`).html(`
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.game.nombre}</td>
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.game.fabricante}</td>
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.game.matematica}</td>
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.game.state}</td>
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                    <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn" 
                                        data-game-nombre="${res.game.nombre}"  
                                        data-game-fabricante="${res.game.fabricante}"  
                                        data-game-matematica="${res.game.matematica}"  
                                        data-game-state="${res.game.state}"  
                                        data-game-id="${res.game.id}">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                                            </svg>
                                    </button>
                                    <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" 
                                        data-game-id="${res.game.id}">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                            </svg>
                                    </button>
                                </td>
                            `);
                            assignActionListeners();
                        },
                        error: function (xhr) {
                            console.error(xhr.responseText);
                        }

                    });
                });

        $('.close-modal').on('click', function () {
            $(this).closest('#editModal').addClass('hidden');
            $(this).closest('#deleteModal').addClass('hidden');
        });

        $('#openCreateModal').click(function () {
            $('#createGameModal').removeClass('hidden');
        });

        $('#closeCreateModal').click(function () {
            $('#createGameModal').addClass('hidden');
        });

        $('#createGameForm').submit(function (e) {
            e.preventDefault();
            $.ajax({
                url: '/games', 
                type: 'POST',
                data: $(this).serialize(),
                success: function (response) {
                    let newRow = `
                        <tr class="game-row" data-game-id="${response.game.id}">
                            <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${response.game.nombre}</td>
                            <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${response.game.fabricante}</td>
                            <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${response.game.matematica}</td>
                            <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${response.game.state}</td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md mr-2 edit-btn" data-game-id="${response.game.id}" data-game-nombre="${response.game.nombre}" data-game-fabricante="${response.game.fabricante}" data-game-matematica="${response.game.matematica}" data-game-owner="${response.game.owner}" data-game-state="${response.game.state}">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                                    </svg>
                                </button>
                                <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md mr-2 delete-btn" data-game-id="${response.game.id}">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                    </svg>
                                </button>
                            </td>
                        </tr>
                    `;
                    $('#games-table').append(newRow);
                    assignActionListeners();
                    $('#createGameModal').addClass('hidden');
                },
                error: function (xhr) {
                    alert('Error al crear el juego');
                }
            });
        });

        assignActionListeners();
    });
</script><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/modals/create_games.blade.php ENDPATH**/ ?>