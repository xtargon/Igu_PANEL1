
<style>
.M_E{
    height:81%;
    padding:25px;
    margin-top:60px;
    overflow-y:scroll;
    width:80%;
}
.M_E::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
</style>
<!-- Modal de Editar Log -->
<div id="editModal" style="
    height: 100%;
    overflow-y: scroll;
    margin-top:45px;
" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-xl font-bold mb-4 text-center">Editar Log</h2>

        <form id="editLogForm" class="space-y-4">
            <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <input type="hidden" id="editLogId" name="log_id">

            <div>
                <label for="descript" class="block text-sm font-medium text-gray-700">Descripcion</label>
                <input type="text" id="descript" name="descript" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2" required>
            </div>

            <div>
                <label for="fecha" class="block text-sm font-medium text-gray-700">Fecha</label>
                <input type="date" id="fecha" name="fecha" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2" required>
            </div>

            <!-- Botones -->
            <div class="flex justify-center space-x-4">
                <button type="button" class="close-modal bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>
