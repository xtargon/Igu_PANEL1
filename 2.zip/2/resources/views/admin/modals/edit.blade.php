<!-- Modal de Editar Usuario -->
<div id="editModal" style="" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
    
    <div style="overflow-y: scroll; margin-top:-20px; height: 93%;" class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-xl font-bold mb-4 text-center">Editar cliente</h2>

        <form id="editUserForm" class="space-y-4">
            @csrf
                    
            @php
                $inputClasses = 'w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500';
            @endphp
            
            <input type="hidden" name="user_id" id="editUserId">

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700">Nombre</label>
                <input type="text" name="name" id="name" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
            </div>

            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" name="email" id="email" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
            </div>

            <div>
                <label for="role" class="block text-sm font-medium text-gray-700">Rol</label>
                <select name="role" id="role" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
                    <option value="administrador">Administrador</option>
                    <option value="usuario">Usuario</option>
                </select>
            </div>
        @if(auth()->user()->created !== 23)
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Locales Asignados
              </label>
        
              <!-- Aqu�� aparecer��n los tags seleccionados -->
              <div id="edit-selected-locals" class="flex flex-wrap gap-2 mb-2"></div>
        
              <!-- Lista de todos los locales disponibles -->
              <ul id="edit-locals-list" 
                  class="border border-gray-300 rounded p-2 max-h-56 overflow-y-auto bg-white shadow">
                <!-- se llena din��micamente -->
              </ul>
        
              <!-- Hidden donde van los IDs unidos por comas -->
              <input type="hidden" name="local" id="edit-local-ids">
            </div>
        @else
            <div>
                <label class="block text-gray-700">Pais</label>
                <select id="countrySelectUp" name="direccion" class="{{ $inputClasses }}" required>
                  <!-- Am��rica Latina y el Caribe -->
                  <option value="Spain">Spain</option>
                  <option value="United States">United States</option>
                  <option value="Mexico">Mexico</option>
                  <option value="Argentina">Argentina</option>
                  <option value="Colombia">Colombia</option>
                  <option value="Chile">Chile</option>
                  <option value="Peru">Peru</option>
                  <option value="Venezuela">Venezuela</option>
                  <option value="Ecuador">Ecuador</option>
                  <option value="Uruguay">Uruguay</option>
                  <option value="Paraguay">Paraguay</option>
                  <option value="Bolivia">Bolivia</option>
                  <option value="Brazil">Brazil</option>
                  <option value="Cuba">Cuba</option>
                  <option value="Dominican Republic">Dominican Republic</option>
                  <option value="Puerto Rico">Puerto Rico</option>
                  <option value="Costa Rica">Costa Rica</option>
                  <option value="Panama">Panama</option>
                  <option value="Guatemala">Guatemala</option>
                  <option value="Honduras">Honduras</option>
                  <option value="El Salvador">El Salvador</option>
                  <option value="Nicaragua">Nicaragua</option>
                  <option value="Belize">Belize</option>
                  <option value="Jamaica">Jamaica</option>
                  <option value="Haiti">Haiti</option>
                  <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                  <option value="Suriname">Suriname</option>
                  <option value="Guyana">Guyana</option>
                  <option value="French Guiana">French Guiana</option>
                  <option value="Barbados">Barbados</option>
                  <option value="St. Lucia">St. Lucia</option>
                  <option value="St. Vincent and the Grenadines">St. Vincent and the Grenadines</option>
                  <option value="Grenada">Grenada</option>
                  <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                  <option value="Dominica">Dominica</option>
                  <option value="Bahamas">Bahamas</option>
                  <option value="Bermuda">Bermuda</option>
                  <option value="Brazil - Acre">Brazil - Acre</option>
                  <option value="Brazil - Campo Grande">Brazil - Campo Grande</option>
                  <option value="Brazil - Manaus">Brazil - Manaus</option>
                  <option value="Brazil - Cuiaba">Brazil - Cuiaba</option>
                  <option value="Brazil - Fortaleza">Brazil - Fortaleza</option>
                  <option value="Argentina - Cordoba">Argentina - Cordoba</option>
                  <option value="Argentina - Mendoza">Argentina - Mendoza</option>
                  <option value="Chile - Punta Arenas">Chile - Punta Arenas</option>
                  <option value="Mexico - Hermosillo">Mexico - Hermosillo</option>
                  <option value="Ecuador - Galapagos">Ecuador - Galapagos</option>
                  <option value="Brazil - Belem">Brazil - Belem</option>
                  <option value="Argentina - La Rioja">Argentina - La Rioja</option>
                  <option value="Chile - Easter Island">Chile - Easter Island</option>
                  <!-- Pa��ses europeos -->
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="Germany">Germany</option>
                  <option value="France">France</option>
                  <option value="Italy">Italy</option>
                  <option value="Netherlands">Netherlands</option>
                  <option value="Sweden">Sweden</option>
                  <option value="Norway">Norway</option>
                  <option value="Poland">Poland</option>
                  <option value="Turkey">Turkey</option>
                  <option value="Russia">Russia</option>
                  <!-- Pa��ses asi��ticos -->
                  <option value="China">China</option>
                  <option value="Japan">Japan</option>
                  <option value="India">India</option>
                  <option value="South Korea">South Korea</option>
                  <option value="Singapore">Singapore</option>
                  <option value="Indonesia">Indonesia</option>
                  <option value="Thailand">Thailand</option>
                  <option value="Vietnam">Vietnam</option>
                  <option value="Malaysia">Malaysia</option>
                  <option value="United Arab Emirates">United Arab Emirates</option>
                </select>
            </div>
        @endif
        @if(auth()->user()->created === 23)
            <div>
                <label for="plan_id" class="block text-sm font-medium text-gray-700 mb-1">Plan asignado</label>
                <select id="plan_id" name="share"
                        class="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring focus:border-blue-500">
                    <option value="">Cargando planes...</option>
                </select>
                
                {{-- Pasamos el ID del plan actual desde la empresa --}}
                <input type="hidden" id="current_plan_id">                
            </div>
        @endif
            <div>
                <div class="flex items-center justify-between mt-4">
                  <label for="iaBalance" class="text-gray-700 text-sm font-medium">
                    AI - Detector de balances y diferencias
                  </label>
                
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" id="iaBalance" class="sr-only peer">
                    <div class="w-11 h-6 bg-gray-300 rounded-full peer peer-checked:bg-green-600 transition-colors duration-300"></div>
                    <div class="absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-300 transform peer-checked:translate-x-full"></div>
                  </label>
                </div>
            </div>
            <br>
            <div>
                <div class="flex items-center justify-between mt-4">
                  <label for="geolocation" class="text-gray-700 text-sm font-medium">Geolocalización</label>
                  
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" id="geolocation" class="sr-only peer">
                    <div class="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-green-500 rounded-full peer peer-checked:bg-green-500 transition-colors duration-300"></div>
                    <div class="absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-300 transform peer-checked:translate-x-full"></div>
                  </label>
                </div>
            </div>
            <br>
            <div>
                <label class="block text-sm font-medium text-gray-700">Contrase�0�9a</label>
                <input type="password" placeholder="Escribir para editar" name="password" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
            </div>

            <!-- Botones -->
            <div class="flex justify-center space-x-4">
                <button type="button" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition close-modal">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>
