<?php

namespace App\Http\Controllers;

use App\Models\mega_admin;
use Illuminate\Http\Request;

class MegaAdminController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(mega_admin $mega_admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(mega_admin $mega_admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, mega_admin $mega_admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(mega_admin $mega_admin)
    {
        //
    }
}
