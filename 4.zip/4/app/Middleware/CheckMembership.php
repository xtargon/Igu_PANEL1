<?php

namespace App\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Empresas;
use App\Models\Plans;
use App\Models\Machine;
use App\Models\Local;

class CheckMembership
{
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();

        if (!$user) {
            return redirect('/login');
        }

        $company = Empresas::find($user->company_id);

        if (
            !$company->last_recharge ||
            Carbon::createFromFormat('Y-m-d', $company->last_recharge)
                ->diffInDays(Carbon::today()) >= 30
        ) {
                $plan = Plans::find($company->share);

                $totalMaquinas = Machine::where('owner', $company->id)->count();
                $totalLocales  = Local::where('company_id', $company->id)->count();
            
                $limiteMaquinasPlan = $plan ? $plan->machines : 0;
                $limiteLocalesPlan  = $plan ? $plan->locals : 0;
                $precioPlan = $plan ? $plan->price : 0;

                $resultadoMaquinas = $totalMaquinas * $limiteMaquinasPlan;
                $resultadoLocales  = $totalLocales * $limiteLocalesPlan;
                
                $totalFinal = $precioPlan + $resultadoMaquinas + $resultadoLocales;
                
            if ($company->coins >= $totalFinal) {
                $company->decrement('coins', $totalFinal);
                $company->update(['last_recharge' => Carbon::today()->format('Y-m-d')]);
                $user->update(['last_recharge' => Carbon::today()->format('Y-m-d')]);
                return $next($request);
            } else {
                return redirect('/payment');
            }
        }

        return $next($request);
    }
}
