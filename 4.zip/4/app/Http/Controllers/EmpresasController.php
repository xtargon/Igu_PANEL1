<?php

namespace App\Http\Controllers;

use App\Models\Empresas;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class EmpresasController extends Controller
{
    public function store(Request $request)
    {
        $uID = auth()->user()->id;
        $user = User::findOrFail($uID);

        if(auth()->user()->created === 1){
            $company = Empresas::create([
                'nombre' => $request->nombre,
                'telefono' => $request->telefono,
                'sector' => $request->sector,
                'direccion' => $request->direccion,
                'owner' => auth()->user()->owner,    
            ]);

            // Actualizar el campo company_id
            $eID = $company->id;
            $user->update([
                'company_id' => $eID,
                'company' => $request->nombre
            ]);

            return response()->json(['success' => true, 'eID' => $eID , 'user' => $user, 'company' => $company->id]);
        }else{
            $company = Empresas::create([
                'nombre' => $request->nombre,
                'telefono' => $request->telefono,
                'sector' => $request->sector,
                'direccion' => $request->direccion,
                'owner' => auth()->user()->id,    
            ]);

            $eID = $company->id;
            $user->update([
                'company_id' => $eID,
                'company' => $request->nombre
            ]);
            
            return response()->json(['success' => true, 'eID' => $eID , 'user' => $user, 'company' => $company->id]);
        }

    }

    public function index(Request $request)
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->role !== 'administrador'){
            return redirect('/dashboard');
        }

        $company = Empresas::where('owner', Auth::user()->id)->get();
        return view('company', compact('company'));
    }

    public function show(Request $request)
    {
        if(auth()->user()->role === 'administrador'){
            if(auth()->user()->created === 1){
                $companys = Empresas::where('owner', auth()->user()->owner)->get();
                $totalcompanys = $companys->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalcompanys,
                    'companys' => $companys
                ]);
            }else{
                $companys = Empresas::where('owner', auth()->user()->id)->get();
                $totalcompanys = $companys->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalcompanys,
                    'companys' => $companys
                ]);
            }
        }else{
            return redirect('/dashboard');
        }
    }

    public function update(Request $request, $id)
    {
        $empresa = Empresas::findOrFail($id);
        $empresa->update($request->all());
        return response()->json(['message' => 'Empresa actualizado correctamente']);
    }

    public function find(Request $request)
    {
        $logs = Log::where('id', $request->idUser)->get();
        return response()->json($logs);
    }

    public function destroy($id)
    {
        $empresa = Empresas::findOrFail($id);
        $empresa->delete();

        return response()->json(['success' => true]);
    }
    
    public function findKing($id)
    {
        try {
            $empresa = Empresas::findOrFail($id);

            return response()->json([
                'empresa' => $empresa
            ]);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Empresa no encontrada con ID ' . $id
            ], 404);
        }
    }
}
