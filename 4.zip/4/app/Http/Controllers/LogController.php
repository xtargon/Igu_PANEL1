<?php

namespace App\Http\Controllers;

use App\Models\Log;
use Illuminate\Http\Request;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Auth;


class LogController extends Controller
{
    public function store(Request $request)
    {
        if(auth()->user()->created === 1 || auth()->user()->created === 23){
            $log = Log::create([
                'companyID' => auth()->user()->company_id,
                'descript' => $request->descript,
                'fecha' => $request->date,
                'owner' => auth()->user()->id,    
            ]);
        }else{
            $log = Log::create([
                'companyID' => auth()->user()->company_id,
                'descript' => $request->descript,
                'fecha' => $request->date,
                'owner' => auth()->user()->local,    
            ]);
        }


        return response()->json(['success' => true, 'log' => $log]);
    }

    public function index(Request $request)
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if(auth()->user()->role !== 'administrador'){
            return redirect('/dashboard');
        }

        $logs = Log::where('owner', Auth::user()->id)->get();
        return view('logs', compact('logs'));
    }

    public function getting(Request $request)
    {
        if(auth()->user()->role === 'administrador'){
            if(auth()->user()->created === 1){
                $logs = Log::where('owner', auth()->user()->owner)->get();
                $totallogs = $logs->count();
                return response()->json([
                    'success' => true,
                    'num' => $totallogs,
                    'logs' => $logs
                ]);
            }else{
                $logs = Log::where('owner', auth()->user()->id)->get();
                $totallogs = $logs->count();
                return response()->json([
                    'success' => true,
                    'num' => $totallogs,
                    'logs' => $logs
                ]);
            }
        }else{
            return redirect('/dashboard');
        }
    }

    public function update(Request $request, $id)
    {
        $logs = Log::findOrFail($id);
        $logs->update($request->only('descript', 'owner', 'fecha'));
        return response()->json(['log' => $logs]);
    }

    public function find(Request $request)
    {
        $logs = Log::where('id', $request->idUser)->get();
        return response()->json($logs);
    }

    public function destroy($id)
    {
        $log = Log::findOrFail($id);
        $log->delete();

        return response()->json(['success' => true]);
    }


    
}
