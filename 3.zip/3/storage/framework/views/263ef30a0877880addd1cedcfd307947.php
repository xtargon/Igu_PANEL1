
<style>
.M_E{
    height:81%;
    padding:25px;
    margin-top:60px;
    overflow-y:scroll;
    width:80%;
}
.M_E::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
</style>
<!-- Modal de Editar Local -->
<div id="editModal" style="
    margin-top:45px;
" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
    <div  id="bgWhite" class="bg-white p-6 rounded-lg shadow-lg " style="
    z-index:1000;
    height: 90%;
    margin-left:15%;
    overflow-y: scroll;">
        <h2 class="text-xl font-bold mb-4 text-center">Editar Local</h2>

        <form id="editLocalForm" class="space-y-4">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" id="editLocalId" name="local_id">

            <div>
                <label for="nombre" class="block text-sm font-medium text-gray-700">Nombre</label>
                <input type="text" id="nombre" name="nombre" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2" required>
            </div>

            <div>
                <label for="estado" class="block text-sm font-medium text-gray-700">Estado</label>
                <input type="text" id="estado" name="estado" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2" required>
            </div>

                <label class="block mb-2 font-semibold text-gray-700">Telefono</label>

                <div>
                  <input type="tel" id="phoneEdit" name="phone"
                         placeholder="123 456 789"
                         class="flex-1 rounded-lg border-gray-300 shadow-sm focus:ring focus:ring-blue-200 p-2" />
                </div>


            <div>
                <label for="state" class="block text-sm font-medium text-gray-700">Estatus</label>
                <select name="state" id="state" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                </select>
            </div>

            <div>
                  <div>
                    <label for="cityEdit" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Pais
                    </label>
                    <select id="cityEdit" placeholder="Escoje la ciudad" required name="ciudad"
                            class="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 shadow-sm focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-500 focus:border-blue-400 dark:focus:border-blue-500 outline-none transition-all duration-300">
                      <option value="Spain">Spain</option>
                      <option value="United States">Estados Unidos</option>
                      <option value="Mexico">México</option>
                      <option value="Argentina">Argentina</option>
                      <option value="Colombia">Colombia</option>
                      <option value="Chile">Chile</option>
                      <option value="Peru">Perú</option>
                      <option value="Venezuela">Venezuela</option>
                      <option value="Ecuador">Ecuador</option>
                      <option value="Uruguay">Uruguay</option>
                      <option value="Paraguay">Paraguay</option>
                      <option value="Bolivia">Bolivia</option>
                      <option value="Brazil">Brasil</option>
                      <option value="Cuba">Cuba</option>
                      <option value="Dominican Republic">República Dominicana</option>
                      <option value="Puerto Rico">Puerto Rico</option>
                      <option value="Costa Rica">Costa Rica</option>
                      <option value="Panama">Panamá</option>
                      <option value="Guatemala">Guatemala</option>
                      <option value="Honduras">Honduras</option>
                      <option value="El Salvador">El Salvador</option>
                      <option value="Nicaragua">Nicaragua</option>
                      <option value="Belize">Belice</option>
                      <option value="Jamaica">Jamaica</option>
                      <option value="Haiti">Haití</option>
                      <option value="Trinidad and Tobago">Trinidad y Tobago</option>
                      <option value="Suriname">Surinam</option>
                      <option value="Guyana">Guyana</option>
                      <option value="French Guiana">Guayana Francesa</option>
                      <option value="Barbados">Barbados</option>
                      <option value="St. Lucia">Santa Lucía</option>
                      <option value="St. Vincent and the Grenadines">San Vicente y las Granadinas</option>
                      <option value="Grenada">Granada</option>
                      <option value="Antigua and Barbuda">Antigua y Barbuda</option>
                      <option value="Dominica">Dominica</option>
                      <option value="Bahamas">Las Bahamas</option>
                      <option value="Bermuda">Bermudas</option>
                      <option value="Brazil - Acre">Brasil – Acre</option>
                      <option value="Brazil - Campo Grande">Brasil – Campo Grande</option>
                      <option value="Brazil - Manaus">Brasil – Manaus</option>
                      <option value="Brazil - Cuiaba">Brasil – Cuiabá</option>
                      <option value="Brazil - Fortaleza">Brasil – Fortaleza</option>
                      <option value="Argentina - Cordoba">Argentina – Córdoba</option>
                      <option value="Argentina - Mendoza">Argentina – Mendoza</option>
                      <option value="Chile - Punta Arenas">Chile – Punta Arenas</option>
                      <option value="Mexico - Hermosillo">México – Hermosillo</option>
                      <option value="Ecuador - Galapagos">Ecuador – Galápagos</option>
                      <option value="Brazil - Belem">Brasil – Belém</option>
                      <option value="Argentina - La Rioja">Argentina – La Rioja</option>
                      <option value="Chile - Easter Island">Chile – Isla de Pascua</option>
                    </select>                  
                  </div>
                  
                  
                 <div id="mapEdit"></div>
                 <input type="hidden" name="lat" id="latedit">
                 <input type="hidden" name="lon" id="lngedit">
            </div>

            <!-- Botones -->
            <div class="flex justify-center space-x-4">
                <button type="button" class="close-modal bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/modals/edit_local.blade.php ENDPATH**/ ?>