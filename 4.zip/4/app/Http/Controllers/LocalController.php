<?php

namespace App\Http\Controllers;

use App\Models\Local;
use Illuminate\Http\Request;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Auth;
use App\Models\Car;
use App\Models\Empresas;

class LocalController extends Controller
{
    
    public function machinesTable(Local $local)
    
    {   
        $empresa = Empresas::findOrFail(auth()->user()->company_id);
        $machines = $local->machines()
                          ->where('owner', auth()->user()->company_id)
                          ->get();
    
        return view('partials.local_tbody', compact('machines', 'empresa'));
    }
    
    public function getName($id)
    {
        $local = Local::find($id);
        if (!$local) {
            return response()->json(['name' => 'No encontrado'], 404);
        }
        return response()->json(['name' => $local->nombre]);
    }
    
    public function store(Request $request)
    {
        if(auth()->user()->created === 1){
           $local = Local::create([
                'nombre' => $request->nombre,
                'lat' => $request->lat,
                'lon' => $request->lon,
                'estado' => $request->estado,
                'state' => $request->state,
                'ciudad' => $request->ciudad,
                'owner' => auth()->user()->owner,
                'company_id' => auth()->user()->company_id,
                'phone' => $request->phone
            ]);
        }else{
            $local = Local::create([
                'nombre' => $request->nombre,
                'estado' => $request->estado,
                'state' => $request->state,
                'ciudad' => $request->ciudad,
                'owner' => auth()->user()->id,
                'company_id'=> auth()->user()->company_id,
                'phone' => $request->phone
            ]);
        }

        return response()->json(['success' => true, 'local' => $local]);
    }

    public function index(Request $request)
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->company_id === null){
            return redirect('/company');
        }

        if(auth()->user()->created === 23){
            $locals = Local::all();
            return view('admin.locals_admin', compact('locals'));
        }

        if( auth()->user()->created === 1){
            if( auth()->user()->local === null){
                $locals = Local::where('company_id', Auth::user()->company_id)->get();
                return view('locals', compact('locals'));
            }else{
                $locals = Local::where('company_id', Auth::user()->company_id)->get();
                return view('locals', compact('locals'));
            }
        }else{
            $locals = Local::where('company_id', Auth::user()->company_id)->where('id', auth()->user()->local)->get();
            return view('locals', compact('locals'));
        }

    }
    
    public function localtion(){
        $empresa = Empresas::findOrFail(auth()->user()->company_id);
        if($empresa->geo === "off"){
            return redirect('/dashboard');
        }else{
            return view('location');
        }
    }
    
    public function cars(){
        $pointers = Car::where('company_id', Auth::user()->company_id)->get();
        $empresa = Empresas::findOrFail(auth()->user()->company_id);
        if($empresa->geo === "off"){
            return redirect('/dashboard');
        }else{
            return view('car', compact('pointers'));
        }
    }
    
    public function carsCreate(Request $request){
          $cars = Car::create([
                'name' => $request->name,
                'code' => $request->code,
                'company_id' => auth()->user()->company_id, 
                'lat' => 0,
                'lon' => 0,
          ]);
          
          return response()->json(['success' => true, 'car' => $cars]);
    }
    
    public function carsDelete($id){
        $car = Car::findOrFail($id);
        $car->delete();

        return response()->json(['success' => true]);
    }
    
    public function localtionTracking(){
        $pointers = Car::where('company_id', Auth::user()->company_id)->get();
        return $pointers;
    }    
    
    public function getting(Request $request)

    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if( auth()->user()->created === 23){
            $locals = Local::all();
            return response()->json($locals);            
        }
        
        if( auth()->user()->created === 1 || auth()->user()->created === 23){
            if( auth()->user()->local === null){
                $locals = Local::where('company_id', Auth::user()->company_id)->get();
                return response()->json($locals);            
            }else{
                $locals = Local::where('company_id', Auth::user()->company_id)->get();
                return response()->json($locals);
            }
        }else{
            if( auth()->user()->local === null){
                $locals = Local::where('company_id', Auth::user()->company_id)->get();
                return response()->json($locals);   
            }else{
                $locals = Local::where('company_id', Auth::user()->company_id)->where('id', auth()->user()->local)->get();
                return response()->json($locals);
            }
        }
    }

    public function update(Request $request, $id)
    {
        $local = Local::findOrFail($id);
        $local->update($request->only('nombre', 'state', 'estado', 'ciudad', 'lat', 'lon', 'phone'));
        return response()->json(['local' => $local]);
    }

    public function find(Request $request)
    {
        $locals = Local::where('id', $request->idUser)->get();
        return response()->json($locals);
    }

    public function destroy($id)
    {
        $local = Local::findOrFail($id);
        $local->delete();

        return response()->json(['success' => true]);
    }
}
