    <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div x-data="{ open: false }" class="dark:text-gray-400 dark:bg-gray-800  rounded-lg shadow-sm mb-4 bg-white overflow-hidden">
            
            <!-- Botón del Acordeón -->
            <button @click="open = !open"
                class="w-full justify-between items-center px-4 py-3 bg-blue-100 hover:bg-blue-200 transition duration-200">
                <svg style="float:left !important;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25m18 0A2.25 2.25 0 0 0 18.75 3H5.25A2.25 2.25 0 0 0 3 5.25m18 0V12a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 12V5.25" />
                </svg>

                <span class="text-lg font-semibold text-gray-800"><?php echo e($machine->nombre); ?></span>
            </button>


            <!-- Contenido del Acordeón -->
            <div x-show="open" x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 max-h-0"
                x-transition:enter-end="opacity-100 max-h-screen"
                x-transition:leave="transition ease-in duration-200"
                x-transition:leave-start="opacity-100 max-h-screen"
                x-transition:leave-end="opacity-0 max-h-0"
                class="px-4 py-2 bg-white dark:text-gray-400 dark:bg-gray-800">

                <!-- Tabla de Máquinas con todos los campos -->
                <div class="overflow-x-auto text-white items-center" style="color:white !important;">
                    <div class="custom-box">
                        <h5 style="color:#c02a2a; border-bottom:2px solid #f3f3f3; padding:10px; padding-top:15%;  margin-bottom:10px; border-top-left-radius:15px; border-top-right-radius:15px;">
                            Verifica que los datos son correctos antes de hacer el jackpot.
                            <br>
                            Esta accion es irrevercible
                        </h5>

                        <button
                          onclick="confirmarPago(this)"
                          data-balance="<?php echo e($machine->balance); ?>"
                          data-ac1_1="<?php echo e($machine->acumulated1); ?>" data-ac1_2="<?php echo e($machine->acumulated1_2); ?>" data-ac1_3="<?php echo e($machine->acumulated1_3); ?>" data-ac1_4="<?php echo e($machine->acumulated1_4); ?>" data-ac1_5="<?php echo e($machine->acumulated1_5); ?>"
                          data-ac2_1="<?php echo e($machine->acumulated2); ?>" data-ac2_2="<?php echo e($machine->acumulated2_2); ?>" data-ac2_3="<?php echo e($machine->acumulated2_3); ?>" data-ac2_4="<?php echo e($machine->acumulated2_4); ?>" data-ac2_5="<?php echo e($machine->acumulated2_5); ?>"
                          data-ac3_1="<?php echo e($machine->acumulated3); ?>"  data-ac3_2="<?php echo e($machine->acumulated3_2); ?>" data-ac3_3="<?php echo e($machine->acumulated3_3); ?>" data-ac3_4="<?php echo e($machine->acumulated3_4); ?>" data-ac3_5="<?php echo e($machine->acumulated3_5); ?>"
                          data-mid="<?php echo e($machine->id); ?>"
                          data-pp="<?php echo e($machine->p_p); ?>"                    
                          style="margin-left: 25%; margin-top:8%;" class="configAcountBtn bg-blue-500 hover:from-blue-600 hover:blue-800 text-white font-bold py-2 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center gap-2">
                            
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor"
                                class="icon-move size-6 transition-all duration-300">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
                              </svg>

                              <span class="text-fade ml-2 transition-all duration-300">Pagar jackpots</span>
                        </button>
                    </div>
                </div>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/partials/local_tbody2.blade.php ENDPATH**/ ?>