@extends('layouts.app')
@section('content')
<div class="col-span-12 space-y-6 xl:col-span-7">
  <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6">
    <div class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-gray-100 dark:bg-gray-800">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 text-gray-800 dark:text-white/90">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25m18 0A2.25 2.25 0 0 0 18.75 3H5.25A2.25 2.25 0 0 0 3 5.25m18 0V12a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 12V5.25" />
          </svg>
        </div>


      <div class="mt-5 flex items-end justify-between">
        <div>
          <span class="text-sm text-gray-500 dark:text-gray-400">Maquinas</span>
          <h4 class="mt-2 text-title-sm font-bold text-gray-800 dark:text-white/90">
            {{$machines}}
          </h4>
        </div>
      <a href="/machines">
        <span class="flex items-center gap-1 rounded-full bg-success-50 py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-600 dark:bg-success-500/15 dark:text-success-500">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25m18 0A2.25 2.25 0 0 0 18.75 3H5.25A2.25 2.25 0 0 0 3 5.25m18 0V12a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 12V5.25" />
          </svg>


          Ver maquinas
        </span>
      </a>
      </div>
    </div>
    <!-- Metric Item End -->

    <!-- Metric Item Start -->
    <div class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-gray-100 dark:bg-gray-800">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 text-gray-800 dark:text-white/90">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 7.5L7.5 3m0 0L12 7.5M7.5 3v13.5m13.5 0L16.5 21m0 0L12 16.5m4.5 4.5V7.5" />
          </svg>
        </div>

    
      <div class="mt-5 flex items-end justify-between">
            <div>
              <span class="text-sm text-gray-500 dark:text-gray-400">Historial de Transacciones</span>
              <h4 id="numTransac" class="mt-2 text-title-sm font-bold text-gray-800 dark:text-white/90">
               {{$transactions}}
              </h4>
              <span class="text-sm text-gray-500 dark:text-gray-400">Este mes</span>
            </div>
          <a href="/transactionsDate">
            <span class="flex items-center gap-1 rounded-full bg-success-50 py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-600 dark:bg-success-500/15 dark:text-success-500">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5m.75-9 3-3 2.148 2.148A12.061 12.061 0 0 1 16.5 7.605" />
            </svg>
    
              Inspeccionar
            </span>
          </a>
      </div>
    </div>
    <!-- Metric Item End -->
  </div>
  <!-- Metric Group One -->
  <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6">
      <!-- Metric Item Start -->
      <div class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-gray-100 dark:bg-gray-800">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 text-gray-800 dark:text-white/90">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 21v-7.5a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349M3.75 21V9.349m0 0a3.001 3.001 0 0 0 3.75-.615A2.993 2.993 0 0 0 9.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 0 0 2.25 1.016c.896 0 1.7-.393 2.25-1.015a3.001 3.001 0 0 0 3.75.614m-16.5 0a3.004 3.004 0 0 1-.621-4.72l1.189-1.19A1.5 1.5 0 0 1 5.378 3h13.243a1.5 1.5 0 0 1 1.06.44l1.19 1.189a3 3 0 0 1-.621 4.72M6.75 18h3.75a.75.75 0 0 0 .75-.75V13.5a.75.75 0 0 0-.75-.75H6.75a.75.75 0 0 0-.75.75v3.75c0 .414.336.75.75.75Z" />
          </svg>
        </div>


        <div class="mt-5 flex items-end justify-between">
          <div>
            <span class="text-sm text-gray-500 dark:text-gray-400">Locales</span>
            <h4 class="mt-2 text-title-sm font-bold text-gray-800 dark:text-white/90">
              {{$locals}}
            </h4>
          </div>
        <a href="/admin/locals">
        <span class="flex items-center gap-1 rounded-full bg-success-50 py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-600 dark:bg-success-500/15 dark:text-success-500">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 21v-7.5a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349M3.75 21V9.349m0 0a3.001 3.001 0 0 0 3.75-.615A2.993 2.993 0 0 0 9.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 0 0 2.25 1.016c.896 0 1.7-.393 2.25-1.015a3.001 3.001 0 0 0 3.75.614m-16.5 0a3.004 3.004 0 0 1-.621-4.72l1.189-1.19A1.5 1.5 0 0 1 5.378 3h13.243a1.5 1.5 0 0 1 1.06.44l1.19 1.189a3 3 0 0 1-.621 4.72M6.75 18h3.75a.75.75 0 0 0 .75-.75V13.5a.75.75 0 0 0-.75-.75H6.75a.75.75 0 0 0-.75.75v3.75c0 .414.336.75.75.75Z" />
          </svg>
            Ver locales
          </span>
        </a>
        </div>
      </div>
      <!-- Metric Item End -->

      <!-- Metric Item Start -->
      <div class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-gray-100 dark:bg-gray-800">
          <svg class="fill-gray-800 dark:fill-white/90" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M11.665 3.75621C11.8762 3.65064 12.1247 3.65064 12.3358 3.75621L18.7807 6.97856L12.3358 10.2009C12.1247 10.3065 11.8762 10.3065 11.665 10.2009L5.22014 6.97856L11.665 3.75621ZM4.29297 8.19203V16.0946C4.29297 16.3787 4.45347 16.6384 4.70757 16.7654L11.25 20.0366V11.6513C11.1631 11.6205 11.0777 11.5843 10.9942 11.5426L4.29297 8.19203ZM12.75 20.037L19.2933 16.7654C19.5474 16.6384 19.7079 16.3787 19.7079 16.0946V8.19202L13.0066 11.5426C12.9229 11.5844 12.8372 11.6208 12.75 11.6516V20.037ZM13.0066 2.41456C12.3732 2.09786 11.6277 2.09786 10.9942 2.41456L4.03676 5.89319C3.27449 6.27432 2.79297 7.05342 2.79297 7.90566V16.0946C2.79297 16.9469 3.27448 17.726 4.03676 18.1071L10.9942 21.5857L11.3296 20.9149L10.9942 21.5857C11.6277 21.9024 12.3732 21.9024 13.0066 21.5857L19.9641 18.1071C20.7264 17.726 21.2079 16.9469 21.2079 16.0946V7.90566C21.2079 7.05342 20.7264 6.27432 19.9641 5.89319L13.0066 2.41456Z" fill=""></path>
          </svg>
        </div>

        <div class="mt-5 flex items-end justify-between">
          <div>
            <span class="text-sm text-gray-500 dark:text-gray-400">Juegos</span>
            <h4 class="mt-2 text-title-sm font-bold text-gray-800 dark:text-white/90">
              {{$games}}
            </h4>
          </div>
        <a href="/admin/games">
          <span class="flex items-center gap-1 rounded-full bg-success-50 py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-600 dark:bg-success-500/15 dark:text-success-500">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 0 0 .75-.75 2.25 2.25 0 0 0-.1-.664m-5.8 0A2.251 2.251 0 0 1 13.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25ZM6.75 12h.008v.008H6.75V12Zm0 3h.008v.008H6.75V15Zm0 3h.008v.008H6.75V18Z" />
            </svg>

            Ver juegos
          </span>
        </a>  
        </div>
      </div>
      <!-- Metric Item End -->
    </div>
                  <!-- ====== Chart One Start -->
  <div class="bg-gray-100 text-gray-900 dark:bg-gray-900 dark:text-gray-100">
    <div class="bg-white dark:bg-gray-800 rounded shadow p-4">
      <div class="w-full h-64 md:h-96">
        <canvas id="myChart" class="w-full h-full"></canvas>
      </div>
    </div>
  </div>
  
    <button id="toggleChartType" class="px-4 py-2 bg-green-500 rounded hover:bg-green-600">
        Cambiar a modo Line
    </button>
    <div class="flex flex-wrap" style="display: ruby;width: 80%;">
        <script>
        document.addEventListener('DOMContentLoaded', function () {
          // Configuraci車n com迆n para Flatpickr
          const commonOptions = {
            dateFormat: "Y-m-d",
            disableMobile: false,
            onOpen: function(selectedDates, dateStr, instance) {
              instance.calendarContainer.classList.add('animate__animated', 'animate__fadeInDown');
            },
            onClose: function(selectedDates, dateStr, instance) {
              instance.calendarContainer.classList.remove('animate__animated', 'animate__fadeInDown');
            }
          };
        
          flatpickr("#start_date", commonOptions);
          flatpickr("#end_date", commonOptions);
        });
        </script>
  <div class="container mx-auto p-6">

  </div>

  <script>
    var myChartInstance;
    var currentChartType = 'bar'; // Tipo inicial: 'bar' o 'line'

    function updateChart() {
      var startDate = $('#start_date').val();
      var endDate = $('#end_date').val();

      // Detectar si estamos en modo dark
      var isDark = document.documentElement.classList.contains('dark');
      var axisColor   = isDark ? 'white' : 'black';
      var gridColor   = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
      var legendColor = isDark ? 'white' : 'black';

      // Opciones para el tooltip
      var tooltipTitleColor = axisColor;
      var tooltipBodyColor  = axisColor;
      var tooltipBgColor    = isDark ? '#333' : '#fff';

      // Opciones para el dataset
      var datasetBgColor    = currentChartType === 'bar' ? 'rgba(66, 165, 245, 0.5)' : 'transparent';
      var datasetBorderColor = 'rgba(66, 165, 245, 1)';

      $.ajax({
        url: "{{ route('chart.data') }}",
        method: "GET",
        data: { start_date: startDate, end_date: endDate },
        success: function(data) {
           $("#numTransac").html(data.total_transactions);
            
          if (!data.dates || !data.balances) {
            console.error("Datos inválidos recibidos:", data);
            return;
          }
          
          // Destruir instancia previa si existe
          if (myChartInstance) {
            myChartInstance.destroy();
          }
          
          var ctx = document.getElementById('myChart').getContext('2d');
          myChartInstance = new Chart(ctx, {
            type: currentChartType,
            data: {
              labels: data.dates,
              datasets: [{
                label: 'Balance Diario',
                data: data.balances,
                backgroundColor: datasetBgColor,
                borderColor: datasetBorderColor,
                borderWidth: 1,
                fill: currentChartType === 'line' ? false : true
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true,
                  ticks: { color: '#728188a3' },
                  grid: { color: '#728188a3' }
                },
                x: {
                  ticks: { color: '#728188a3' },
                  grid: { color: '#728188a3' }
                }
              },
              plugins: {
                legend: {
                  labels: { color: '#728188a3' }
                },
                tooltip: {
                  titleColor: tooltipTitleColor,
                  bodyColor: tooltipBodyColor,
                  backgroundColor: tooltipBgColor
                }
              }
            }
          });
        },
        error: function(xhr, status, error) {
          console.error("Error en la petición AJAX:", error);
        }
      });
    }

    function toggleChartType() {
      if (currentChartType === 'bar') {
        currentChartType = 'line';
        $('#toggleChartType').text('Cambiar a modo Bar');
      } else {
        currentChartType = 'bar';
        $('#toggleChartType').text('Cambiar a modo Line');
      }
      updateChart();
    }

    $(document).ready(function() {
      updateChart();
      $('#updateChart').click(updateChart);
      $('#toggleChartType').click(toggleChartType);
    });
  </script>





@endsection
