<div id="createUserModal" class="fixed inset-0 hidden bg-gray-800 bg-opacity-50 flex justify-center items-center p-4" style="
    height: 100%;
    overflow-y: scroll;
    margin-top:45px;
" style="z-index:1000;">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg h-5/6 overflow-y-auto">
        <h2 class="text-xl font-bold mb-4 text-center">Registrar nuevo usuario</h2>
        <form id="createUserForm" class="space-y-4">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

            <div>
                <label class="block text-gray-700">Nombre</label>
                <input type="text" name="name" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>

            <div>
                <label class="block text-gray-700">Email</label>
                <input type="email" name="email" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>

            <div>
                <label class="block text-gray-700">Contraseña</label>
                <input type="password" name="password" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>

            <div>
                <label class="block text-gray-700">Rol</label>
                <select name="role" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="administrador">Administrador</option>
                    <option value="usuario">Usuario</option>
                </select>
            </div>
            
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Selecciona Locales
              </label>
            
              <!-- Contenedor donde aparecerán los tags seleccionados -->
              <div id="selected-locals" class="flex flex-wrap gap-2 mb-4"></div>
            
              <!-- Lista de todos los locales disponibles -->
              <ul id="locals-list" class="border border-gray-300 rounded p-2 max-h-56 overflow-y-auto bg-white shadow">
                <!-- Se llenará dinámicamente -->
              </ul>
            
              <!-- Input oculto donde guardaremos los IDs seleccionados separados por comas -->
              <input type="hidden" name="locals" id="local-ids">
            </div>
            
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" id="closeCreateModal" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>


<script>

    const csrfToken = $('meta[name="csrf-token"]').attr('content');
    let allLocals = [];      // locales traídos del backend
    let selectedLocals = []; // locales ya seleccionados

    // Renderiza la lista de sugerencias excluyendo los ya seleccionados
    function renderList() {
        const list = $('#locals-list').empty();
        allLocals.forEach(local => {
            if (!selectedLocals.some(sel => sel.id === local.id)) {
                list.append(`
                  <li class="px-3 py-2 hover:bg-blue-100 cursor-pointer"
                      data-id="${local.id}" data-name="${local.nombre}">
                    ${local.nombre}
                  </li>
                `);
            }
        });
    }

    // Renderiza los tags seleccionados y actualiza el hidden input
    function renderSelected() {
        const container = $('#selected-locals').empty();
        selectedLocals.forEach(local => {
            container.append(`
              <span class="bg-blue-100 text-blue-800 rounded-full px-3 py-1 text-sm flex items-center gap-2">
                ${local.nombre}
                <button type="button" class="remove-tag text-red-500" data-id="${local.id}">&times;</button>
              </span>
            `);
        });
        const ids = selectedLocals.map(l => l.id);
        $('#local-ids').val(ids.join(','));
    }

    // Carga inicial de todos los locales
    $.ajax({
        url: '/locals_getting',
        type: 'GET',
        data: {_token: csrfToken},
        success(response) {
            // Backend debe devolver el array tal cual lo muestras
            console.log(response)
            allLocals = response;
            renderList();
        },
        error() {
            alert('No se pudieron cargar los locales.');
        }
    });

    // Seleccionar un local
    $('#locals-list').on('click', 'li', function() {
        const id   = $(this).data('id');
        const nombre = $(this).data('name');
        selectedLocals.push({ id, nombre });
        renderSelected();
        renderList();
    });

    // Quitar un tag
    $('#selected-locals').on('click', '.remove-tag', function() {
        const id = $(this).data('id');
        selectedLocals = selectedLocals.filter(l => l.id !== id);
        renderSelected();
        renderList();
    });

    function assignActionListeners() {
        

        
        console.log($('.GGG .edit-btn'))
        $('.GGG .edit-btn').off('click').on('click', function () {
            
            
            const userId = $(this).data('user-id');
            const email = $(this).data('user-email');
            const role = $(this).data('user-role');
            const name = $(this).data('user-name');
            const ia_picture = $(this).data('user-ia_picture');
            const geo = $(this).data('user-geo');
            $('#editModal').removeClass('hidden');
            $('#name').val(name);
            $('#editUserId').val(userId);
            $('#email').val(email);
            $('#role').val(role);
            
                        
            console.log(ia_picture);
            console.log(geo);
            
            if (ia_picture !== 'on') {
                $('#iaBalance').prop('checked', false);
            } else {
                $('#iaBalance').prop('checked', true);
            }
            if (geo !== 'on') {
                $('#geolocation').prop('checked', false);
            } else {
                $('#geolocation').prop('checked', true);
            }

          let allLocalsUp      = [];  // vendrán de /get-locals
          let selectedLocalsUp = [];  // {id, nombre}
        
          // 1) Función para pintar la lista de locales disponibles
          function renderListUp() {
            const $list = $('#edit-locals-list').empty();
            allLocalsUp.forEach(loc => {
              if (!selectedLocalsUp.some(sel => sel.id === loc.id)) {
                $list.append(`
                  <li class="px-3 py-2 hover:bg-blue-100 cursor-pointer"
                      data-id="${loc.id}" data-nombre="${loc.nombre}">
                    ${loc.nombre}
                  </li>
                `);
              }
            });
          }
        
          // 2) Función para pintar los tags seleccionados y actualizar el hidden
          function renderSelectedUp() {
            const $sel = $('#edit-selected-locals').empty();
            selectedLocalsUp.forEach(loc => {
              $sel.append(`
                <span class="bg-blue-100 text-blue-800 rounded-full px-3 py-1 text-sm flex items-center gap-2">
                  ${loc.nombre}
                  <button type="button" class="remove-tag text-red-500" data-id="${loc.id}">&times;</button>
                </span>
              `);
            });
            const ids = selectedLocalsUp.map(l => l.id).join(',');
            $('#edit-local-ids').val(ids);
          }

          // 3) Carga inicial de todos los locales de la compañía
          const localsLoaded = $.ajax({
            url: '/locals_getting',
            type: 'GET',
            data: { _token: csrfToken }
          }).done(resp => {
              allLocalsUp = resp;    // tu array completo
              renderListUp();               // pinta la lista inicial
            }).fail(() => {
              alert('No se pudieron cargar los locales.');
            });
        
          // 4) Click en un local para seleccionarlo
          $('#edit-locals-list').on('click', 'li', function() {
            const id     = +$(this).data('id');
            const nombre = $(this).data('nombre');
            selectedLocalsUp.push({ id, nombre });
            renderSelectedUp();
            renderListUp();
          });
        
          // 5) Quitar un tag
          $('#edit-selected-locals').on('click', '.remove-tag', function() {
            const id = +$(this).data('id');
            selectedLocalsUp = selectedLocalsUp.filter(l => l.id !== id);
            renderSelectedUp();
            renderListUp();
          });

          function initLocalsUp(preIds) {
            selectedLocalsUp = allLocalsUp.filter(loc => preIds.includes(loc.id));
            renderSelectedUp();
            renderListUp();
          }

            $.get(`/gettingUpdate/${userId}`, function(res) {
              const preIds = res.user.local
                ? res.user.local.split(',').map(x => +x)
                : [];
                
              console.log(preIds)

              if (allLocalsUp.length === 0) {
                $(document).one('ajaxSuccess', () => initLocalsUp(preIds));
              } else {
                initLocalsUp(preIds);
              }

                localsLoaded.done(() => {
                  // Inicializo selectedLocals filtrando allLocals
                  selectedLocalsUp = allLocalsUp.filter(loc => preIds.includes(loc.id));
                  renderSelectedUp();
                  renderListUp();
                }); 

            });
                
            //---End Edit-btn
        });

        $('.GGG .delete-btn').off('click').on('click', function () {
            const userId = $(this).data('user-id');
            $('#deleteModal').removeClass('hidden');
            $('#deleteUserId').val(userId);
        });
    }

$(document).ready(function () {
    $('#editUserForm').on('submit', function (e) {
            e.preventDefault();
            const userId = $('#editUserId').val();

            
                let formData = $(this).serializeArray().reduce((obj, item) => {
                    obj[item.name] = item.value;
                    return obj;
                }, {});
            
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            $.ajax({
                url: `/users/${userId}`,
                method: 'PUT',
                data: formData,
                success: function (res) {
                    $('#editModal').addClass('hidden');
                   
                    $(`tr[data-user-id="${userId}"]`).html(`
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.name}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.email}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.role}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.local}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.company}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                            <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md mr-2 edit-btn" data-user-email="${res.user.email}"  data-user-role="${res.user.role}" data-user-name="${res.user.name}" data-user-id="${res.user.id}"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" /></svg></button>
                            <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md mr-2 delete-btn" data-user-id="${res.user.id}"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" /></svg></button>
                        </td>
                    `);
                     assignActionListeners();
                },
                error: function (xhr) {
                }
            });
        });

        $('#deleteUserForm').on('submit', function (e) {
            e.preventDefault();
            const userId = $('#deleteUserId').val();

            $.ajax({
                url: `/users/${userId}`,
                method: 'DELETE',
                data: $(this).serialize(),
                success: function (response) {
                    $('#deleteModal').addClass('hidden');
                    $(`tr[data-user-id="${userId}"]`).remove();
                    assignActionListeners()
                },
                error: function (xhr) {
                }
            });
        });

    // Abrir el modal y cargar datos dinámicos
    $('#openCreateModal').click(function () {
        let createInput1 = $("#localAdd");
        $.get('/locals_getting', function (data) {
            createInput1.empty(); // Limpiar opciones anteriores
            data.forEach(loc => {
                let rowLocal = `<option value="${loc.id}">${loc.nombre}</option>`;
                createInput1.append(rowLocal);
            });
        });

        $('#createUserModal').removeClass('hidden');
    });

    // Cerrar el modal
    $('#closeCreateModal').click(function () {
        $('#createUserModal').addClass('hidden');
    });

    // Enviar el formulario
    $('#createUserForm').submit(function (e) {
        e.preventDefault();
        $.ajax({
            url: '/users',  // Asegúrate de que esta ruta esté correctamente configurada en tu backend
            type: 'POST',
            data: $(this).serialize(),
            success: function (res) {
                let newRow = `
                    <tr class="GGG" data-user-id="${res.user.id}">
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.name}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.email}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.role}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.local}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.company}</td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                            <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn" data-user-id="${res.user.id}" data-user-name="${res.user.name}" data-user-email="${res.user.email}" data-user-role="${res.user.role}">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                                </svg>
                            </button>
                            <button class="bg-red-500 text-white px-3 py-1 rounded-md mr-2 delete-btn" data-user-id="${res.user.id}">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                </svg>
                            </button>
                        </td>
                    </tr>
                `;

                $('#users-table').append(newRow);
                assignActionListeners();
                $('#createUserModal').addClass('hidden');
            },
            error: function (xhr) {
                alert('Error al crear el usuario');
            }
        });
    });
});

window.onload = function() {
    setTimeout(assignActionListeners, 1000);
};
</script>
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/modals/create_user.blade.php ENDPATH**/ ?>