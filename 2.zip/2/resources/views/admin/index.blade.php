@extends('layouts.app')
@section('content')
<style>
    .M_E_p::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
        .pagination-btn {
            transition: background-color 0.3s ease;
        }
        .pagination-btn:hover {
            background-color: #2563eb; /* Cambia el color al pasar el mouse */
        }
        .pagination-btn.bg-blue-700 {
            background-color: #1e40af; /* Color para el botón activo */
        }        
</style>   

<div class="M_E_p">
   <div class="mb-4">
        <label for="searchInput" class="block text-gray-700 text-lg font-medium dark:text-gray-400">CLIENTES</label>
        <input style="color: #6b7c84 !important;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-3/5 h-8 px-4 py-2 mt-5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
        @if(auth()->user()->created === 23)
            <button id="openCreateModal" 
              class="bg-[#8a78f5] text-white px-4 py-2 rounded-md w-1/4 md:w-1/5 md:fixed md:bottom-6 md:right-6">
              NUEVO CLIENTE
            </button>
        @endif
    </div>
<style>
  .small-table {
      font-size: 12px; /* Reducir el tamaño de la fuente */
  }
  .small-table th, .small-table td {
      padding: 4px 8px; /* Reducir el padding */
  }
  .small-table th {
      white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
  }
  .small-table td {
      white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
  }
  .small-table {
      width: 100%; /* Ajustar el ancho de la tabla */
      overflow-x: auto; /* Permitir scroll horizontal si es necesario */
  }
  
  td{
      color: #6b7c84 !important;
  }
</style>
<script>
    let clientIdCoinsArrow = null;
    let companyIdCoinsArrow = null;

    function getCoins(company_id){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: `/companyKing/${company_id}`,
            method: 'GET',
            data: company_id,
            success: function (res) {
                console.log("dataaa ->  "+res.empresa.coins)
                $(`.coins-${company_id}`).html(res.empresa.coins)
                $(`.lastR-${company_id}`).html(res.empresa.last_recharge)
            },
            error: function (xhr) {console.log(xhr)}
        });
    }
</script>

<div class="overflow-x-auto">
  <table class="small-table min-w-full leading-normal text-center" style="min-width:100px;">
    <thead>
      <tr>
        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Nombre</th></center>
        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">correo</th></center>
        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">compañia</th></center>
        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Mensualidad</th></center>
        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Monedas</th></center>
        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider"></th></center>

        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Status</th></center>

        <center><th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-center text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">acciones</th></center>
      </tr>
    </thead>
    <tbody id="clients-table" class="dark:bg-gray-900">
      @foreach($users as $user)
      
      @php
        $lastRecharge = \Carbon\Carbon::parse($user->last_recharge);
        $now = \Carbon\Carbon::now();
      @endphp

        <tr class="GGG" data-client-id="{{ $user->id }}">
          <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
              {{ $user->name }}
          </td>
          <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
              {{ $user->email }}
          </td>
          <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
              {{ $user->company }}
          </td>
          
          <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
            <p class="lastR-{{ $user->company_id }}"></p>
          </td>
          
          <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
            <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-500 dark:text-success-400" style="margin-left:20px;">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-3-2.818.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                </svg>
                
                <p class="coins-{{ $user->company_id }}"></p>
            </span> 
             
            <script>
                getCoins(@json($user->company_id));
            </script>
          </td>
          <td class="items-center px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                <button 
                    class="openModalBtnAddmoney flex items-center gap-1 px-2 py-1 text-success-500 dark:text-success-400 rounded hover:text-l text-sm"
                    data-client-id="{{ $user->id }}" 
                    data-company-id="{{ $user->company_id }}">
                        
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                      <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 15 12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" />
                    </svg>

                </button>          
          </td>
          <td class="items-center px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
            <p class="items-center">
                @if ($lastRecharge->diffInDays($now) < 30)
                        <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-600  dark:text-success-500 text-center" style="margin-left:20%; text-align:center; width:120px;">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 0 0 6.16-12.12A14.98 14.98 0 0 0 9.631 8.41m5.96 5.96a14.926 14.926 0 0 1-5.841 2.58m-.119-8.54a6 6 0 0 0-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 0 0-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 0 1-2.448-2.448 14.9 14.9 0 0 1 .06-.312m-2.24 2.39a4.493 4.493 0 0 0-1.757 4.306 4.493 4.493 0 0 0 4.306-1.758M16.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z" />
                            </svg>
                
                            ACTIVO
                        </span>        
                @else
                        <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-orange-600  dark:text-orange-500 text-center" style="margin-left:20%; text-align:center; width:120px;">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.182 16.318A4.486 4.486 0 0 0 12.016 15a4.486 4.486 0 0 0-3.198 1.318M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Z" />
                          </svg>
                          INACTIVO
                        </span>                        
                @endif
            </p>
          </td>
          <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
              <!-- Botones de acciones -->
              <button class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn" data-client-company_id="{{ $user->company_id }}" data-client-ia_picture="{{ $user->ia_picture }}" data-client-geo="{{ $user->geo }}" data-client-email="{{ $user->email }}" data-client-name="{{ $user->name }}" data-client-id="{{ $user->id }}" style="margin-top:3px;">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                </svg>
              </button>
              <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-client-id="{{ $user->id }}" style="margin-top:3px;">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                  <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                </svg>
              </button>
          </td>
        </tr>
      @endforeach
      </tbody>
  </table>
</div>
</div>
<div id="pagination" class="flex justify-center mt-4"></div>

<!-- Modal Sum value-->
<div id="numberModal" class="fixed inset-0 z-50 hidden bg-black bg-opacity-50 flex items-center justify-center">
    <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-md transform scale-95 opacity-0 transition duration-300" id="modalContent">
        <h2 class="text-lg font-semibold mb-4">Suma o resta saldo de este cliente</h2>
        <form id="numberForm">
            <meta name="csrf-token" content="{{ csrf_token() }}">

            <input type="number" name="value" class="w-full border p-2 rounded mb-4" placeholder="número para sumar o restar saldo" required>
            <div id="responseMsg" class="text-sm text-red-600 hidden mb-2"></div>
            <div class="flex justify-end space-x-2">
                <button type="button" id="closeModalBtn" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancelar</button>
                <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Enviar</button>
            </div>
        </form>
    </div>
</div>


@include('admin.modals.edit')
@include('admin.modals.delete')

@include('admin.modals.create_company')

<script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#closeModalBtn').click(function () {
            $('#modalContent').removeClass('scale-100 opacity-100').addClass('scale-95 opacity-0');
            setTimeout(() => {
                $('#numberModal').addClass('hidden');
                $('#responseMsg').addClass('hidden').text('');
                $('#numberForm')[0].reset();
            }, 300);
        });

        $('#numberForm').submit(function (e) {
            e.preventDefault();

            const value = $(this).find('input[name="value"]').val();

            $.post('/admin/update-coins', {
                value: value,
                client_id: clientIdCoinsArrow,
                company_id: companyIdCoinsArrow
            })
            .done(function (res) {
                $('#responseMsg')
                    .removeClass('hidden text-red-600')
                    .addClass('text-green-600')
                    .text('Enviado con éxito ✅');

                setTimeout(() => {
                    $('#closeModalBtn').click();
                }, 800);
                getCoins(companyIdCoinsArrow);
            })
            .fail(function (xhr) {
                $('#responseMsg')
                    .removeClass('hidden text-green-600')
                    .addClass('text-red-600')
                    .text('Error al enviar 😞');

                $('#modalContent')
                    .addClass('shake border-red-300 bg-red-50');

                setTimeout(() => {
                    $('#modalContent').removeClass('shake border-red-300 bg-red-50');
                }, 500);
            });
        });

    const rowsPerPage = 10; 
    const $rows = $('#users-table tr.GGG'); 
    const totalRows = $rows.length; 
    const totalPages = Math.ceil(totalRows / rowsPerPage); 

    function showPage(page) {
        $rows.hide(); 
        $rows.slice((page - 1) * rowsPerPage, page * rowsPerPage).show(); 
    }

    function createPaginationButtons() {
        let buttons = '';
        for (let i = 1; i <= totalPages; i++) {
            buttons += `<button class="px-4 py-2 mx-1 bg-blue-500 text-white rounded-md pagination-btn" data-page="${i}">${i}</button>`;
        }
        $('#pagination').html(buttons);
    }

    showPage(1);
    createPaginationButtons();

    $('#pagination').on('click', '.pagination-btn', function () {
        const page = $(this).data('page'); 
        showPage(page); 

        $('.pagination-btn').removeClass('bg-blue-700').addClass('bg-blue-500');
        $(this).removeClass('bg-blue-500').addClass('bg-blue-700');
    });

    $("#searchInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#users-table tr").filter(function() {
            $(this).toggle(
                $(this).find("td:nth-child(0)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(4)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(1)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(3)").text().toLowerCase().indexOf(value) > -1   
            );
        });
    });

    $('.close-modal').on('click', function () {
        $(this).closest('#editModal').addClass('hidden');
        $(this).closest('#deleteModal').addClass('hidden');
        $(this).closest('#viewTransactionsModal').addClass('hidden');
    });

</script>

@endsection
