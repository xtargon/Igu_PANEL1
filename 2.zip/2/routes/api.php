use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\APIController;

Route::get('/api/post', [APIController::class, 'store']);
