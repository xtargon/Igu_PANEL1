<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction; 

class TransactionDateController extends Controller
{
    /**
     * Muestra la vista con el formulario de búsqueda.
     */
    public function index()
    {
        return view('transactions.index');
    }

    /**
     * Procesa la búsqueda de transacciones en el rango de fechas.
     */
    public function search(Request $request)
    {
        $start_date = $request->input('start_date');
        $end_date   = $request->input('end_date');

        $transactions = Transaction::whereBetween('fecha', [$start_date, $end_date])->get();

        return view('transactions.index', compact('transactions', 'start_date', 'end_date'));
    }
}
