

<?php $__env->startSection('content'); ?>
<div class="p-8">

    <label for="searchInput" class="block text-gray-700 text-lg font-medium dark:text-gray-400">PLANES</label>
    <input style="color: #6b7c84 !important;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-3/5 h-8 px-4 py-2 mt-5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required="">
        
    <button style="margin-top: 18px;float:right;" id="openCreateModal"
        class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition">
        Crear Nuevo Plan
    </button>

    <div id="plansContainer" class="grid md:grid-cols-3 gap-6">
        
    </div>

    <div id="paginationLinks" class="mt-6 flex justify-center"></div>
</div>

<!-- Fragmento Card -->
<script type="text/template" id="plan-card-template">
    <div style="margin-top:50px;" class="bg-white dark:bg-gray-900 p-6 rounded-2xl shadow-xl hover:shadow-2xl transition cursor-pointer border border-gray-100 dark:border-gray-700"
        onclick="openEditModal(__ID__)">
        <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-400">__NAME__</h3>
        <p class="text-gray-500 dark:text-gray-400 mt-2">Máquinas: __MACHINES__</p>
        <p class="text-gray-500 dark:text-gray-400">Locales: __LOCALS__</p>
        <p class="text-gray-500 dark:text-gray-400">Precio: __PRICE__</p>
        <button onclick="event.stopPropagation(); openDeleteModal(__ID__)"
            class="mt-4 px-4 py-1 text-sm bg-red-500 text-white rounded hover:bg-red-600 transition">
            Eliminar
        </button>
    </div>
</script>


<!-- Modales -->

<!-- Crear -->
<div id="createModal" class="modal hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-md shadow-xl animate-fadeIn">
        <h2 class="text-xl font-bold mb-4">Crear Plan</h2>
        <form id="createForm">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-gray-700">Nombre para el plan</label>
                <input type="text" name="name" required class="input w-full">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Precio por Máquinas</label>
                <input type="number" name="machines" required class="input w-full" placeholder="valor por maquina">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Precio por Locales</label>
                <input type="number" name="locals" required class="input w-full" placeholder="valor por local">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Precio base</label>
                <input type="number" name="price" required class="input w-full" placeholder="valor base para este plan">
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" onclick="closeModals()" class="btn-cancel">Cancelar</button>
                <button type="submit" class="btn-save">Guardar</button>
            </div>
        </form>
    </div>
</div>

<!-- Editar -->
<div id="editModal" class="modal hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-md shadow-xl animate-fadeIn">
        <h2 class="text-xl font-bold mb-4">Editar Plan</h2>
        <form id="editForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" id="editPlanId">
            <div class="mb-4">
                <label class="block text-gray-700">Nombre</label>
                <input type="text" name="name" id="editName" required class="input w-full">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Máquinas</label>
                <input type="number" name="machines" id="editMachines" required class="input w-full">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Locales</label>
                <input type="number" name="locals" id="editLocals" required class="input w-full">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Precio</label>
                <input type="number" name="price" id="editPrice" required class="input w-full">
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" onclick="closeModals()" class="btn-cancel">Cancelar</button>
                <button type="submit" class="btn-save">Actualizar</button>
            </div>
        </form>
    </div>
</div>

<!-- Eliminar -->
<div id="deleteModal" class="modal hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-md shadow-xl animate-fadeIn">
        <h2 class="text-xl font-bold mb-4">Eliminar Plan</h2>
        <p class="mb-4 text-gray-600">¿Estás seguro que deseas eliminar este plan?</p>
        <form id="deleteForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="hidden" id="deletePlanId">
            <div class="flex justify-end space-x-2">
                <button type="button" onclick="closeModals()" class="btn-cancel">Cancelar</button>
                <button type="submit" class="btn-delete">Eliminar</button>
            </div>
        </form>
    </div>
</div>

<style>
.input {
    @apply px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500;
}
.btn-save {
    @apply px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition;
}
.btn-cancel {
    @apply px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500 transition;
}
.btn-delete {
    @apply px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition;
}
.modal {
    animation: fadeIn 0.3s ease-in-out forwards;
}
@keyframes fadeIn {
    from {opacity: 0; transform: scale(0.95);}
    to {opacity: 1; transform: scale(1);}
}
</style>

<script>
$(document).ready(function () {
    loadPlans();

    function renderCard(plan) {
        let template = $('#plan-card-template').html();
        return template
            .replace(/__ID__/g, plan.id)
            .replace(/__NAME__/g, plan.name)
            .replace(/__MACHINES__/g, plan.machines)
            .replace(/__LOCALS__/g, plan.locals)
            .replace(/__PRICE__/g, plan.price);
    }

    function loadPlans(page = 1, query = '') {
        $.get(`/plans-data?page=${page}&q=${query}`, function (data) {
            let html = '';
            data.plans.forEach(plan => {
                html += renderCard(plan);
            });
            $('#plansContainer').html(html);
            $('#paginationLinks').html(data.paginationHtml);
        });
    }

    $('#searchInput').on('keyup', function () {
        const query = $(this).val();
        loadPlans(1, query);
    });

    $(document).on('click', '.pagination a', function (e) {
        e.preventDefault();
        const page = $(this).attr('href').split('page=')[1];
        const query = $('#searchInput').val();
        loadPlans(page, query);
    });

    $('#createForm').submit(function(e) {
        e.preventDefault();
        $.post(`/plan`, $(this).serialize(), function () {
            closeModals();
            loadPlans();
        });
    });

    $('#editForm').submit(function(e) {
        e.preventDefault();
        let id = $('#editPlanId').val();
        $.ajax({
            url: `/plan/${id}`,
            method: 'PUT',
            data: $(this).serialize(),
            success: function () {
                closeModals();
                loadPlans();
            }
        });
    });

    $('#deleteForm').submit(function(e) {
        e.preventDefault();
        let id = $('#deletePlanId').val();
        $.ajax({
            url: `/plan/${id}`,
            method: 'DELETE',
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function () {
                closeModals();
                loadPlans();
            }
        });
    });

    $('#openCreateModal').click(() => $('#createModal').removeClass('hidden'));
    window.openEditModal = function(id) {
        $.get(`/plan/${id}`, function(data) {
            $('#editPlanId').val(id);
            $('#editName').val(data.name);
            $('#editMachines').val(data.machines);
            $('#editLocals').val(data.locals);
            $('#editPrice').val(data.price);
            $('#editModal').removeClass('hidden');
        });
    };
    window.openDeleteModal = function(id) {
        $('#deletePlanId').val(id);
        $('#deleteModal').removeClass('hidden');
    };
    window.closeModals = function() {
        $('.modal').addClass('hidden');
    };
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/plans/index.blade.php ENDPATH**/ ?>