@extends('layouts.app')
@section('content')

<!-- Tailwind CSS -->
<script src="https://cdn.tailwindcss.com"></script>
<!-- Alpine.js -->
<script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Formulario de Filtro (centrado) -->
<div class="flex justify-center mb-6">
<div class="p-5 w-full bg-white dark:bg-gray-900 shadow rounded">
    <form id="filterForm" method="GET" action="{{ route('transactions.filter') }}" class="text-center">
      <!-- Contenedor general con flex responsivo -->
      <div class="flex flex-col md:flex-row md:items-center md:space-x-4">
        <!-- Select -->
        <div class="mb-6 md:mb-0 md:mr-auto">
          <label for="filter_option" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Filtrar por:</label>
          <select style="color: #6b7c84 !important;" name="filter_option" id="filter_option" class="mt-1 block w-4/5 md:w-auto md:min-w-[185px] border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-200 rounded-md shadow-sm text-center px-4 py-2">
            <option style="color: #6b7c84 !important;" value="custom" selected>Fechas Personalizadas</option>
            <option style="color: #6b7c84 !important;" value="today">Hoy</option>
            <option style="color: #6b7c84 !important;" value="yesterday">Ayer</option>
            <option style="color: #6b7c84 !important;" value="this_week">Esta Semana</option>
            <option style="color: #6b7c84 !important;" value="this_month">Este Mes</option>
            <option style="color: #6b7c84 !important;" value="last_month">Último Mes</option>
          </select>
        </div>

        <!-- Inputs de Fecha -->
        <div class="flex flex-row items-center justify-center w-4/5 mx-auto space-x-4">
          <div id="custom_dates" class="w-[31%]">
            <label for="start_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Fecha inicio:</label>
            <input type="date" name="start_date" id="start_date" class="mt-1 block w-full border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-200 rounded-md shadow-sm" placeholder="YYYY-MM-DD">
          </div>
          <div id="custom_dates_end" class="w-[31%]">
            <label for="end_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Fecha fin:</label>
            <input type="date" name="end_date" id="end_date" class="mt-1 block w-full border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-200 rounded-md shadow-sm" placeholder="YYYY-MM-DD">
          </div>
        </div>

        <script>
          document.addEventListener('DOMContentLoaded', function () {
            const commonOptions = {
              dateFormat: "Y-m-d",
              disableMobile: true,
              onOpen: function(selectedDates, dateStr, instance) {
                instance.calendarContainer.classList.add('animate__animated', 'animate__fadeInDown');
              },
              onClose: function(selectedDates, dateStr, instance) {
                instance.calendarContainer.classList.remove('animate__animated', 'animate__fadeInDown');
              }
            };
          
            flatpickr("#start_date", commonOptions);
            flatpickr("#end_date", commonOptions);
          });
        </script>

        <!-- Botón de Filtrar -->
        <div class="w-2/5 mx-auto mt-4">
          <button type="submit" class="w-full px-4 py-2 bg-blue-600 dark:bg-blue-700 text-white rounded-md shadow flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5 mr-2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 3c2.755 0 5.455.232 8.083.678.533.09.917.556.917 1.096v1.044a2.25 2.25 0 0 1-.659 1.591l-5.432 5.432a2.25 2.25 0 0 0-.659 1.591v2.927a2.25 2.25 0 0 1-1.244 2.013L9.75 21v-6.568a2.25 2.25 0 0 0-.659-1.591L3.659 7.409A2.25 2.25 0 0 1 3 5.818V4.774c0-.54.384-1.006.917-1.096A48.32 48.32 0 0 1 12 3Z" />
            </svg>
            Filtrar
          </button>
        </div>
      </div>
    </form>
  </div>
</div>


<!-- Contenedor para los locales (se actualizará vía AJAX) -->
<div id="localesContainer" class="paginated-locales w-full bg-white dark:bg-gray-900 shadow rounded p-[10px]">
  @include('transactions.partials.locales', ['locales' => $locales, 'overallSum' => $overallSum])
</div>

<script>
    function reload() {
        const $container = $("#localesContainer");
        
        $container.empty();
        $container.addClass("animate-pulse bg-gray-100");
        
        setTimeout(() => {
                $.ajax({
                    url: "/buss/reload",
                    type: "GET",
                    success: function (data) {
                        $container.html(data.html);
                    },
                    error: function () {
                        $container.html("<p class='text-red-500'>Error al cargar los locales.</p>");
                    },
                    complete: function () {
                        $container.removeClass("animate-pulse bg-gray-100");
                        Swal.fire({
                          title: "Transacción registrada",
                          icon: "success",
                          draggable: true
                        });
                    }
                });
        }, 100); 
    }


    // Mostrar/Ocultar fechas personalizadas
    $('#filter_option').change(function() {
      if ($(this).val() === 'custom') {
        $('#custom_dates, #custom_dates_end').removeClass('hidden');
      } else {
        $('#custom_dates, #custom_dates_end').addClass('hidden');
      }
    });

    // Envío del formulario vía AJAX
    $('#filterForm').submit(function(e) {
      e.preventDefault();
      var formData = $(this).serialize();
      $.ajax({
        url: $(this).attr('action'),
        type: 'GET',
        data: formData,
        success: function(response) {
          $('#localesContainer').html(response.html);
          setupPagination(); // Reinicializa la paginación
        },
        error: function() {
          alert('Error al filtrar los datos.');
        }
      });
    });

    // Función de paginación
    function setupPagination() {
      let locales = $('.paginated-locales > .local-item');
      let perPage = 10;
      let totalPages = Math.ceil(locales.length / perPage);
      let currentPage = 1;
      
      function showPage(page) {
        locales.hide();
        locales.slice((page - 1) * perPage, page * perPage).show();
      }
      
      showPage(currentPage);
      
      $('.pagination').remove();
      let pagination = $('<div class="pagination flex justify-center space-x-2 mt-4"></div>');
      for (let i = 1; i <= totalPages; i++) {
        let pageBtn = $('<button class="px-3 py-1 text-sm bg-blue-500 text-white rounded">' + i + '</button>');
        pageBtn.click(function() {
          currentPage = i;
          showPage(currentPage);
        });
        pagination.append(pageBtn);
      }
      $('.paginated-locales').after(pagination);
    }

    setupPagination();
    
        let currentModalData = {
            buttonData: null,
            paramsForSendTransaction: null
        };

        function sendTransaction(docData){
            console.log(docData)
            var url = 'https://iguentertainment.com/api_insert.php?' + $.param(docData);
                                
            $.ajax({
                url: url,
                type: 'GET',
                success: function (response) {
                    $('#image').val('');
                    $('#modalContent').removeClass('scale-100 opacity-100').addClass('scale-90 opacity-0');
                    setTimeout(() => {
                        $('#modalOverlay').addClass('hidden');
                        
                    }, 300);
                    reload();
                },
                error: function (xhr, status, error) {
                    console.error('❌ Error al enviar los datos:', error);
                }
            });            
            
        }

        
</script>

@endsection








