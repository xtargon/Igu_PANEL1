<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Iniciar sesion')</title>
    <link rel="shortcut icon" href="{{ asset('assets/img/fav.png') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/cssTailPanel.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.1/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.1/dist/flowbite.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

    <script src="https://cdn.tailwindcss.com"></script>

    <script src="{{ asset('assets/js/scripts.js') }}" defer></script>

    <link rel="icon" href="favicon.ico">
    <link href="{{ asset('assets/css/cssTailPanel.css') }}" rel="stylesheet">
    <script data-cfasync="false" nonce="7302b8b6-0677-4bbb-91f2-8a67e3a65fa3">try{(function(w,d){!function(j,k,l,m){if(j.zaraz)console.error("zaraz is loaded twice");else{j[l]=j[l]||{};j[l].executed=[];j.zaraz={deferred:[],listeners:[]};j.zaraz._v="5850";j.zaraz._n="7302b8b6-0677-4bbb-91f2-8a67e3a65fa3";j.zaraz.q=[];j.zaraz._f=function(n){return async function(){var o=Array.prototype.slice.call(arguments);j.zaraz.q.push({m:n,a:o})}};for(const p of["track","set","debug"])j.zaraz[p]=j.zaraz._f(p);j.zaraz.init=()=>{var q=k.getElementsByTagName(m)[0],r=k.createElement(m),s=k.getElementsByTagName("title")[0];s&&(j[l].t=k.getElementsByTagName("title")[0].text);j[l].x=Math.random();j[l].w=j.screen.width;j[l].h=j.screen.height;j[l].j=j.innerHeight;j[l].e=j.innerWidth;j[l].l=j.location.href;j[l].r=k.referrer;j[l].k=j.screen.colorDepth;j[l].n=k.characterSet;j[l].o=(new Date).getTimezoneOffset();if(j.dataLayer)for(const t of Object.entries(Object.entries(dataLayer).reduce(((u,v)=>({...u[1],...v[1]})),{})))zaraz.set(t[0],t[1],{scope:"page"});j[l].q=[];for(;j.zaraz.q.length;){const w=j.zaraz.q.shift();j[l].q.push(w)}r.defer=!0;for(const x of[localStorage,sessionStorage])Object.keys(x||{}).filter((z=>z.startsWith("_zaraz_"))).forEach((y=>{try{j[l]["z_"+y.slice(7)]=JSON.parse(x.getItem(y))}catch{j[l]["z_"+y.slice(7)]=x.getItem(y)}}));r.referrerPolicy="origin";r.src="cdn-cgi/zaraz/sd0d9.js?z="+btoa(encodeURIComponent(JSON.stringify(j[l])));q.parentNode.insertBefore(r,q)};["complete","interactive"].includes(k.readyState)?zaraz.init():j.addEventListener("DOMContentLoaded",zaraz.init)}}(w,d,"zarazData","script");window.zaraz._p=async bs=>new Promise((bt=>{if(bs){bs.e&&bs.e.forEach((bu=>{try{const bv=d.querySelector("script[nonce]"),bw=bv?.nonce||bv?.getAttribute("nonce"),bx=d.createElement("script");bw&&(bx.nonce=bw);bx.innerHTML=bu;bx.onload=()=>{d.head.removeChild(bx)};d.head.appendChild(bx)}catch(by){console.error(`Error executing script: ${bu}\n`,by)}}));Promise.allSettled((bs.f||[]).map((bz=>fetch(bz[0],bz[1]))))}bt()}));zaraz._p({"e":["(function(w,d){})(window,document)"]});})(window,document)}catch(e){throw fetch("/cdn-cgi/zaraz/t"),e;};</script>
    </head>
    <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script defer src="{{ asset('assets/js/bundle.js') }}"></script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"9125748e7e97a699","version":"2025.1.0","r":1,"serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"67f7a278e3374824ae6dd92295d38f77","b":1}' crossorigin="anonymous"></script>
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<style>
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-5px); }
        40% { transform: translateX(5px); }
        60% { transform: translateX(-5px); }
        80% { transform: translateX(5px); }
    }

    .shake {
        animation: shake 0.5s ease;
    }

    .bg-error-light {
        background-color: #fee2e2 !important;
    }
</style>
<body x-data="{ page: 'ecommerce', 'loaded': true, 'darkMode': false, 'stickyMenu': false, 'sidebarToggle': false, 'scrollTop': false }" x-init="
         darkMode = JSON.parse(localStorage.getItem('darkMode'));
         $watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{'dark bg-gray-900': darkMode === true}">
    <div class="flex justify-center items-center min-h-screen px-4" style=""> 
  
        <div class="relative z-1 flex h-screen w-full overflow-hidden bg-white px-4 py-6 dark:bg-gray-900 sm:p-0">
        <div class="flex flex-1 flex-col rounded-2xl p-6 sm:rounded-none sm:border-0 sm:p-8">

            <div class="mx-auto flex w-full max-w-md flex-1 flex-col justify-center">
            <div>
                <div class="mb-5 sm:mb-8">
                <h1 class="mb-2 text-title-sm font-semibold text-gray-800 dark:text-white/90 sm:text-title-md">
                    Iniciar sesion
                </h1>
                <p class="text-sm text-gray-500 dark:text-gray-400">
                </p>
                </div>
                <div>
                 <div x-data="{ hasError: {{ session('login_error') ? 'true' : 'false' }} }">
                <form id="loginForm"
                    class="rounded-xl p-4 transition duration-300 ease-in-out border border-transparent">
                    <div class="space-y-5">
                        @csrf
                        <meta name="csrf-token" content="{{ csrf_token() }}">

                        <div>
                            <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                Correo<span class="text-error-500">*</span>
                            </label>
                            <input style="background:white;" type="email" name="email" placeholder="info@gmail.com"
                                class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-none focus:ring focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                required>
                        </div>
                
                        <div>
                            <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                Contraseña<span class="text-error-500">*</span>
                            </label>
                            <div x-data="{ showPassword: false }" class="relative">
                                <input style="background:white;" name="password" :type="showPassword ? 'text' : 'password'" placeholder="Enter your password"
                                    class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-4 pr-11 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-none focus:ring focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                    required>
                                <span @click="showPassword = !showPassword"
                                    class="absolute right-4 top-1/2 z-30 -translate-y-1/2 cursor-pointer text-gray-500 dark:text-gray-400">
                                    {{-- Iconos omitidos por brevedad --}}
                                </span>
                            </div>
                        </div>
                
                        <div>
                            <button type="submit"
                                class="flex w-full items-center justify-center rounded-lg bg-brand-500 px-4 py-3 text-sm font-medium text-white shadow-theme-xs transition hover:bg-brand-600">
                                Entrar
                            </button>
                        </div>
                
                        <div id="loginError" class="text-sm text-red-600 mt-2 hidden"></div>
                    </div>
                </form>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="relative z-1 hidden flex-1 items-center justify-center bg-brand-950 p-8 dark:bg-white/5 lg:flex">
<style>
    @keyframes gradient {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
    .animate-gradient {
      background-size: 200% 200%;
      animation: gradient 5s ease infinite;
    }

    /* Animación de partículas flotantes */
    @keyframes float {
      0% { transform: translateY(0) translateX(0); opacity: 0.2; }
      50% { transform: translateY(-20px) translateX(20px); opacity: 0.4; }
      100% { transform: translateY(0) translateX(0); opacity: 0.2; }
    }
    .animate-float {
      animation: float 6s ease-in-out infinite;
    }
    .animation-delay-2000 {
      animation-delay: 2s;
    }
    .animation-delay-4000 {
      animation-delay: 4s;
    }

    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-5px); }
        40% { transform: translateX(5px); }
        60% { transform: translateX(-5px); }
        80% { transform: translateX(5px); }
    }

    .shake {
        animation: shake 0.5s ease;
    }

    .bg-error-light {
        background-color: #fee2e2; /* rojo claro */
    }
</style>
  
  
        <div class="flex justify-center items-center min-h-screen bg-gradient-to-r from-purple-900 via-indigo-900 to-blue-900 p-6">
            <div style="width: 420;" class="card relative w-full max-w-md h-[500px] bg-white rounded-3xl overflow-hidden shadow-2xl transform transition-all duration-500 hover:scale-105">
            <div class="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-500 opacity-75 animate-gradient"></div>
            
            <div class="relative z-10 flex flex-col justify-center items-center h-full p-8 text-center">
                <div class="mb-6">

                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 200 200"
                    class="w-28 h-28 rounded-full border-4 border-white shadow-lg transform transition-all duration-300 hover:scale-110"
                    >
                    <!-- Fondo circular con gradiente -->
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#6D28D9;stop-opacity:1" />
                        <stop offset="100%" style="stop-color:#4C1D95;stop-opacity:1" />
                        </linearGradient>
                    </defs>
                    <circle cx="100" cy="100" r="95" fill="url(#gradient)" stroke="#FFFFFF" stroke-width="4" />

                    <rect x="60" y="60" width="80" height="80" rx="15" fill="#FFFFFF" />
                    <circle cx="75" cy="75" r="8" fill="#6D28D9" />
                    <circle cx="125" cy="75" r="8" fill="#6D28D9" />
                    <circle cx="75" cy="125" r="8" fill="#6D28D9" />
                    <circle cx="125" cy="125" r="8" fill="#6D28D9" />
                    <circle cx="100" cy="100" r="8" fill="#6D28D9" />

                    <text
                        x="100"
                        y="170"
                        font-size="24"
                        font-weight="bold"
                        fill="#FFFFFF"
                        text-anchor="middle"
                        font-family="Arial, sans-serif"
                    >
                        IGU
                    </text>
                    </svg>

                </div>
                
                <h1 class="text-5xl font-bold text-white mb-2 transform transition-all duration-300 hover:scale-105" style="color: #222742;">IGU</h1>
                <p class="text-2xl font-semibold text-white opacity-90 mb-6" style="color: #222742;">ENTERTAINMENT</p>
            </div>
            
            <div class="absolute inset-0 overflow-hidden">
                <div class="particle absolute w-2 h-2 bg-white rounded-full opacity-20 animate-float" style="top: 10%; left: 20%;"></div>
                <div class="particle absolute w-3 h-3 bg-white rounded-full opacity-30 animate-float animation-delay-2000" style="top: 30%; left: 70%;"></div>
                <div class="particle absolute w-2 h-2 bg-white rounded-full opacity-25 animate-float animation-delay-4000" style="top: 70%; left: 40%;"></div>
            </div>
            </div>
        </div>
        </div>
    </div>
    
    <script>
    $(document).ready(function () {
        $('#loginForm').on('submit', function (e) {
            e.preventDefault();

            const form = $(this);
            const url = "{{ route('login') }}";
            const data = form.serialize();

            // Limpiar errores anteriores
            $('#loginError').addClass('hidden').text('');
            form.removeClass('shake bg-error-light border-red-300');
            
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: url,
                method: 'POST',
                data: data,
                success: function (response) {
                    if(response.log == 'no'){
                        $('#loginError').removeClass('hidden').text('Correo o contraseña incorrectos.');
    
                        form.addClass('shake bg-error-light border-red-300');
    
                        setTimeout(() => {
                            form.removeClass('shake');
                        }, 500);
                    }
                    if(response.log !== 'no'){
                        window.location.href = response.redirect ?? '/dashboard';
                    }
                    
                    
                },
                error: function (xhr) {

                }
            });
        });
    });
</script>
</body>