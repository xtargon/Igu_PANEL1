<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Game;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class GameController extends Controller
{
    
    public function getName($id)
    {
        $juego = Game::find($id);
        if (!$juego) {
            return response()->json(['name' => 'No encontrado'], 404);
        }
        return response()->json(['name' => $juego->nombre]);
    }
    
    public function store(Request $request)
    {
        if(auth()->user()->created === 1){
            $game = Game::create([
                'nombre' => $request->nombre,
                'fabricante' => $request->fabricante,
                'matematica' => $request->matematica,
                'owner' => auth()->user()->company_id,
                'state' => $request->state
            ]);
        }else{
            $game = Game::create([
                'nombre' => $request->nombre,
                'fabricante' => $request->fabricante,
                'matematica' => $request->matematica,
                'owner' => auth()->user()->company_id,
                'state' => $request->state
            ]);
        }
        
        return response()->json(['success' => true, 'game' => $game]);
    }

    public function index(Request $request)
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if(auth()->user()->role !== 'administrador'){
            return redirect('/dashboard');
        }

        $games = Game::where('owner', Auth::user()->company_id)->get();
        return view('games', compact('games'));
    }

    public function getting(Request $request)
    {
        if(auth()->user()->role === 'administrador'){
            if( auth()->user()->created === 23){
                $G_all = Game::all();
                $totalGames = $G_all->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalGames,
                    'games' => $G_all
                ]);          
            }
            
            if(auth()->user()->created === 1){
                $Games = Game::where('owner', auth()->user()->company_id)->get();
                $totalGames = $Games->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalGames,
                    'games' => $Games
                ]);
            }else{
                $games = Game::where('owner', auth()->user()->company_id)->get();
                $totalGames = $games->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalGames,
                    'games' => $games
                ]);
            }
        }else{
            return redirect('/dashboard');
        }
    }

    public function update(Request $request, $id)
    {
        $games = Game::findOrFail($id);
        $games->update($request->only('nombre', 'fabricante', 'matematica', 'owner', 'state'));
        return response()->json(['game' => $games]);
    }

    public function find(Request $request)
    {
        $games = Game::where('id', $request->idUser)->get();
        return response()->json($games);
    }

    public function destroy($id)
    {
        $games = Game::findOrFail($id);
        $games->delete();

        return response()->json(['success' => true]);
    }


    
}

