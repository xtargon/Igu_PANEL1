@extends('layouts.app')
@section('content')
<style>
    .M_E_p::-webkit-scrollbar {
          width: 10px; 
    }
    .M_E_p::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
    }
    .M_E_p::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
    }
    .M_E_p::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
    }
    .pagination-btn {
        transition: background-color 0.3s ease;
    }
    .pagination-btn:hover {
        background-color: #2563eb;
    }
    .pagination-btn.bg-blue-700 {
        background-color: #1e40af;
    }
    .small-table {
        font-size: 12px;
        width: 100%;
        overflow-x: auto;
    }
    .small-table th, .small-table td {
        padding: 4px 8px;
        white-space: nowrap;
    }
    td {
        color: #6b7c84 !important;
    }
</style>

<div class="M_E_p p-4">
    <div class="mb-4">
        <label for="searchInput" class="block text-gray-700 text-lg font-medium">AUTOMÓVILES</label>
        <input style="color: #6b7c84 !important;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-3/5 h-8 px-4 py-2 mt-5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
    </div>

    <div class="overflow-x-auto">
      <table class="small-table min-w-full leading-normal">
          <thead>
              <tr>
                  <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">PLACA DEL AUTO</th>
                  <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">NOMBRE DEL AUTO</th>
                  <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">ELIMINAR AUTO</th>
              </tr>
          </thead>
          <tbody id="games-table" class="dark:border-gray-800 dark:bg-gray-900">
              @foreach($pointers as $car)
                  <tr class="GGG" data-car-id="{{ $car->id }}">
                      <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                          {{ $car->code }}
                      </td>
                      <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                          {{ $car->name }}
                      </td>
                      <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                          <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-car-id="{{ $car->id }}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                              </svg>
                          </button>
                      </td>
                  </tr>
              @endforeach
          </tbody>
      </table>
    </div>
    <div id="pagination" class="flex justify-center mt-4"></div>
</div>

@include('admin.modals.delete')

<div class="max-w-xl mx-auto p-6">
    <h2 class="text-2xl font-bold mb-6 text-gray-900 dark:text-gray-100">Registrar Carro</h2>
    <form id="carForm" class="space-y-4">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <!-- Código -->
        <div>
            <label for="code" class="block text-sm font-medium text-gray-900 dark:text-gray-300">Código</label>
            <div class="relative">
                <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                    <!-- Heroicon: Hashtag -->
                    <svg class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4V20M17 4V20M3 10h18M3 14h18"></path>
                    </svg>
                </span>
                <input type="text" id="code" name="code" placeholder="Código del carro" required 
                  class="w-full pl-10 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
        </div>
        
        <!-- Nombre -->
        <div>
            <label for="name" class="block text-sm font-medium text-gray-900 dark:text-gray-300">Nombre</label>
            <div class="relative">
                <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                    <!-- Heroicon: Tag -->
                    <svg class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h10a2 2 0 012 2v10a2 2 0 01-2 2H7a2 2 0 01-2-2V5a2 2 0 012-2z"></path>
                    </svg>
                </span>
                <input type="text" id="name" name="name" placeholder="Nombre del carro" required 
                  class="w-full pl-10 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
        </div>
        
        <button type="submit" class="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
            Registrar
        </button>
    </form>
    <!-- Mensajes de respuesta -->
    <div id="message" class="mt-4 text-center"></div>
</div>

<script>
$(document).ready(function() {

    // Registro del carro mediante AJAX
    $('#carForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        
        $.ajax({
            url: '/cars',
            type: 'POST',
            data: formData,
            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
            success: function(response) {
                var car = response.car;
                var newRow = `
                  <tr class="GGG" data-car-id="${car.id}">
                      <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                          ${car.code}
                      </td>
                      <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                          ${car.name}
                      </td>
                      <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                          <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-car-id="${car.id}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                              </svg>
                          </button>
                      </td>
                  </tr>
                `;
                $('#games-table').append(newRow);
                $('#message').html('<p class="text-green-500">Carro registrado exitosamente.</p>');
                $('#carForm')[0].reset();
            },
            error: function(xhr, status, error) {
                $('#message').html('<p class="text-red-500">Ocurrió un error al registrar el carro.</p>');
            }
        });
    });

    // Eliminación del carro
    $('.delete-btn').off('click').on('click', function () {
        const carID = $(this).data('car-id');
        $('#deleteModal').removeClass('hidden');
        $('#deleteUserId').val(carID);
    });
    
    $('#deleteUserForm').on('submit', function (e) {
        e.preventDefault();
        const carID = $('#deleteUserId').val();

        $.ajax({
            url: `/car/${carID}`,
            method: 'DELETE',
            data: { _token: '{{ csrf_token() }}' },
            success: function (response) {
                $('#deleteModal').addClass('hidden');
                $(`tr[data-car-id="${carID}"]`).remove();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
            }
        });
    });
    
    $('.close-modal').on('click', function () {
        $(this).closest('#editModal, #deleteModal').addClass('hidden');
    });

    // Paginación
    const rowsPerPage = 10;
    const $rows = $('#games-table tr.GGG');
    const totalRows = $rows.length;
    const totalPages = Math.ceil(totalRows / rowsPerPage);

    function showPage(page) {
        $rows.hide();
        $rows.slice((page - 1) * rowsPerPage, page * rowsPerPage).show();
    }

    function createPaginationButtons() {
        let buttons = '';
        for (let i = 1; i <= totalPages; i++) {
            buttons += `<button class="px-4 py-2 mx-1 bg-blue-500 text-white rounded-md pagination-btn" data-page="${i}">${i}</button>`;
        }
        $('#pagination').html(buttons);
    }

    showPage(1);
    createPaginationButtons();

    $('#pagination').on('click', '.pagination-btn', function () {
        const page = $(this).data('page');
        showPage(page);
        $('.pagination-btn').removeClass('bg-blue-700').addClass('bg-blue-500');
        $(this).removeClass('bg-blue-500').addClass('bg-blue-700');
    });

    // Buscador de la tabla
    $("#searchInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#games-table tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });
});
</script>
@endsection
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/cars.blade.php ENDPATH**/ ?>