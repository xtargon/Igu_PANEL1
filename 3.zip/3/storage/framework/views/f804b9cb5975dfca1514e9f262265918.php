<meta charset="UTF-8">

<div id="createClientModal" class="fixed inset-0 hidden bg-gray-800 bg-opacity-50 flex justify-center items-center p-4" style="
    height: 100%;
    overflow-y: scroll;
    margin-top:45px;
" style="z-index:1000;">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg h-5/6 overflow-y-auto">
        <h2 class="text-xl font-bold mb-4 text-center">Registrar nuevo cliente y compañia</h2>

        <form id="createClientForm" class="space-y-4">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        
            <?php
                $inputClasses = 'w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500';
            ?>
        
            <div>
                <label class="block text-gray-700">Nombre</label>
                <input type="text" name="name" class="<?php echo e($inputClasses); ?>" required>
            </div>
        
            <div>
                <label class="block text-gray-700">Email</label>
                <input type="email" name="email" class="<?php echo e($inputClasses); ?>" required>
            </div>
        
            <div>
                <label class="block text-gray-700">Compañia</label>
                <input type="text" name="company" class="<?php echo e($inputClasses); ?>" required>
            </div>
        
            <div>
                <label class="block text-gray-700">Cuota mensual en monedas</label>
                <select id="plan_id_created" name="share"
                        class="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring focus:border-blue-500">
                    <option value="">Cargando planes...</option>
                </select>
            </div>
        
            <div>
                <label class="block text-gray-700">Monedas</label>
                <input type="number" name="coins" class="<?php echo e($inputClasses); ?>" required>
            </div>
        
            <div>
                <label class="block text-gray-700">Pais</label>
                <select id="countrySelect" name="address" class="<?php echo e($inputClasses); ?>" required>
                  <!-- Am���rica Latina y el Caribe -->
                  <option value="Spain">Spain</option>
                  <option value="United States">United States</option>
                  <option value="Mexico">Mexico</option>
                  <option value="Argentina">Argentina</option>
                  <option value="Colombia">Colombia</option>
                  <option value="Chile">Chile</option>
                  <option value="Peru">Peru</option>
                  <option value="Venezuela">Venezuela</option>
                  <option value="Ecuador">Ecuador</option>
                  <option value="Uruguay">Uruguay</option>
                  <option value="Paraguay">Paraguay</option>
                  <option value="Bolivia">Bolivia</option>
                  <option value="Brazil">Brazil</option>
                  <option value="Cuba">Cuba</option>
                  <option value="Dominican Republic">Dominican Republic</option>
                  <option value="Puerto Rico">Puerto Rico</option>
                  <option value="Costa Rica">Costa Rica</option>
                  <option value="Panama">Panama</option>
                  <option value="Guatemala">Guatemala</option>
                  <option value="Honduras">Honduras</option>
                  <option value="El Salvador">El Salvador</option>
                  <option value="Nicaragua">Nicaragua</option>
                  <option value="Belize">Belize</option>
                  <option value="Jamaica">Jamaica</option>
                  <option value="Haiti">Haiti</option>
                  <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                  <option value="Suriname">Suriname</option>
                  <option value="Guyana">Guyana</option>
                  <option value="French Guiana">French Guiana</option>
                  <option value="Barbados">Barbados</option>
                  <option value="St. Lucia">St. Lucia</option>
                  <option value="St. Vincent and the Grenadines">St. Vincent and the Grenadines</option>
                  <option value="Grenada">Grenada</option>
                  <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                  <option value="Dominica">Dominica</option>
                  <option value="Bahamas">Bahamas</option>
                  <option value="Bermuda">Bermuda</option>
                  <option value="Brazil - Acre">Brazil - Acre</option>
                  <option value="Brazil - Campo Grande">Brazil - Campo Grande</option>
                  <option value="Brazil - Manaus">Brazil - Manaus</option>
                  <option value="Brazil - Cuiaba">Brazil - Cuiaba</option>
                  <option value="Brazil - Fortaleza">Brazil - Fortaleza</option>
                  <option value="Argentina - Cordoba">Argentina - Cordoba</option>
                  <option value="Argentina - Mendoza">Argentina - Mendoza</option>
                  <option value="Chile - Punta Arenas">Chile - Punta Arenas</option>
                  <option value="Mexico - Hermosillo">Mexico - Hermosillo</option>
                  <option value="Ecuador - Galapagos">Ecuador - Galapagos</option>
                  <option value="Brazil - Belem">Brazil - Belem</option>
                  <option value="Argentina - La Rioja">Argentina - La Rioja</option>
                  <option value="Chile - Easter Island">Chile - Easter Island</option>
                  <!-- Pa���ses europeos -->
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="Germany">Germany</option>
                  <option value="France">France</option>
                  <option value="Italy">Italy</option>
                  <option value="Netherlands">Netherlands</option>
                  <option value="Sweden">Sweden</option>
                  <option value="Norway">Norway</option>
                  <option value="Poland">Poland</option>
                  <option value="Turkey">Turkey</option>
                  <option value="Russia">Russia</option>
                  <!-- Pa���ses asi���ticos -->
                  <option value="China">China</option>
                  <option value="Japan">Japan</option>
                  <option value="India">India</option>
                  <option value="South Korea">South Korea</option>
                  <option value="Singapore">Singapore</option>
                  <option value="Indonesia">Indonesia</option>
                  <option value="Thailand">Thailand</option>
                  <option value="Vietnam">Vietnam</option>
                  <option value="Malaysia">Malaysia</option>
                  <option value="United Arab Emirates">United Arab Emirates</option>
                </select>
            </div>
        
            <div>
                <label class="block text-gray-700">Telefono</label>
                <input type="tel" name="telefono" class="<?php echo e($inputClasses); ?>" required>
            </div>
        
            <div>
                <label class="block text-gray-700">Contraseña</label>
                <input type="password" name="password" class="<?php echo e($inputClasses); ?>" required>
            </div>
        
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" id="closeCreateModal" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>

    </div>
</div>

<script>

    function loadPlansSelect() {
        $.get('/api/planes', function (planes) {
            let options = '<option value="">-- Selecciona un plan --</option>';
            planes.forEach(function (plan) {
                options += `<option value="${plan.id}">${plan.name}</option>`;
            });
            $('#plan_id').html(options);
            $('#plan_id_created').html(options);
        });
    }

$(document).ready(function () {
    function assignActionListeners() {
        
        $('.GGG .openModalBtnAddmoney').off('click').on('click', function () {
            clientIdCoinsArrow = $(this).data('client-id');
            companyIdCoinsArrow = $(this).data('company-id');

            $('#numberModal').removeClass('hidden');
            setTimeout(() => {
                $('#modalContent').removeClass('scale-95 opacity-0').addClass('scale-100 opacity-100');
            }, 10);
        });
        
        $('.GGG .edit-btn').off('click').on('click', function () {
            const clientId = $(this).data('client-id');
            const email = $(this).data('client-email');
            const name = $(this).data('client-name');
            const ia_picture = $(this).data('client-ia_picture');
            const geo = $(this).data('client-geo');      
            const company_id = $(this).data('client-company_id');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: `/companyKing/${company_id}`,
                method: 'GET',
                data: company_id,
                success: function (res) {
                    $('#current_plan_id').val(res.empresa.share)
                    if (res.empresa.ia_picture !== 'on') {
                        $('#iaBalance').prop('checked', false);
                    } else {
                        $('#iaBalance').prop('checked', true);
                    }                    
                    if (res.empresa.geo !== 'on') {
                        $('#geolocation').prop('checked', false);
                    } else {
                        $('#geolocation').prop('checked', true);
                    }
                    
                    const address = res.empresa.direccion ;
                    $('#countrySelectUp option').each(function(){
                      if ($(this).text().trim() === address) {
                        $(this).prop('selected', true);
                        return false; 
                      }
                    });
                    $('#countrySelectUp').trigger('change');                    
                    
                    
                    function loadPlansSelect() {
                        let selectedPlanId = $('#current_plan_id').val();

                        $.get('/api/planes', function (planes) {
                            let options = '<option value="">-- Selecciona un plan --</option>';
                            planes.forEach(function (plan) {
                                let selected = plan.id == selectedPlanId ? 'selected' : '';
                                options += `<option value="${plan.id}" ${selected}>${plan.name}</option>`;
                            });
                            $('#plan_id').html(options);
                        });
                    }
                
                    loadPlansSelect();
                },
                error: function (xhr) {console.log(xhr)}
            });

            $('#editModal').removeClass('hidden');
            $('#name').val(name);
            $('#editUserId').val(clientId);
            $('#email').val(email);
        
        });

        $('.GGG .delete-btn').off('click').on('click', function () {
            const clientId = $(this).data('client-id');
            $('#deleteModal').removeClass('hidden');
            console.log("client"+clientId)
            $('#deleteUserId').val(clientId);
        });
    }

    $('#editUserForm').on('submit', function (e) {
        e.preventDefault();
        const clientId = $('#editUserId').val();

                let formData = $(this).serializeArray().reduce((obj, item) => {
                    obj[item.name] = item.value;
                    return obj;
                }, {});
            
                formData.ia_picture = $('#iaBalance').is(':checked') ? 'on' : 'off';
                formData.geo = $('#geolocation').is(':checked') ? 'on' : 'off';
                console.log(formData);
            
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

        $.ajax({
            url: `/admin/clients/${clientId}`,
            method: 'POST',
            data: formData,
            success: function (res) {
                $('#editModal').addClass('hidden');
        
                let lastRechargeStr = res.client.last_recharge;
                let lastRechargeDate = new Date(lastRechargeStr);
                let now = new Date();
                let diffMs = now - lastRechargeDate;
                let diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        
                // Define el HTML para la condicional de estado.
                let statusHTML = "";
                if (diffDays < 30) {
                    statusHTML = `
                        <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-600 dark:text-success-500 text-center" style="margin-left:20%; text-align:center; width:120px;">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 0 0 6.16-12.12A14.98 14.98 0 0 0 9.631 8.41m5.96 5.96a14.926 14.926 0 0 1-5.841 2.58m-.119-8.54a6 6 0 0 0-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 0 0-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 0 1-2.448-2.448 14.9 14.9 0 0 1 .06-.312m-2.24 2.39a4.493 4.493 0 0 0-1.757 4.306 4.493 4.493 0 0 0 4.306-1.758M16.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z" />
                            </svg>

                            ACTIVO
                        </span>
                    `;
                } else {
                    statusHTML = `
                        <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-orange-600 dark:text-orange-500 text-center" style="margin-left:20%; text-align:center; width:120px;">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M15.182 16.318A4.486 4.486 0 0 0 12.016 15a4.486 4.486 0 0 0-3.198 1.318M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Z" />
                            </svg>

                            INACTIVO
                        </span>
                    `;
                }
        
                let updatedRow = `
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        ${res.client.name}
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        ${res.client.email}
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        ${res.client.company}
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="lastR-${res.client.company_id}"></p>
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-500 dark:text-success-400" style="margin-left:20px;">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-3-2.818.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                            </svg>

                            <p class="coins-${res.client.company_id}"></p>
                        </span>
                    </td>
                      <td class="items-center px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                            <button 
                                class="openModalBtnAddmoney flex items-center gap-1 px-2 py-1 text-success-500 dark:text-success-400 rounded hover:text-l text-sm"
                                data-client-id="${res.client.id}" 
                                data-company-id="${res.client.company_id}">
                                    
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 15 12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" />
                                </svg>
            
                            </button>          
                      </td>                    
                    <td class="items-center px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="items-center">
                            ${statusHTML}
                        </p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <button class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn"
                            data-client-id="${res.client.id}"
                            data-client-name="${res.client.name}"
                            data-client-email="${res.client.email}"
                            data-client-company_id="${res.client.company_id}"
                            data-client-ia_picture="${res.client.ia_picture || ''}"
                            data-client-geo="${res.client.geo || ''}">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                            </svg>
                        </button>
                        <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-client-id="${res.client.id}" style="margin-top:3px;">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"/>
                            </svg>
                        </button>
                    </td>
                `;
                
                $(`tr[data-client-id="${clientId}"]`).html(updatedRow);
                $('#editUserForm')[0].reset();
                
                getCoins(res.client.company_id);
                assignActionListeners();
            },
            error: function (xhr) {}
        });
    });

    $('#deleteUserForm').on('submit', function (e) {
        e.preventDefault();
        const clientId = $('#deleteUserId').val();
        console.log(clientId)
        $.ajax({
            url: `/clients/${clientId}`,
            method: 'DELETE',
            data: $(this).serialize(),
            success: function () {
                $('#deleteModal').addClass('hidden');
                $(`tr[data-client-id="${clientId}"]`).remove();
                $('deleteClientForm').trigger('reset');
                assignActionListeners();
            },
            error: function (xhr) {}
        });
    });

    $('#openCreateModal').click(function () {
        let createInput = $("#companyAdd");
        $.get('/companies_getting', function (data) {
            createInput.empty();
            data.forEach(company => {
                let rowCompany = `<option value="${company.id}">${company.nombre}</option>`;
                createInput.append(rowCompany);
            });
        });
        loadPlansSelect();
        $('#createClientModal').removeClass('hidden');
    });

    $('#closeCreateModal').click(function () {
        $('#createClientModal').addClass('hidden');
    });

$('#createClientForm').submit(function (e) {
    e.preventDefault();

    $.ajax({
        url: '/clients',
        type: 'POST',
        data: $(this).serialize(),
        success: function (res) {
            let newRow = `
                <tr class="GGG" data-user-id="${res.client.id}">
                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        ${res.client.name}
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        ${res.client.email}
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        ${res.client.company}
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        <p class="lastR-${res.client.company_id}"></p>
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-500 dark:text-success-400" style="margin-left:20px;">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-3-2.818.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                        </svg>

                            <p class="coins-${res.client.company_id}"></p>
                        </span>
                    </td>
                      <td class="items-center px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                            <button 
                                class="openModalBtnAddmoney flex items-center gap-1 px-2 py-1 text-success-500 dark:text-success-400 rounded hover:text-l text-sm"
                                data-client-id="${res.client.id}" 
                                data-company-id="${res.client.company_id}">
                                    
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 15 12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" />
                                </svg>
            
                            </button>          
                      </td>                    

                    <td class="items-center px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        <p class="items-center">
                            <!-- Se asume que se determina el estado "ACTIVO" o "INACTIVO" desde el servidor -->
                            <span class="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-2.5 text-sm font-medium text-success-600 dark:text-success-500 text-center" style="margin-left:20%; text-align:center; width:120px;">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 0 0 6.16-12.12A14.98 14.98 0 0 0 9.631 8.41m5.96 5.96a14.926 14.926 0 0 1-5.841 2.58m-.119-8.54a6 6 0 0 0-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 0 0-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 0 1-2.448-2.448 14.9 14.9 0 0 1 .06-.312m-2.24 2.39a4.493 4.493 0 0 0-1.757 4.306 4.493 4.493 0 0 0 4.306-1.758M16.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z" />
                                </svg>
    
                                ACTIVO
                            </span>      
                        </p>
                    </td>
                    <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                        <button class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn"
                            data-client-company_id="${res.client.company_id}"
                            data-client-ia_picture="${res.client.ia_picture || ''}"
                            data-client-geo="${res.client.geo || ''}"
                            data-client-email="${res.client.email}"
                            data-client-name="${res.client.name}"
                            data-client-id="${res.client.id}">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                            </svg>

                        </button>
                        <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-client-id="${res.client.id}" style="margin-top:3px;">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                            </svg>
                        </button>
                    </td>
                </tr>
            `;
            
            getCoins(res.client.company_id);
            $('#createClientForm')[0].reset();
            $('#clients-table').append(newRow);
            assignActionListeners();
            $('#createClientModal').addClass('hidden');
        },
        error: function (xhr) {
            alert('Error al crear el cliente');
        }
    });
});

    assignActionListeners();
});
</script>
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/modals/create_company.blade.php ENDPATH**/ ?>