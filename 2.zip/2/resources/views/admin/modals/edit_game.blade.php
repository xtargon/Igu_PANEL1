<!-- Modal de Editar Juego -->
<div style="
    height: 100%;
    overflow-y: scroll;
    margin-top:45px;
" id="editModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-xl font-bold mb-4 text-center">Editar Juego</h2>

        <form id="editGameForm" class="space-y-4">
            <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <input type="hidden" id="editGameId" name="game_id">

            <div>
                <label for="nombre" class="block text-sm font-medium text-gray-700">Nombre</label>
                <input type="text" id="nombre" name="nombre" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2" required>
            </div>

            <div>
                <label for="fabricante" class="block text-sm font-medium text-gray-700">Fabricante</label>
                <input type="text" id="fabricante" name="fabricante" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2" required>
            </div>

            <div>
                <label for="matematica" class="block text-sm font-medium text-gray-700">Matemática</label>
                <input type="text" id="matematica" name="matematica" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2" required>
            </div>

            <div>
                <label for="state" class="block text-sm font-medium text-gray-700">Estado</label>
                <select name="state" id="state" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                </select>
            </div>

            <!-- Botones -->
            <div class="flex justify-center space-x-4">
                <button type="button" class="close-modal bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>
