
<?php $__env->startSection('content'); ?>
<div class="M_T_S bg-white shadow-md rounded-lg overflow-x-auto" style="margin: 55px; padding:10px;">

<div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
     <div class="space-y-6">
       <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="max-w-4xl mx-auto bg-white shadow-md rounded-lg overflow-hidden">
        <!-- Título de la lista -->
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-xl font-semibold text-gray-800"><?php echo e(auth()->user()->company); ?></h2>
        </div>

        <!-- Lista de datos -->
        <ul class="divide-y divide-gray-200">

            <li class="p-6 hover:bg-gray-50 transition duration-200">
                <div class="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-6">
                    <!-- Icono -->
                    <div class="flex-shrink-0">
                        <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 21v-8.25M15.75 21v-8.25M8.25 21v-8.25M3 9l9-6 9 6m-1.5 12V10.332A48.36 48.36 0 0 0 12 9.75c-2.551 0-5.056.2-7.5.582V21M3 21h18M12 6.75h.008v.008H12V6.75Z" />
                        </svg>
                    </div>

                    <div class="flex-1">
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div>
                                <p class="text-sm font-medium text-gray-500">Nombre</p>
                                <p class="text-lg font-semibold text-gray-900"><?php echo e($company->nombre); ?></p>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-500">Dirección</p>
                                <p class="text-lg text-gray-900"><?php echo e($company->direccion); ?></p>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-500">Teléfono</p>
                                <p class="text-lg text-gray-900"><?php echo e($company->telefono); ?></p>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-500">Sector</p>
                                <p class="text-lg text-gray-900"><?php echo e($company->sector); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </div>

    <div class="space-y-6">
        <button id="openModal" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
            </svg>
            <p>Editar</p>
        </button>
        <a href="/admin/machines" style="margin-top:2%; display:inline-block;">
            <button style="margin-top:2%; display:inline-block;" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" />
                </svg>
                Transacciones
            </button>
            
        </a>
        <a href="/admin/logs" style="margin-top:2%; display:inline-block;">
            <button style="margin-top:2%; display:inline-block;" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z" />
                </svg>
                 Logs
            </button>
           
        </a>
    </div>

    <script>
        $(document).ready(function () {
            $('#openModal').click(function () {
                $('#editModal').removeClass('hidden'); 
                $('#editModal > div').addClass('slide-down'); 
            });

            // Cerrar modal con animación
            $('#closeModal').click(function () {
                $('#editModal > div').addClass('slide-up'); 
                setTimeout(function () {
                    $('#editModal').addClass('hidden'); 
                    $('#editModal > div').removeClass('slide-up slide-down'); 
                }, 300); 
            });

            // Enviar formulario con AJAX
            $('#editForm').submit(function (e) {
                e.preventDefault(); 

                const formData = {
                    nombre: $('#nombre').val(),
                    direccion: $('#direccion').val(),
                    telefono: $('#telefono').val(),
                    sector: $('#sector').val(),
                    owner: $('#owner').val(),
                };

                $.ajax({
                    url: 'https://ejemplo.com/api/actualizar', 
                    method: 'POST',
                    data: formData,
                    success: function (response) {
                        alert('Datos actualizados correctamente');
                        $('#editModal > div').addClass('slide-up'); 
                        setTimeout(function () {
                            $('#editModal').addClass('hidden');
                            $('#editModal > div').removeClass('slide-up slide-down'); 
                        }, 300);
                    },
                    error: function (xhr, status, error) {
                        alert('Error al actualizar los datos');
                    }
                });
            });
        });
    </script>
    </div>
</div>
</div>
    <!-- Modal -->
    <div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-lg shadow-lg w-full max-w-md transform transition-all">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-xl font-semibold text-gray-800">Editar Datos</h2>
            </div>

            <form id="editForm" class="p-6">
                <div class="mb-4">
                    <label for="nombre" class="block text-sm font-medium text-gray-700">Nombre</label>
                    <input type="text" id="nombre" name="nombre" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                </div>

                <div class="mb-4">
                    <label for="direccion" class="block text-sm font-medium text-gray-700">Dirección</label>
                    <input type="text" id="direccion" name="direccion" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                </div>

                <div class="mb-4">
                    <label for="telefono" class="block text-sm font-medium text-gray-700">Teléfono</label>
                    <input type="text" id="telefono" name="telefono" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                </div>

                <div class="mb-4">
                    <label for="sector" class="block text-sm font-medium text-gray-700">Sector</label>
                    <input type="text" id="sector" name="sector" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                </div>

                <div class="mb-4">
                    <label for="owner" class="block text-sm font-medium text-gray-700">Owner</label>
                    <input type="text" id="owner" name="owner" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                </div>

                <div class="flex justify-end space-x-4">
                    <button type="button" id="closeModal" class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600">
                        Cancelar
                    </button>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                        Guardar
                    </button>
                </div>
            </form>
        </div>

<script>
$(document).ready(function () {
    $('.edit-btn').on('click', function () {
        const userId = $(this).data('user-id');
        const email = $(this).data('user-email');
        const role = $(this).data('user-role');
        const name = $(this).data('user-name');
        $('#editModal').removeClass('hidden');
        $('#name').val(name);
        $('#editUserId').val(userId);
        $('#email').val(email);
        $('#role').val(role);
    });

    $('#editUserForm').on('submit', function (e) {
        e.preventDefault();
        const userId = $('#editUserId').val();

        $.ajax({
            url: `/users/${userId}`,
            method: 'PUT',
            data: $(this).serialize(),
            success: function (res) {
                alert('Usuario actualizado correctamente.');
                $('#editModal').addClass('hidden');

                $(`tr[data-user-id="${userId}"]`).html(`
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.name}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.email}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.role}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.local}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.user.company}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <button class="bg-blue-500 text-white px-3 py-1 rounded-md mr-2 edit-btn" data-user-email="${res.user.email}"  data-user-role="${res.user.role}" data-user-name="${res.user.role}" data-user-id="${res.user.id}">Editar</button>
                        <button class="bg-red-500 text-white px-3 py-1 rounded-md mr-2 delete-btn" data-user-id="${res.user.id}">Eliminar</button>
                        <button class="bg-green-500 text-white px-3 py-1 rounded-md view-transactions-btn" data-local-id="${res.user.local}">Ver Transacciones</button>
                    </td>
                `);
            },
            error: function (xhr) {
                alert('Error al actualizar el usuario.');
            }
        });
    });

    $('.delete-btn').on('click', function () {
        const userId = $(this).data('user-id');
        $('#deleteModal').removeClass('hidden');
        $('#deleteUserId').val(userId);
    });

    $('#deleteUserForm').on('submit', function (e) {
        e.preventDefault();
        const userId = $('#deleteUserId').val();

        $.ajax({
            url: `/users/${userId}`,
            method: 'DELETE',
            data: $(this).serialize(),
            success: function (response) {
                alert('Usuario eliminado correctamente.');
                $('#deleteModal').addClass('hidden');
            },
            error: function (xhr) {
                alert('Error al eliminar el usuario.');
            }
        });
    });

    $('.view-transactions-btn').on('click', function () {
        var localId = $(this).data('local-id');
        var URLs = `/machines/local/${localId}/`;

        $('#viewTransactionsModal').removeClass('hidden');

        function loadTransactions(M){
          console.log(M[0].id)
          var URLsM = `/transactions/${M[0].id}/`;

         $.ajax({
              url: URLsM,
              method: 'GET',
              success: function (res) {
                  if (res.transaction && res.transaction.length > 0) {
                      $('#transactionsList').html('');

                      let table = `
                          <table class="min-w-full bg-white">
                              <thead>
                                  <tr>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">ID</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Total IN</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Total OUT</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Balance Total</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Balance Parcial</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">IN Parcial</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">OUT Parcial</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">% Pago</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
                                  </tr>
                              </thead>
                              <tbody>
                      `;

                      res.transaction.forEach(function (transaction) {
                          table += `
                              <tr>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.id}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.total_in}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.total_out}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.total_balance}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_balance}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_in}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_out}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.percentage_pay}%</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.fecha}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">
                                      <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-transaction-btn" data-transaction-id="${transaction.id}">Eliminar</button>
                                  </td>
                              </tr>
                          `;
                      });

                      table += `
                              </tbody>
                          </table>
                      `;

                      $('#transactionsList').html(table);

                      $('.delete-transaction-btn').on('click', function () {
                          const transactionId = $(this).data('transaction-id');
                          $('#deleteTransactionModal').removeClass('hidden');
                          $('#deleteTransactionId').val(transactionId); 
                      });
                  } else {
                      $('#transactionsList').html('<p class="text-gray-600">No hay transacciones para este usuario.</p>');
                  }
              },
              error: function (xhr) {
                  alert('Error al cargar las maquinas.');
              }
          });

            $('#deleteTransactionForm').on('submit', function (e) {
              e.preventDefault();
                const transactionId = $('#deleteTransactionId').val();

                $.ajax({
                    url: `/transactions/${transactionId}`,
                    method: 'DELETE',
                    data: $(this).serialize(),
                    success: function (response) {
                        alert('Transacción eliminada correctamente.');
                        $('#deleteTransactionModal').addClass('hidden');
                        location.reload(); 
                    },
                    error: function (xhr) {
                        alert('Error al eliminar la transacción.');
                    }
                });
            });


        }

        $.ajax({
            url: URLs,
            method: 'GET',
            success: function (res) {
                $('#transactionsList').html(res);
                loadTransactions(res);
            },
            error: function (xhr) {
                alert('Error al cargar las maquinas.');
            }
        });
    });

    $('.close-modal').on('click', function () {
        $(this).closest('#editModal').addClass('hidden');
        $(this).closest('#deleteModal').addClass('hidden');
        $(this).closest('#viewTransactionsModal').addClass('hidden');
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/company.blade.php ENDPATH**/ ?>