<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Editar Usuario</title>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- AlpineJS for interactivity -->
  <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
  <!-- Heroicons -->
  <script src="https://unpkg.com/heroicons@2.0.13"></script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
  <!-- Navbar -->
  <header class="bg-white shadow-md">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
      <div class="flex items-center">
        <img src="{{ asset('/img/logo.png') }}" alt="Logo" class="h-8 w-8 mr-2">
        <span class="font-bold text-xl">Cpanel</span>
      </div>
      <button @click="sidebarOpen = !sidebarOpen" class="md:hidden text-gray-600 focus:outline-none">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
    </div>
  </header>

  <div class="flex flex-1" x-data="{ sidebarOpen: false, editModal: false }">
    <!-- Sidebar -->
    <aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" class="fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200 transform md:translate-x-0 transition-transform">
      <nav class="mt-10 px-4 space-y-4">
        <a href="{{ url('/dashboard') }}" class="block text-gray-700 hover:text-teal-600">Dashboard</a>
        <a href="{{ url('/machines') }}" class="block text-gray-700 hover:text-teal-600">Máquinas</a>
        <a href="{{ url('/locals') }}" class="block text-gray-700 hover:text-teal-600">Locales</a>
        @if(auth()->user()->role === 'administrador')
          <a href="{{ url('/users') }}" class="block text-gray-700 hover:text-teal-600 font-semibold">Usuarios</a>
        @endif
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-6 md:ml-64">
      <div class="max-w-3xl mx-auto bg-white shadow rounded-lg p-6">
        <div class="flex justify-between items-center mb-6">
          <h1 class="text-2xl font-bold">Editar Usuario</h1>
          <button @click="editModal = true" class="flex items-center bg-teal-500 text-white px-4 py-2 rounded-lg hover:bg-teal-600 transition">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
              <path d="M2 15.25V18h2.75l8.394-8.394-2.75-2.75L2 15.25z" />
            </svg>
            Editar
          </button>
        </div>

        <!-- User Details Accordion -->
        <div x-data="{ open: true }" class="mb-4 border border-gray-200 rounded-lg">
          <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 bg-gray-50 hover:bg-gray-100 transition">
            <span class="font-medium">Detalles del Usuario</span>
            <svg xmlns="http://www.w3.org/2000/svg" :class="open ? 'transform rotate-180' : ''" class="h-5 w-5 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <div x-show="open" x-collapse class="p-4">
            <ul class="space-y-2">
              <li><strong>Nombre:</strong> {{ auth()->user()->name }}</li>
              <li><strong>Correo:</strong> {{ auth()->user()->email }}</li>
              <li><strong>Compañía:</strong> {{ auth()->user()->company }}</li>
              <li><strong>Rol:</strong> {{ auth()->user()->role }}</li>
              <li><strong>Última actualización:</strong> {{ auth()->user()->updated_at }}</li>
            </ul>
          </div>
        </div>

        <!-- Edit Modal -->
        <div x-show="editModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center" x-cloak>
          <div @click.away="editModal = false" class="bg-white rounded-lg shadow-lg w-full max-w-md p-6 transform transition-all">
            <h2 class="text-xl font-semibold mb-4">Editar Información</h2>
            <form id="editUserForm" @submit.prevent="submitForm">
              @csrf
              <div class="mb-4">
                <label for="name" class="block text-gray-700 font-medium">Nombre</label>
                <input type="text" id="name" name="name" x-model="form.name" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400" required>
              </div>
              <div class="mb-4">
                <label for="email" class="block text-gray-700 font-medium">Correo</label>
                <input type="email" id="email" name="email" x-model="form.email" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400" required>
              </div>
              <div class="mb-4">
                <label for="company" class="block text-gray-700 font-medium">Compañía</label>
                <input type="text" id="company" name="company" x-model="form.company" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400" required>
              </div>
              <div class="mb-4">
                <label for="role" class="block text-gray-700 font-medium">Rol</label>
                <select id="role" name="role" x-model="form.role" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="administrador">Administrador</option>
                  <option value="usuario">Usuario</option>
                </select>
              </div>
              <div class="flex justify-end space-x-2">
                <button type="button" @click="editModal = false" class="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition">Cancelar</button>
                <button type="submit" class="px-4 py-2 rounded-lg bg-teal-500 text-white hover:bg-teal-600 transition">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </main>
  </div>

  <!-- Scripts -->
  <script>
    document.addEventListener('alpine:init', () => {
      Alpine.data('editUserForm', () => ({
        form: {
          name: '{{ auth()->user()->name }}',
          email: '{{ auth()->user()->email }}',
          company: '{{ auth()->user()->company }}',
          role: '{{ auth()->user()->role }}'
        },
        async submitForm() {
          try {
            const response = await fetch('/users/update_me', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
              },
              body: JSON.stringify(this.form)
            });
            const data = await response.json();
            // actualizar vista
            location.reload();
          } catch (error) {
            console.error(error);
          }
        }
      }))
    })
  </script>
</body>
</html>

