<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Local extends Model
{
    public function machines()
    {
        return $this->hasMany(Machine::class, 'local', 'id');
    }
    
    public function transacciones()
    {
        return $this->hasMany(Transaction::class, 'machine_id');
    }
    protected $fillable = ['nombre', 'estado', 'state', 'owner', 'ciudad', 'company_id', 'lat', 'lon', 'phone'];

    public function setLatAttribute($value)
    {
        $this->attributes['lat'] = ($value === '' || $value === null) ? null : $value;
    }

    public function setLonAttribute($value)
    {
        $this->attributes['lon'] = ($value === '' || $value === null) ? null : $value;
    }
    
}

