 
<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">

    <form id="editUserForm2" class="bg-white/70 backdrop-blur-md shadow-xl rounded-2xl px-8 pt-8 pb-6 mb-6 border border-gray-200 animate-fade-in transition-all duration-500">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="<?php echo e(auth()->user()->id); ?>" id="editUserId" name="id">
    
        <h2 class="text-2xl font-semibold text-gray-800 mb-6 flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Zm6-10.125a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0Zm1.294 6.336a6.721 6.721 0 0 1-3.17.789 6.721 6.721 0 0 1-3.168-.789 3.376 3.376 0 0 1 6.338 0Z" />
            </svg>
            Editar Usuario
        </h2>
    
        <div class="mb-5 group">
            <label for="name" class="block text-sm font-medium text-gray-700 mb-1">
                <i class="lucide lucide-user w-4 h-4 inline mr-1 text-blue-400"></i>Nombre
            </label>
            <input type="text" id="name" name="name" required placeholder="Tu nombre"
                class="w-full px-4 py-2 rounded-xl border border-gray-300 shadow-sm focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none transition-all duration-300 group-hover:scale-[1.01]">
        </div>
    
        <div class="mb-5 group">
            <label for="email" class="block text-sm font-medium text-gray-700 mb-1">
                <i class="lucide lucide-mail w-4 h-4 inline mr-1 text-blue-400"></i>Email
            </label>
            <input type="email" id="email" name="email" required placeholder="ejemplo@correo.com"
                class="w-full px-4 py-2 rounded-xl border border-gray-300 shadow-sm focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none transition-all duration-300 group-hover:scale-[1.01]">
        </div>
    
        <div class="mb-5 group">
            <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">
                <i class="lucide lucide-phone w-4 h-4 inline mr-1 text-blue-400"></i>Teléfono
            </label>
            <input type="text" id="phone" name="phone" required placeholder="+51 999 999 999"
                class="w-full px-4 py-2 rounded-xl border border-gray-300 shadow-sm focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none transition-all duration-300 group-hover:scale-[1.01]">
        </div>
    
        <div class="mb-6 group">
            <label for="company" class="block text-sm font-medium text-gray-700 mb-1">
                <i class="lucide lucide-building w-4 h-4 inline mr-1 text-blue-400"></i>Compañía
            </label>
            <input type="text" id="company" name="company" disabled placeholder="Tu empresa"
                class="w-full px-4 py-2 rounded-xl border bg-gray-100 text-gray-600 shadow-inner outline-none cursor-not-allowed">
        </div>
    
        <!-- Botón -->
        <div class="flex justify-end">
            <button type="submit" id="configAcountBtn" class="bg-blue-500 hover:from-blue-600 hover:blue-800 text-white font-bold py-2 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
                </svg>

                Guardar Cambios
            </button>
        </div>
    </form>
</div>

<!-- Script para manejar el envío del formulario con AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
        const userId = $('#editUserId').val();
        $.ajax({
            url: `/users/${userId}`,
            method: 'GET',
            success: function (response) {
                $('#editUserId').val(response.id);
                $('#name').val(response.name);
                $('#email').val(response.email);
                $('#phone').val(response.phone);
                $('#company').val(response.company);
            },
            error: function (xhr) {
                alert('Error al cargar los datos del usuario.');
            }
        });

        $('#editUserForm2').on('submit', function (e) {
            e.preventDefault();
            const userId = $('#editUserId').val();
            const form = $(this);
            
            $.ajax({
                url: `/users/${userId}`,
                method: 'PUT',
                data: $(this).serialize(),
                success: function (response) {
                    $('#name').val(response.user.name);
                    $('#email').val(response.user.email);
                    $('#phone').val(response.user.phone);
                    $('#company').val(response.user.company);
                    
                    form.addClass('animate-pulse'); 
                    $("#configAcountBtn").css("background", "green");
                    setTimeout(() => {
                        form.removeClass('animate-pulse');
                        $("#configAcountBtn").css("background", "#3b82f6");
                    }, 1900);       
                    
                },
                error: function (xhr) {
                    alert('Error al actualizar el usuario.');
                }
            });
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/user_me_admin.blade.php ENDPATH**/ ?>