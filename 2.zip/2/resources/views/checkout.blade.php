@extends('layouts.app')
@section('content')
  <script src="https://www.paypal.com/sdk/js?client-id={{ env('PAYPAL_CLIENT_ID') }}&currency=USD"></script>
<div class="dark:text-gray-200 dark:bg-gray-800 bg-white p-8 rounded-2xl shadow-lg w-full max-w-sm text-center">
    
  <h2 class="text-2xl text-gray-500 font-bold mb-6">Pagar con PayPal</h2>
  <label for="amount" class="block text-sm font-medium text-gray-600 mb-1">Plan asignado: {{ $plan->name ?? 'No tienes un plan asignado' }} </label>
  <div style="margin-left:25%;" class="text-center">
    <div class="flex items-center space-x-2">
        <span class="text-gray-500 text-base font-medium">USD</span>
                
        <input type="number" id="amount" name="amount" value="{{ $totalFinal  ?? 0 }}
"
            class="dark:text-gray-200 dark:bg-gray-800 w-1/3 pborder border-gray-300 rounded-md bg-gray-50 t-base text-gray-500 text-center focus:outline-nofocus:ring-2 focus:ring-indigo-500"
            placeholder="{{ $totalFinal ?? 0 }}"  {{ $plan ? 'readonly' : '' }}>
                
        <span class="text-gray-500 text-base font-medium">$</span>
    </div>
 </div>
 <div style="margin-top:20px;" id="paypal-button-container"></div>
</div>

  <script>
    paypal.Buttons({
      style: {
        layout: 'vertical',   
        color:  'gold',       
        shape:  'rect',       
        label:  'paypal'     
      },
      createOrder: function(data, actions) {
        // Aquí defines el monto a pagar
        return actions.order.create({
          purchase_units: [{
            amount: {
              value: '{{ isset($amount) ? $amount : "10.00" }}' // monto dinámico o fijo
            }
          }]
        });
      },
      onApprove: function(data, actions) {
        return actions.order.capture().then(function(details) {
          // Tras pago exitoso, envías datos al backend
          return fetch("{{ route('paypal.success') }}", {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
              orderID: data.orderID,
              payerID: data.payerID
            })
          }).then(res => res.json())
            .then(response => {
              if (response.success) {
                window.location.href = "/dashboard";
              } else {
                alert("Hubo un error procesando tu pago.");
              }
            });
        });
      },
      onError: function(err) {
        console.error(err);
        alert("Ocurrió un error con PayPal. Intenta de nuevo.");
      }
    }).render('#paypal-button-container');
  </script>
        

@endsection