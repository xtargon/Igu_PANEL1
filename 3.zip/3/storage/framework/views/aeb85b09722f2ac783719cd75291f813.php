
<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<style>
    .M_E_p::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
        .pagination-btn {
            transition: background-color 0.3s ease;
        }
        .pagination-btn:hover {
            background-color: #2563eb; /* Cambia el color al pasar el mouse */
        }
        .pagination-btn.bg-blue-700 {
            background-color: #1e40af; /* Color para el botón activo */
        }
        .state{
           
        }
</style>

<script>
    const empresaIA = <?php echo json_encode($empresa, 15, 512) ?>;

    function refreshMachinesForLocal(localId) {
      const $body = $('#machines-body-' + localId);
      $body.fadeTo(150, 0.3);
      $.ajax({
        url: '/locals/' + localId + '/machines-table',
        type: 'GET',
        success(html) {
          $body.html(html).fadeTo(150, 1);
        },
        error() {
          alert('Error al recargar máquinas para el local ' + localId);
          $body.fadeTo(150, 1);
        }
      });
    }    
</script>

<div class="M_E_p">
   <div class="mb-4">
        <label for="searchInput" class="block text-gray-700 text-lg font-medium">JACKPOTS MAQUINAS</label>
        <input style="color: #6b7c84 !important;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-3/5 h-8 px-4 py-2 mt-5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
    </div>
<style>
#openCreateModal{
    background: turquoise!important;
    float:right!important;
}
@media (max-width: 768px) {
    #openCreateModal {
        background: turquoise;
        width: 35% !important;
        margin: 10px auto!important;
        float: right;
        margin-top: -10px!important;
        
    }
}
}
  .small-table {
      font-size: 12px; /* Reducir el tamaño de la fuente */
  }
  .small-table th, .small-table td {
      padding: 4px 8px; /* Reducir el padding */
  }
  .small-table th {
      white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
  }
  .small-table td {
      white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
  }
  .small-table {
      width: 100%; /* Ajustar el ancho de la tabla */
      overflow-x: auto; /* Permitir scroll horizontal si es necesario */
  }
  
  td{
      color: #6b7c84 !important;
  }
  
    @keyframes move-icon-center {
       to {
            transform: translateX(60px);
       }
    }

    .custom-box {
        text-align: center;
        background: white;
        width: 40%;
        margin-left: 32%;
        height:250px;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        transition: box-shadow 0.3s ease, transform 0.3s ease;
        margin-bottom:10px;
        margin-top:10px;
    }
                        
    .custom-box:hover {
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
        transform: translateY(-4px);
    }

</style>

<div class="container mx-auto p-4">
    <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div x-data="{ open: false }" class="dark:text-gray-400 dark:bg-gray-800 rounded-lg shadow-sm mb-4 bg-white overflow-hidden">
            
            <!-- Botón del Acordeón -->
            <button @click="open = !open"
                class="w-full justify-between items-center px-4 py-3 bg-blue hover:bg-blue transition duration-200">
                <svg style="float:left !important;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 21v-7.5a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349M3.75 21V9.349m0 0a3.001 3.001 0 0 0 3.75-.615A2.993 2.993 0 0 0 9.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 0 0 2.25 1.016c.896 0 1.7-.393 2.25-1.015a3.001 3.001 0 0 0 3.75.614m-16.5 0a3.004 3.004 0 0 1-.621-4.72l1.189-1.19A1.5 1.5 0 0 1 5.378 3h13.243a1.5 1.5 0 0 1 1.06.44l1.19 1.189a3 3 0 0 1-.621 4.72M6.75 18h3.75a.75.75 0 0 0 .75-.75V13.5a.75.75 0 0 0-.75-.75H6.75a.75.75 0 0 0-.75.75v3.75c0 .414.336.75.75.75Z" />
                </svg>

                <span class="text-lg font-semibold text-white-800"><?php echo e($local->nombre); ?></span>

            </button>

            <!-- Contenido del Acordeón -->
            <div x-show="open" x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 max-h-0"
                x-transition:enter-end="opacity-100 max-h-screen"
                x-transition:leave="transition ease-in duration-200"
                x-transition:leave-start="opacity-100 max-h-screen"
                x-transition:leave-end="opacity-0 max-h-0"
                class="dark:text-gray-400 dark:bg-gray-800 px-4 py-2 bg-white">

                <!-- Tabla de Máquinas con todos los campos -->
                <div class="overflow-x-auto">
                    <table class="dark:text-gray-400 dark:bg-gray-800 min-w-full  rounded-md overflow-hidden shadow-sm mt-2">
                        <tbody id="machines-body-<?php echo e($local->id); ?>">
                            <?php echo $__env->make('partials.local_tbody2', ['machines' => $local->machines], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
 <div id="pagination" class="flex justify-center mt-4"></div>

<script>
  function confirmarPago(button) {
      
    const balance = button.dataset.balance;
    const ac1 = button.dataset.ac1;
    const ac2 = button.dataset.ac2;
    const ac3 = button.dataset.ac3;
    const pp = button.dataset.pp;
    const mid = button.dataset.mid;

    Swal.fire({
      title: '¿Seguro que quieres mandar a pagar jackpot en esta maquina?',
      html: `
        <p><strong>Balance:</strong> ${balance}</p>
      `,
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Sí, pagar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33'
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire('¡Pagado!', 'La máquina ha sido enviada a pagar.', 'success');

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.post('/jack_pots', {
            machine_id: mid,
            active: 1
        })
        .done(function(response) {
               $(button)
                  .css({
                    "background": "green",
                    "cursor": "not-allowed"
                  })
                  .prop("disabled", true);
        })
        .fail(function(xhr) {
            console.error('Error al actualizar jackpot:', xhr.responseText);
                // Revertir switch en caso de error
            checkbox.prop('checked', !newState);
        });

      }
    });
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/jackpots.blade.php ENDPATH**/ ?>