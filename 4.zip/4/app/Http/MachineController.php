<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Machine;
use Illuminate\Support\Facades\Auth;

class MachineController extends Controller
{
    /**
     * Mostrar la lista de máquinas del usuario autenticado.
     */
    public function index()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        $machines = Machine::where('owner', Auth::id())->get();
        return view('machines.index', compact('machines'));
    }

    /**
     * Guardar una nueva máquina en la base de datos.
     */
    public function store(Request $request)
    {
        Machine::create([
            'owner' => Auth::id(),
            'local' => $request->local,
            'transactions' => $request->transactions,
            'filters' => $request->filters,
        ]);

        return redirect()->back()->with('success', 'Máquina creada correctamente.');
    }

    /**
     * Mostrar el formulario para editar una máquina.
     */
    public function edit(Machine $machine)
    {
        // Verifica que el usuario tenga permiso para editar
        if ($machine->owner !== Auth::id()) {
            return redirect()->back()->with('error', 'No tienes permiso para editar esta máquina.');
        }

        return view('machines.edit', compact('machine'));
    }

    /**
     * Actualizar una máquina en la base de datos.
     */
    public function update(Request $request, Machine $machine)
    {
        // Verifica que el usuario tenga permiso para actualizar
        
        $machine->update([
            'local' => $request->local,
            'transactions' => $request->transactions,
            'filters' => $request->filters,
        ]);

        return redirect()->back()->with('success', 'Máquina actualizada correctamente.');
    }

    /**
     * Eliminar una máquina de la base de datos.
     */
    public function destroy(Machine $machine)
    {

        $machine->delete();

        return redirect()->back()->with('success', 'Máquina eliminada correctamente.');
    }
}
