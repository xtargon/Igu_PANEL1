@extends('layouts.app')

@section('title', 'Registrarme')

@section('content')
<style>

        /* Modificar el tamaño de la barra de desplazamiento */
        .reg::-webkit-scrollbar {
          width: 10px; /* Ancho de la barra */
        }

        /* Modificar el color y el aspecto de la parte que se mueve (thumb) */
        .reg::-webkit-scrollbar-thumb {
          background-color: #202326d1; /* Color del thumb */
          border-radius: 10px; /* Bordes redondeados */
        }

        /* Modificar el color y el estilo del área de la barra (track) */
        .reg::-webkit-scrollbar-track {
          background-color: #334053b0; /* Color del track */
          border-radius: 10px; /* Bordes redondeados */
        }

        /* Cambiar el color del thumb cuando se pasa el cursor */
        .reg::-webkit-scrollbar-thumb:hover {
          background-color: #555; /* Color cuando se pasa el mouse */
        }

</style>
<div class="flex justify-center items-center min-h-screen px-4" style=""> 
    <div class="reg w-full max-w-md lg:max-w-lg xl:max-w-xl" style="overflow-y:scroll; box-shadow: 0 10px 15px rgba(0, 0, 0, 0.2), 0 4px 6px rgba(0, 0, 0, 0.1); height: 550px;color:#555555;padding:30px;background: white;border-radius: 4px;">
        <h2 class="text-3xl text-white-600 text-center mb-6">Registrate</h2>

        @if (session('error'))
            <div class="bg-red-100 text-red-700 p-3 rounded-lg mb-4">
                {{ session('error') }}
            </div>
        @endif

        <form action="{{ route('register') }}" method="POST">
            @csrf

            <!-- Nombre -->
            <div class="mb-4">
                <label for="name" class="block text-white-700 font-semibold">Nombre</label>
                <div style="color: #000000ab;" class="flex items-center border-2 border-gray-300 rounded-lg p-3 shadow-md focus-within:border-blue-500">
                    <i class="fa-solid fa-user text-gray-500 mr-3"></i>
                    <input type="text" id="name" style="border:none !important;" name="name" class="w-full focus:outline-none" placeholder="Tu nombre" required>
                </div>
            </div>

            <!-- Compañía -->
            <div class="mb-4">
                <label for="company" class="block text-white-700 font-semibold">Compañía</label>
                <div style="color: #000000ab;" class="flex items-center border-2 border-gray-300 rounded-lg p-3 shadow-md focus-within:border-blue-500">
                    <i class="fa-solid fa-building text-gray-500 mr-3"></i>
                    <input type="text" id="company" style="border:none !important;" name="company" class="w-full focus:outline-none" placeholder="Nombre de tu compañía" required>
                </div>
            </div>

            <!-- Email -->
            <div class="mb-4">
                <label for="email" class="block text-white-700 font-semibold">Email</label>
                <div style="color: #000000ab;" class="flex items-center border-2 border-gray-300 rounded-lg p-3 shadow-md focus-within:border-blue-500">
                    <i class="fa-solid fa-envelope text-gray-500 mr-3"></i>
                    <input type="email" id="email" style="border:none !important;" name="email" class="w-full focus:outline-none" placeholder="tucorreo@email.com" required>
                </div>
            </div>

            <!-- Contraseña -->
            <div class="mb-4">
                <label for="password" class="block text-white-700 font-semibold">Contraseña</label>
                <div style="color: #000000ab;" class="flex items-center border-2 border-gray-300 rounded-lg p-3 shadow-md focus-within:border-blue-500">
                    <i class="fa-solid fa-lock text-gray-500 mr-3"></i>
                    <input type="password" id="password" style="border:none !important;" name="password" class="w-full focus:outline-none" placeholder="********" required>
                </div>
            </div>

            <!-- Confirmar Contraseña -->
            <div class="mb-6">
                <label for="password_confirmation" class="block text-white-700 font-semibold">Confirmar Contraseña</label>
                <div style="color: #000000ab;" class="flex items-center border-2 border-gray-300 rounded-lg p-3 shadow-md focus-within:border-blue-500">
                    <i class="fa-solid fa-lock text-gray-500 mr-3"></i>
                    <input type="password" id="password_confirmation" style="border:none !important;" name="password_confirmation" class="w-full focus:outline-none" placeholder="********" required>
                </div>
            </div>

            <!-- Botón de Registro -->
            <button type="submit" style="cursor:pointer;color: aliceblue;background: #68b8aa;" class="w-full text-white py-3 rounded-lg text-lg font-semibold shadow-lg hover:opacity-90 transition">
                <i class="fa-solid fa-user-plus mr-2"></i>Empezar a descubrir
            </button>
        </form>

        <!-- Link a Login -->
        <p class="text-sm text-white-600 text-center mt-4">
            ¿Ya tienes una cuenta? <a href="{{ route('login') }}" class="text-blue-600 font-semibold hover:underline">Iniciar sesion</a>
        </p>
    </div>
</div>

@endsection