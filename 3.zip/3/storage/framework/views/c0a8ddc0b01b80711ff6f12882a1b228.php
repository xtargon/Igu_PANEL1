
<?php $__env->startSection('content'); ?>
    <div id="membershipModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 transition-all duration-300 ease-out">
        <div class="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-md shadow-lg transform scale-100 animate-fade-in">
            <h2 class="text-xl font-bold text-center text-red-600 mb-4">¡Tu membresía ha expirado!</h2>
            <p class="text-gray-700 dark:text-gray-300 text-center mb-6">
                Para seguir usando la plataforma, debes renovar tu membresía mensual.
            </p>
            <div class="flex justify-center">
                <button id="showPaymentFormBtn" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Renovar ahora
                </button>
            </div>
        </div>
    </div>

    <div id="stripePaymentForm" class="hidden bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl max-w-lg w-full text-center transition-all duration-500 ease-in-out opacity-0 transform scale-95">
        <h2 class="text-2xl font-bold mb-4 text-gray-800 dark:text-white">Pago de Membresía</h2>
        <p class="mb-6 text-gray-600 dark:text-gray-300">Realiza el pago para continuar usando la plataforma.</p>
        
        <a href="/payment/checkout">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-blue-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-full">
                Pagar con PayPal
            </button>
        </a>
    </div>

    <style>
        @keyframes fade-in {
            0% { opacity: 0; transform: scale(0.95); }
            100% { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in {
            animation: fade-in 0.3s ease-out;
        }
    </style>

    <script>
        $(document).ready(function () {
            $('#showPaymentFormBtn').on('click', function () {
                // Ocultar modal con animación
                $('#membershipModal')
                    .addClass('opacity-0 scale-95')
                    .removeClass('scale-100 opacity-100');
                
                setTimeout(function () {
                    $('#membershipModal').hide();
                    
                    // Mostrar formulario con animación
                    $('#stripePaymentForm')
                        .removeClass('hidden')
                        .removeClass('opacity-0 scale-95')
                        .addClass('opacity-100 scale-100');
                }, 300);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/payment.blade.php ENDPATH**/ ?>