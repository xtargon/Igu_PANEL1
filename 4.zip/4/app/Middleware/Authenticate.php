<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Support\Facades\Cookie;

class Authenticate extends Middleware
{
    public function handle($request, Closure $next, ...$guards)
    {
        // Si no hay usuario autenticado pero existe la cookie "custom_auth"
        if (!auth()->check() && $request->hasCookie('custom_auth')) {
            try {
                // Desencriptamos el contenido de la cookie para obtener el ID del usuario
                $userId = decrypt($request->cookie('custom_auth'));
                // Buscamos al usuario en la base de datos
                $user = \App\Models\User::find($userId);
                if ($user) {
                    // Iniciamos la sesión del usuario (esto crea toda la información en session y Auth)
                    auth()->login($user);
                    // Opcional: puedes regenerar la sesión para evitar fijación de sesión
                    $request->session()->regenerate();
                }
            } catch (\Exception $e) {
                // Si algo falla (p.ej. el valor no se puede desencriptar), eliminamos la cookie
                Cookie::queue(Cookie::forget('custom_auth'));
            }
        }

        return parent::handle($request, $next, ...$guards);
    }

    protected function redirectTo($request)
    {
        if (! $request->expectsJson()) {
            return route('login');
        }
    }
}
