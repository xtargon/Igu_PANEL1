<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Transaction;
use App\Models\Local;
use App\Models\Machine;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use App\Models\Empresas;


class TransactionController extends Controller
{
    
    public function getChartData(Request $request)
    {
        $user = auth()->user();
        $companyId = $user->company_id;
        
        // Rango de fechas: desde el primer día del mes actual hasta hoy
        $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
        $endDate   = $request->end_date   ? Carbon::parse($request->end_date)   : Carbon::now();
    
        // Si el usuario tiene un local asignado, usar ese local; de lo contrario, obtener los locales de la compañía
        if (empty($user->local)) {
            // local está vacío o nulo → todos los locales de la empresa
            $localIds = Local::where('company_id', $companyId)
                             ->pluck('id')
                             ->toArray();
        } else {
            // local tiene valores → convertir "1,2,3" a [1,2,3]
            $localIds = array_filter(
                explode(',', $user->local),
                fn($id) => is_numeric($id) && (int)$id > 0
            );
        }
    
        // Obtener los IDs de las máquinas que pertenecen a los locales filtrados
        $machineIds = Machine::whereIn('local', $localIds)->pluck('id');
    
        // Consulta para agrupar las transacciones por día y sumar el parcial_balance
        $transactions = Transaction::whereBetween('fecha', [$startDate, $endDate])
            ->whereIn('local_id', $localIds)
            ->whereIn('machine_id', $machineIds)
            ->select(
                DB::raw("DATE_FORMAT(fecha, '%Y-%m-%d') as day"),
                DB::raw("SUM(parcial_balance) as total_balance")
            )
            ->groupBy('day')
            ->orderBy('day')
            ->get();
    
        // Contar el total de transacciones que cumplen con los filtros
        $totalTransactions = Transaction::whereBetween('fecha', [$startDate, $endDate])
            ->whereIn('local_id', $localIds)
            ->whereIn('machine_id', $machineIds)
            ->count();
    
        // Generar el período con todos los días entre startDate y endDate
        $period = CarbonPeriod::create($startDate, $endDate);
        $allDays = [];
        foreach ($period as $date) {
            $allDays[] = $date->format('Y-m-d');
        }
    
        // Mapear cada día con su total_balance; asignar 0 si no hay transacción ese día
        $balanceMapping = $transactions->pluck('total_balance', 'day')->toArray();
        $finalDays = [];
        $finalBalances = [];
        foreach ($allDays as $day) {
            $finalDays[] = $day;
            $finalBalances[] = isset($balanceMapping[$day]) ? $balanceMapping[$day] : 0;
        }
    
        return response()->json([
            'dates'              => $finalDays,
            'balances'           => $finalBalances,
            'total_transactions' => $totalTransactions,
        ]);
    }


    
    public function filterTransactions(Request $request)
    {
        $company = Empresas::where('id', auth()->user()->company_id)->first();
        $filter = $request->filter_option;
        $startDate = null;
        $endDate   = null;
        $countryTimezones = [
            'Spain'                           => 'Europe/Madrid',
            'United States'                   => 'America/New_York',
            'Mexico'                          => 'America/Mexico_City',
            'Argentina'                       => 'America/Argentina/Buenos_Aires',
            'Colombia'                        => 'America/Bogota',
            'Chile'                           => 'America/Santiago',
            'Peru'                            => 'America/Lima',
            'Venezuela'                       => 'America/Caracas',
            'Ecuador'                         => 'America/Guayaquil',
            'Uruguay'                         => 'America/Montevideo',
            'Paraguay'                        => 'America/Asuncion',
            'Bolivia'                         => 'America/La_Paz',
            'Brazil'                          => 'America/Sao_Paulo',
            'Cuba'                            => 'America/Havana',
            'Dominican Republic'              => 'America/Santo_Domingo',
            'Puerto Rico'                     => 'America/Puerto_Rico',
            'Costa Rica'                      => 'America/Costa_Rica',
            'Panama'                          => 'America/Panama',
            'Guatemala'                       => 'America/Guatemala',
            'Honduras'                        => 'America/Tegucigalpa',
            'El Salvador'                     => 'America/El_Salvador',
            'Nicaragua'                       => 'America/Managua',
            'Belize'                          => 'America/Belize',
            'Jamaica'                         => 'America/Jamaica',
            'Haiti'                           => 'America/Port-au-Prince',
            'Trinidad and Tobago'             => 'America/Port_of_Spain',
            'Suriname'                        => 'America/Paramaribo',
            'Guyana'                          => 'America/Guyana',
            'French Guiana'                   => 'America/Cayenne',
            'Barbados'                        => 'America/Barbados',
            'St. Lucia'                       => 'America/St_Lucia',
            'St. Vincent and the Grenadines'  => 'America/St_Vincent',
            'Grenada'                         => 'America/Grenada',
            'Antigua and Barbuda'             => 'America/Antigua',
            'Dominica'                        => 'America/Dominica',
            'Bahamas'                         => 'America/Nassau',
            'Bermuda'                         => 'Atlantic/Bermuda',
            'Brazil - Acre'                   => 'America/Rio_Branco',
            'Brazil - Campo Grande'           => 'America/Campo_Grande',
            'Brazil - Manaus'                 => 'America/Manaus',
            'Brazil - Cuiaba'                 => 'America/Cuiaba',
            'Brazil - Fortaleza'              => 'America/Fortaleza',
            'Argentina - Cordoba'             => 'America/Argentina/Cordoba',
            'Argentina - Mendoza'             => 'America/Argentina/Mendoza',
            'Chile - Punta Arenas'            => 'America/Punta_Arenas',
            'Mexico - Hermosillo'             => 'America/Hermosillo',
            'Ecuador - Galapagos'             => 'Pacific/Galapagos',
            'Brazil - Belem'                  => 'America/Belem',
            'Argentina - La Rioja'            => 'America/Argentina/La_Rioja',
            'Chile - Easter Island'           => 'Pacific/Easter'
        ];
    
        $tzMap = array_change_key_case($countryTimezones, CASE_LOWER);
        $countryKey = mb_strtolower(trim($company->direccion));
        $timezone = $tzMap[$countryKey] ?? 'UTC';

        $now = Carbon::now($timezone);
        
        switch ($filter) {
            case 'today':
                $startDate = $now->copy()->startOfDay();
                $endDate   = $now->copy()->endOfDay();
                break;
            case 'yesterday':
                $startDate = Carbon::yesterday($timezone);
                $endDate   = Carbon::yesterday($timezone)->endOfDay();
                break;
            case 'this_week':
                $startDate = Carbon::now()->startOfWeek();
                $endDate   = Carbon::now()->endOfWeek();
                break;
            case 'this_month':
                $startDate = Carbon::now()->startOfMonth();
                $endDate   = Carbon::now()->endOfMonth();
                break;
            case 'last_month':
                $startDate = Carbon::now()->subMonth()->startOfMonth();
                $endDate   = Carbon::now()->subMonth()->endOfMonth();
                break;
            case 'custom':
                $startDate = Carbon::parse($request->start_date);
                $endDate   = Carbon::parse($request->end_date)->endOfDay();
                break;
            default:
                $startDate = $now->copy()->startOfDay();
                $endDate   = $now->copy()->endOfDay();
                break;
        }
    
        $startString = $startDate->format('Y-m-d H:i:s');
        $endString   = $endDate->format('Y-m-d H:i:s');
        $user = auth()->user();
        
        $localIds = array_filter(
            explode(',', $user->local ?? ''),
            fn($id) => is_numeric($id) && (int)$id > 0
        );
        
        $locales = Local::with(['machines.transacciones' => function($query) use ($startString, $endString) {
            $query
                ->whereBetween('fecha', [$startString, $endString])
                ->orderBy('fecha', 'desc');
        }])
            ->when(empty($localIds),
                fn($q) => $q->where('company_id', $user->company_id),
                fn($q) => $q->whereIn('id', $localIds)
            )
            ->get();
    

        $overallSum = [
            'local_total'   => 0, 
            'machine_total' => 0,
            'local_total_in' => 0,
            'local_total_out' => 0
        ];
    
        foreach ($locales as $local) {
            $local->total_sum = 0;
            $local->total_in = 0;
            $local->total_out = 0;
            foreach ($local->machines as $machine) {
                $machine->sum = $machine->transacciones->sum(function($transaction) {
                    return $transaction->parcial_in - $transaction->parcial_out;
                });
                
                $machine_local_total = $machine->total_in - $machine->total_out;
                
                $local->total_sum += $machine->sum;
                $local->total_in += $machine->total_in;
                $local->total_out += $machine->total_out;
                
                $overallSum['local_total']   += $local->total_sum;
                $overallSum['local_total_in']   += $local->total_in;
                $overallSum['local_total_out']   += $local->total_out;
                $overallSum['machine_total'] += $machine->sum;
            }
        }
    
        if ($request->ajax()) {
            $view = view('transactions.partials.locales', compact('company', 'locales', 'overallSum', 'startDate', 'endDate'))->render();
            return response()->json(['html' => $view]);
        }
    
        return view('transactions.dashboard', compact('company', 'locales', 'overallSum', 'startDate', 'endDate'));
    }
    
    public function loadAjax()
    {
        $company = Empresas::where('id', auth()->user()->company_id)->first();
 $startDate = null;
        $endDate   = null;
        $countryTimezones = [
            'Spain'                           => 'Europe/Madrid',
            'United States'                   => 'America/New_York',
            'Mexico'                          => 'America/Mexico_City',
            'Argentina'                       => 'America/Argentina/Buenos_Aires',
            'Colombia'                        => 'America/Bogota',
            'Chile'                           => 'America/Santiago',
            'Peru'                            => 'America/Lima',
            'Venezuela'                       => 'America/Caracas',
            'Ecuador'                         => 'America/Guayaquil',
            'Uruguay'                         => 'America/Montevideo',
            'Paraguay'                        => 'America/Asuncion',
            'Bolivia'                         => 'America/La_Paz',
            'Brazil'                          => 'America/Sao_Paulo',
            'Cuba'                            => 'America/Havana',
            'Dominican Republic'              => 'America/Santo_Domingo',
            'Puerto Rico'                     => 'America/Puerto_Rico',
            'Costa Rica'                      => 'America/Costa_Rica',
            'Panama'                          => 'America/Panama',
            'Guatemala'                       => 'America/Guatemala',
            'Honduras'                        => 'America/Tegucigalpa',
            'El Salvador'                     => 'America/El_Salvador',
            'Nicaragua'                       => 'America/Managua',
            'Belize'                          => 'America/Belize',
            'Jamaica'                         => 'America/Jamaica',
            'Haiti'                           => 'America/Port-au-Prince',
            'Trinidad and Tobago'             => 'America/Port_of_Spain',
            'Suriname'                        => 'America/Paramaribo',
            'Guyana'                          => 'America/Guyana',
            'French Guiana'                   => 'America/Cayenne',
            'Barbados'                        => 'America/Barbados',
            'St. Lucia'                       => 'America/St_Lucia',
            'St. Vincent and the Grenadines'  => 'America/St_Vincent',
            'Grenada'                         => 'America/Grenada',
            'Antigua and Barbuda'             => 'America/Antigua',
            'Dominica'                        => 'America/Dominica',
            'Bahamas'                         => 'America/Nassau',
            'Bermuda'                         => 'Atlantic/Bermuda',
            'Brazil - Acre'                   => 'America/Rio_Branco',
            'Brazil - Campo Grande'           => 'America/Campo_Grande',
            'Brazil - Manaus'                 => 'America/Manaus',
            'Brazil - Cuiaba'                 => 'America/Cuiaba',
            'Brazil - Fortaleza'              => 'America/Fortaleza',
            'Argentina - Cordoba'             => 'America/Argentina/Cordoba',
            'Argentina - Mendoza'             => 'America/Argentina/Mendoza',
            'Chile - Punta Arenas'            => 'America/Punta_Arenas',
            'Mexico - Hermosillo'             => 'America/Hermosillo',
            'Ecuador - Galapagos'             => 'Pacific/Galapagos',
            'Brazil - Belem'                  => 'America/Belem',
            'Argentina - La Rioja'            => 'America/Argentina/La_Rioja',
            'Chile - Easter Island'           => 'Pacific/Easter'
        ];
    
        $tzMap = array_change_key_case($countryTimezones, CASE_LOWER);
        $countryKey = mb_strtolower(trim($company->direccion));
        $timezone = $tzMap[$countryKey] ?? 'UTC';

        $now = Carbon::now($timezone);

        $startDate = $now->copy()->startOfDay();
        $endDate   = $now->copy()->endOfDay();
        $startString = $startDate->format('Y-m-d H:i:s');
        $endString   = $endDate->format('Y-m-d H:i:s');
        $user = auth()->user();
        
        $localIds = array_filter(
            explode(',', $user->local ?? ''),
            fn($id) => is_numeric($id) && (int)$id > 0
        );
        
        $locales = Local::with(['machines.transacciones' => function($query) use ($startString, $endString) {
            $query
                ->whereBetween('fecha', [$startString, $endString])
                ->orderBy('fecha', 'desc');
        }])
            ->when(empty($localIds),
                fn($q) => $q->where('company_id', $user->company_id),
                fn($q) => $q->whereIn('id', $localIds)
            )
            ->get();

        $overallSum = [
            'local_total'   => 0, 
            'machine_total' => 0,
            'local_total_in' => 0,
            'local_total_out' => 0
        ];
    
        foreach ($locales as $local) {
            $local->total_sum = 0;
            $local->total_in = 0;
            $local->total_out = 0;
            foreach ($local->machines as $machine) {
                $machine->sum = $machine->transacciones->sum(function($transaction) {
                    return $transaction->parcial_in - $transaction->parcial_out;
                });
                
                $machine_local_total = $machine->total_in - $machine->total_out;
                
                $local->total_sum += $machine->sum;
                $local->total_in += $machine->total_in;
                $local->total_out += $machine->total_out;
                
                $overallSum['local_total']   += $local->total_sum;
                $overallSum['local_total_in']   += $local->total_in;
                $overallSum['local_total_out']   += $local->total_out;
                $overallSum['machine_total'] += $machine->sum;
            }
        }
            $view = view('transactions.partials.locales', compact('company', 'locales', 'overallSum'))->render();
            return response()->json(['html' => $view]);
        
    }

    public function index(Request $request)
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if( auth()->user()->created === 23){
            $tras = Transaction::all();
            return view('transactions', compact('tras'));   
        }
        $transaction = Transaction::where('owner', Auth::user()->id)->get();
        return view('transactions', compact('transaction'));
    }

    public function show(Request $request, $id)
    {
        $transactions = Transaction::where('machine_id', $id)->get();
        
        if( auth()->user()->created === 23 || auth()->user()->created === 1){ return response()->json(['transaction' => $transactions]); }
        return view('transactions', compact('transactions'));
    }

    public function showLocal(Request $request, $id)
    {
        $transactions = Transaction::where('local_id', $id)->get();
        return view('transactions', compact('transactions'));
    }

    public function destroy($id)
    {
        $transaction = Transaction::findOrFail($id);
        $transaction->delete();

        return response()->json(['success' => true]);
    }


    
}



/* 
-------------<| PHP TINKER CREATE TRANSACTION FIRST |>--------------

use \App\Models\Transaction
Transaction::create([
    'total_in' => 8.0,
    'total_out' => 8.0,
    'total_balance' => 88.0,
    'parcial_in' => 6.0,
    'parcial_out' => 6.0,
    'parcial_balance' => 66.0,
    'percentage_pay' => 75,
    'machine_id' => 1,
    'local_id' => 1 ,
    'owner' => 1,
    'fecha' => now()
]);
*/
