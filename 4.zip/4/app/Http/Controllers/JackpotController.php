<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Machine;

class JackpotController extends Controller
{

    public function toggle(Request $request)
    {
        
        function generateRandomString() {
            $numbers1 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT);
            $letters = '';
            for ($i = 0; $i < 3; $i++) {
                $letters .= chr(mt_rand(65, 90));
            }
            $numbers2 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT);
            
            return $numbers1 . $letters . $numbers2;
        }
        
        $tokn = generateRandomString();        
        
        $data = $request->validate([
            'machine_id' => 'required|integer|exists:machines,id',
            'active'     => 'required|boolean',
        ]);

        $machine = Machine::find($data['machine_id']);

        $machine->jackpots = $data['active'];
        $machine->tkn_jackpots = $tokn;
        $machine->save();

        return response()->json([
            'status'     => 'success',
            'machine_id' => $machine->id,
            'jackpots'   => $machine->jackpots,
        ]);
    }
    
    public function statusAll()
    {
        $machines = Machine::select('id', 'jackpots')->get();
        $statusMap = $machines->pluck('jackpots', 'id');

        return response()->json($statusMap);
    }
    
}
