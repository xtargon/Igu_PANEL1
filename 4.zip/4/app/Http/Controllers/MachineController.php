<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Machine;
use Illuminate\Support\Facades\Auth;
use App\Models\Empresas;
use App\Models\Local;

class MachineController extends Controller
{
    /**
     * Mostrar la lista de máquinas del usuario autenticado.
     */
    public function index()
    {
        if (!auth()->check()) {
            return redirect('/');
        }

        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if(auth()->user()->created === 23){
            $machines = Machine::all();
            return view('admin.machines_admin', compact('machines'));
        }
        
        $empresa = Empresas::findOrFail(auth()->user()->company_id);
        $user = auth()->user();
        
        if (empty($user->local)) {
            $locales = Local::with('machines')
                            ->where('company_id', $user->company_id)
                            ->get();
        } else {
            $local_ids = array_filter(explode(',', $user->local));
            $locales = Local::with('machines')
                            ->whereIn('id', $local_ids)
                            ->get();
        }
        
        return view('machines', compact('locales', 'empresa'));


    }
    
    public function jackpots()
    {
        if (!auth()->check()) {
            return redirect('/');
        }

        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if(auth()->user()->created === 23){
            $machines = Machine::all();
            return view('admin.machines_admin', compact('machines'));
        }
        
        $empresa = Empresas::findOrFail(auth()->user()->company_id);
        $user = auth()->user();
        
        if (empty($user->local)) {
            $locales = Local::with('machines')
                            ->where('company_id', $user->company_id)
                            ->get();
        } else {
            $local_ids = array_filter(explode(',', $user->local));
            $locales = Local::with('machines')
                            ->whereIn('id', $local_ids)
                            ->get();
        }
        
        return view('jackpots', compact('locales', 'empresa'));


    }    
    
    public function find()
    {

        if( auth()->user()->local === null){
            if(auth()->user()->role === 'administrador'){
                
                if( auth()->user()->created === 23){
                    $M_all = Machine::all();
                    $totalMachines = $M_all->count();
                    return response()->json([
                        'success' => true,
                        'num' => $totalMachines,
                        'machine' => $M_all
                    ]);          
                }

                if(auth()->user()->created === 1){
                    $machines = Machine::where('owner', auth()->user()->company_id)->get();
                    $totalMachines = $machines->count();
                    return response()->json([
                        'success' => true,
                        'num' => $totalMachines,
                        'machine' => $machines
                    ]);
                }else{
                    $machines = Machine::where('owner', auth()->user()->company_id)->get();
                    $totalMachines = $machines->count();
                    return response()->json([
                        'success' => true,
                        'num' => $totalMachines,
                        'machine' => $machines
                    ]);
                }
            }else{
                $machines = Machine::where('owner', auth()->user()->company_id)->get();
                $totalMachines = $machines->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalMachines,
                    'machine' => $machines
                ]);
            }
        }else{
            if( auth()->user()->created === 23){
                $M_all = Machine::all();
                $totalMachines = $M_all->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalMachines,
                    'machine' => $M_all
                ]);          
            }

            if(auth()->user()->role === 'administrador'){
                if(auth()->user()->created === 1){
                    $machines = Machine::where('owner', auth()->user()->company_id)->get();
                    $totalMachines = $machines->count();
                    return response()->json([
                        'success' => true,
                        'num' => $totalMachines,
                        'machine' => $machines
                    ]);
                }else{
                    $machines = Machine::where('owner', auth()->user()->company_id)->get();
                    $totalMachines = $machines->count();
                    return response()->json([
                        'success' => true,
                        'num' => $totalMachines,
                        'machine' => $machines
                    ]);
                }
            }else{
                $machines = Machine::where('owner', auth()->user()->company_id)->where('local', auth()->user()->local)->get();
                $totalMachines = $machines->count();
                return response()->json([
                    'success' => true,
                    'num' => $totalMachines,
                    'machine' => $machines
                ]);
            }
        }
    }
    /**
     * Guardar una nueva máquina en la base de datos.
     */
    public function store(Request $request)
    {
        function generateRandomString() {
            $numbers1 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT); // 2 dígitos
            $letters = '';
            for ($i = 0; $i < 3; $i++) {
                $letters .= chr(mt_rand(65, 90)); // Letras A-Z
            }
            $numbers2 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT); // 2 dígitos
            
            return $numbers1 . $letters . $numbers2;
        }   
        
        $token = generateRandomString();
        
        $local = 0; 
        if($request->local !== null){
            $local = $request->local;
        }
        
        $offOnIA = $request->ia_balance ?? 'off';
        
        $machine = Machine::create([
            'owner' => auth()->user()->company_id,
            'local' => $local,
            'transactions' => 0,
            'filters' => mt_rand(100000, 999999),
            'state' => 1,
            'nombre' => $request->nombre,
            'juego' => $request->juego,
            'parcial_in' => 0,
            'parcial_out' => 0,
            'total_in' => 0,
            'total_out' => 0,
            'balance' => 0,
            'p_p' => $request->p_p,
            'tkn_jackpots' => '',
            'ac1' => $request->ac1,
            'ac2' => $request->ac2,
            'ac3' => $request->ac3,            
            
            'acumulated1' => $request->acumulated1_1,
            'acumulated2' => $request->acumulated2_1,
            'acumulated3' => $request->acumulated3_1,
            'acumulated1_2' => $request->acumulated1_2,
            'acumulated1_3' => $request->acumulated1_3,
            'acumulated2_2' => $request->acumulated2_2,
            'acumulated2_3' => $request->acumulated2_3,
            'acumulated3_2' => $request->acumulated3_2,
            'acumulated3_3' => $request->acumulated3_3,
            
            'acumulated1_4' => $request->acumulated1_4,
            'acumulated1_5' => $request->acumulated1_5,
            'acumulated2_4' => $request->acumulated2_4,
            'acumulated2_5' => $request->acumulated2_5,
            'acumulated3_4' => $request->acumulated3_4,
            'acumulated3_5' => $request->acumulated3_5,
            'door_acumulated' => $token,
        ]);
        return response()->json([
            'success' => true,
            'machine' => $machine
        ]);
    }

    public function edit(Machine $machine, Request $request )
    {
        $machines = Machine::where('id', $request->id)->get();
        return response()->json($machine);
    }

    public function show($id)
    {
        $machines = Machine::where('local', $id)->get();
        return response()->json($machines);
    }

    public function update(Request $request, Machine $machine)
    {
        
        function generateRandomString() {
            $numbers1 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT);
            $letters = '';
            for ($i = 0; $i < 3; $i++) {
                $letters .= chr(mt_rand(65, 90));
            }
            $numbers2 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT);
            
            return $numbers1 . $letters . $numbers2;
        }
        
        $tokn = generateRandomString();
        
        if ($request->acumulated1_1 != $machine->acumulated1 ||
            $request->acumulated1_2 != $machine->acumulated1_2 ||
            $request->acumulated1_3 != $machine->acumulated1_3 || 
            $request->acumulated1_4 != $machine->acumulated1_4 ||
            $request->acumulated1_5 != $machine->acumulated1_5 || 
            $request->acumulated2_1 != $machine->acumulated2 ||
            $request->acumulated2_2 != $machine->acumulated2_2 ||
            $request->acumulated2_3 != $machine->acumulated2_3 || 
            $request->acumulated2_4 != $machine->acumulated2_4 ||
            $request->acumulated2_5 != $machine->acumulated2_5 || 
            $request->acumulated3_1 != $machine->acumulated3 ||
            $request->acumulated3_2 != $machine->acumulated3_2 ||
            $request->acumulated3_3 != $machine->acumulated3_3 || 
            $request->acumulated3_4 != $machine->acumulated3_4 ||
            $request->acumulated3_5 != $machine->acumulated3_5 || 
            $request->ac1 != $machine->ac1 || 
            $request->ac2 != $machine->ac2 || 
            $request->ac3 != $machine->ac3 || 
            $request->p_p != $machine->p_p) {
                
            $machine->update(['door_acumulated' => $tokn]); 
        }
        
        $machine->update([
            'nombre' => $request->nombre,
            'local' => $request->local,
            'acumulated1' => $request->acumulated1_1,
            'acumulated2' => $request->acumulated2_1,
            'acumulated3' => $request->acumulated3_1,
            
            'acumulated1_2' => $request->acumulated1_2,
            'acumulated1_3' => $request->acumulated1_3,
            'acumulated1_4' => $request->acumulated1_4,
            'acumulated1_5' => $request->acumulated1_5,

            'acumulated2_2' => $request->acumulated2_2,
            'acumulated2_3' => $request->acumulated2_3,
            'acumulated2_4' => $request->acumulated2_4,
            'acumulated2_5' => $request->acumulated2_5,

            'acumulated3_2' => $request->acumulated3_2,
            'acumulated3_3' => $request->acumulated3_3,
            'acumulated3_4' => $request->acumulated3_4,
            'acumulated3_5' => $request->acumulated3_5,

            'p_p' => $request->p_p,
        ]);     
        
        return response()->json([
            'success' => true,
            'machine' => $machine
        ]);
    }

    public function reset(Request $request, Machine $machine)
    {
        
        if($request->caracter == 0){
            function generateRandomString() {
                $numbers1 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT);
                $letters = '';
                for ($i = 0; $i < 3; $i++) {
                    $letters .= chr(mt_rand(65, 90));
                }
                $numbers2 = str_pad(mt_rand(0, 99), 2, '0', STR_PAD_LEFT);
                
                return $numbers1 . $letters . $numbers2;
            }
            
            $tokn = generateRandomString();
            
            $machine->tkn_jackpots = $tokn;
            $machine->state = 'reset';
            $machine->save();
            
            return response()->json([
                'success' => true,
                'machine' => $machine
            ]);
        }else{
            return response()->json([
                'success' => false,
                'machine' => $machine
            ]);
        }
    }

    public function updateStatus(Request $request, $id)
    {
        $machine = Machine::find($id);
        $machine->update($request->only('state'));
        return response()->json([
            'success' => true,
            'machine' => $machine
        ]);
    }
    
    // Método para eliminar la máquina
    public function destroy(Machine $machine)
    {
        $machine->delete();
        return response()->json(['success' => true]);
    }
}