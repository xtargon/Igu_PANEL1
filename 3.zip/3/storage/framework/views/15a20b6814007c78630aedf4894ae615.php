
<?php $__env->startSection('content'); ?>
<style>
    .M_E_p::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
        .pagination-btn {
            transition: background-color 0.3s ease;
        }
        .pagination-btn:hover {
            background-color: #2563eb; /* Cambia el color al pasar el mouse */
        }
        .pagination-btn.bg-blue-700 {
            background-color: #1e40af; /* Color para el botón activo */
        }
</style>

<div class="M_E_p">
   <div class="mb-4">
        <label for="searchInput" class="block text-gray-700 text-lg font-medium">JUEGOS</label>
        <input style="color: #6b7c84 !important;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-3/5 h-8 px-4 py-2 mt-5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
        <?php if(auth()->user()->role === 'administrador'): ?>
            <button id="openCreateModal" class="bg-blue-500 text-white px-4 py-2 rounded-md">NUEVO JUEGO</button>
        <?php endif; ?>
    </div>
<style>
    .small-table {
        font-size: 12px; /* Reducir el tamaño de la fuente */
    }
    .small-table th, .small-table td {
        padding: 4px 8px; /* Reducir el padding */
    }
    .small-table th {
        white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
    }
    .small-table td {
        white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
    }
    .small-table {
        width: 100%; /* Ajustar el ancho de la tabla */
        overflow-x: auto; /* Permitir scroll horizontal si es necesario */
    }
    
  td{
      color: #6b7c84 !important;
  }
    
</style>

<div class="overflow-x-auto">
  <table class="small-table min-w-full leading-normal">
      <thead>
          <tr>
              <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Nombre</th>
              <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Fabricante</th>
              <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Matemática</th>
              <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Estado</th>
              <th class="px-2 py-1 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">Acciones</th>
          </tr>
      </thead>
      <tbody id="games-table" class="dark:border-gray-800 dark:bg-gray-900">
          <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="GGG" data-game-id="<?php echo e($game->id); ?>">
                  <!-- Nombre -->
                  <td style="color: #6b7c84 !important;" class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                      <?php echo e($game->nombre); ?>

                  </td>
                  <!-- Fabricante -->
                  <td style="color: #6b7c84 !important;" class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                      <?php echo e($game->fabricante); ?>

                  </td>
                  <!-- Matemática -->
                  <td style="color: #6b7c84 !important;" class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                      <?php echo e($game->matematica); ?>

                  </td>
                  <!-- Estado -->
                  <td style="color: #6b7c84 !important;" class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                      <?php echo e($game->state); ?>

                  </td>
                  <!-- Botones de acciones -->
                  <td class="px-2 py-2 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-gray-100">
                      <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn" data-game-nombre="<?php echo e($game->nombre); ?>" data-game-fabricante="<?php echo e($game->fabricante); ?>" data-game-matematica="<?php echo e($game->matematica); ?>" data-game-state="<?php echo e($game->state); ?>" data-game-id="<?php echo e($game->id); ?>">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                          </svg>
                      </button>
                      <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-game-id="<?php echo e($game->id); ?>">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                              <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                          </svg>
                      </button>
                  </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
</div>
<div id="pagination" class="flex justify-center mt-4"></div>
<?php echo $__env->make('admin.modals.edit_game', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modals.create_games', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
$(document).ready(function () {

    const rowsPerPage = 10; 
    const $rows = $('#games-table tr.GGG'); 
    const totalRows = $rows.length; 
    const totalPages = Math.ceil(totalRows / rowsPerPage); 

    function showPage(page) {
        $rows.hide(); 
        $rows.slice((page - 1) * rowsPerPage, page * rowsPerPage).show(); 
    }

    function createPaginationButtons() {
        let buttons = '';
        for (let i = 1; i <= totalPages; i++) {
            buttons += `<button class="px-4 py-2 mx-1 bg-blue-500 text-white rounded-md pagination-btn" data-page="${i}">${i}</button>`;
        }
        $('#pagination').html(buttons);
    }

    showPage(1);
    createPaginationButtons();

    $('#pagination').on('click', '.pagination-btn', function () {
        const page = $(this).data('page'); 
        showPage(page); 

        $('.pagination-btn').removeClass('bg-blue-700').addClass('bg-blue-500');
        $(this).removeClass('bg-blue-500').addClass('bg-blue-700');
    });


    $("#searchInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
        $("#games-table tr").filter(function() {
            $(this).toggle(
                $(this).find("td:nth-child(0)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(1)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(2)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(3)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(4)").text().toLowerCase().indexOf(value) > -1   
            );
        });
    });
});
</script>

<?php $__env->stopSection(); ?>


<script>
   /* $(document).ready(function() {
        $("#searchInput").on("keyup", function() {
            var value = $(this).val().toLowerCase(); // Obtener el texto de búsqueda y convertirlo a minúsculas
            $("#machine-table tr").filter(function() {
                // Buscar dentro del ID, Local y Estado
                $(this).toggle(
                    $(this).find("td:nth-child(4)").text().toLowerCase().indexOf(value) > -1 ||
                    $(this).find("td:nth-child(1)").text().toLowerCase().indexOf(value) > -1 || 
                    $(this).find("td:nth-child(3)").text().toLowerCase().indexOf(value) > -1   
                );
            });
        });

        // Abrir el modal
        $('#openModal').click(function() {
            $('#modal').removeClass('hidden opacity-0').addClass('opacity-100');
            $('#modal .transform').removeClass('scale-95').addClass('scale-100');
            
        });

        // Cerrar el modal
        $('#closeModal').click(function() {
            $('#modal').addClass('hidden opacity-0').removeClass('opacity-100');
            $('#modal .transform').removeClass('scale-100').addClass('scale-95');
        });

        // Cerrar el modal al hacer clic fuera del modal
        $('#modal').click(function(e) {
            if ($(e.target).closest('.transform').length === 0) {
                $('#modal').addClass('hidden opacity-0').removeClass('opacity-100');
                $('#modal .transform').removeClass('scale-100').addClass('scale-95');
            }
        });

        $('#createUserForm').on('submit', function(e) {
            e.preventDefault();

            let formData = $(this).serialize(); 
            $('#submitBtn').attr('disabled', true); 

            $.ajax({
                url: '/games',
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        
                        loadMachines();
                        $('#createUserForm')[0].reset();
                        $('#submitBtn').attr('disabled', false);
                        $("#machine-table").empty();
                        $('#crud-modal').removeClass('scale-100').addClass('scale-95');
                        $('#crud-modal').addClass('hidden').removeClass('opacity-100');
                        $('#crud-modal').removeClass('scale-100').addClass('scale-95');
                        
                    } else {
                        alert('Hubo un error. Intenta nuevamente.');
                        $('#submitBtn').attr('disabled', false);
                    }
                },
                error: function(xhr, status, error) {
                    alert('Error en la solicitud. Intenta nuevamente.');
                    $('#submitBtn').attr('disabled', false);
                }
            });
        });
    });


    function loadMachines() {
        $.get('/games_getting', function (data) {
            let tableBody = $("#machine-table");

                if (data.length === 0) {
                    tableBody.append("<tr><td colspan='4'>No se encontraron resultados</td></tr>");
                } else {
                    var games = data.games;
                    $("#numT").text(games.length)
                    games.forEach(doc => {  
                        console.log(doc.nombre)
                        let row = `
                            <tr  data-id=${doc.id} class="assemble">
                                <td class="py-4 text-sm text-gray-600 flex flex-row items-center text-left">
                                    <div class="w-8 h-8 overflow-hidden mr-3">
                                    <i style="margin-left:10px; color:teal; font-size:18px;" class="object-cover fad fa-alien-monster"></i>
                                        <i  fas fa-user-cog"></i> 
                                    </div>
                                     ${doc.nombre} 
                                </td>
                                <td class="py-4 text-xs text-gray-600">${doc.fabricante}<span class="num-3"></span></td>
                                <td class="py-4 text-xs text-gray-600">${doc.matematica}<span class="num-3"></span></td>
                                <td class="py-4 text-xs text-gray-600">${doc.id}</td>
                            </tr> `;
                        tableBody.append(row);
                    });
                }
        });
    }

    $("#machine-table").on('click', '.assemble', function() {
        var machID = $(this).data('id');
        $('#viewM').removeClass('hidden').addClass('scale-95');
        $.ajax({
            url: `/games/find`,
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                idUser: machID
            },
            success: function(doc) {
                console.log(doc[0].nombre)
            let view2 = `
              <li style="margin-top: 17px; list-style: none;" class="">
                         <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fad fa-alien-monster"></i> ${doc[0].nombre}</p>
                    </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                      <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fad fa-game-console-handheld"></i> ${doc[0].fabricante}</p>
                  </li>
                    <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fad fa-sort-numeric-up"></i> ${doc[0].matematica}</p>
                  </li> 
                 <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fad fa-toggle-on"></i> ${doc[0].state}</p>
                  </li> 

          <p style="padding:7px; text-align: end;">
              <button 
                  data-name="${doc[0].nombre}" 
                  data-fab="${doc[0].fabricante}" 
                  data-math="${doc[0].matematica}" 
                  data-state="${doc[0].state}" 
                  data-id="${doc[0].id}" 
                  id="userEditBtn"
                  class="userEditBtn rounded-full text-white badge bg-teal-400 text-xs"
                  style="background: #42a071;" 
                  type="button">
                  <i class="fad fa-cogs"></i> editar
              </button>

              <button 
                  data-id="${doc[0].id}" 
                  class="deleteMachineBtn rounded-full text-white badge bg-red-400 text-xs"
                  style="background: #c75b5b;" 
                  type="button">
                  <i class="fad fa-trash-restore"></i> Eliminar
              </button>
          </p>

           `;
            $("#datas").append(view2);
            }
        });


        $('#closeViewModal').click(function() {
            $('#viewM').addClass('hidden');
            $("#datas").empty();
            $("#tr").empty();
        });
      })


    $("#viewM").on('click', '#userEditBtn', function() {
      $('#viewM').addClass('hidden');
        $("#datas").empty();
        $("#tr").empty();
        $('#idx').val($(this).data('id'));
        $('#nameEdit').val($(this).data('name'));
        $('#fabEdit').val($(this).data('fab'));
        $('#mathEdit').val($(this).data('math'));
        $('#stateEdit').val($(this).data('state'));

        $('#editModal').removeClass('hidden');
    });

    // Cerrar modal de edición
    $('#closeEditModal').click(function() {
        $('#editModal').addClass('hidden');
    });

    // Enviar formulario de edición con AJAX
    $('#editUserForm').submit(function(e) {
        e.preventDefault();
        let id = $('#idx').val();
        $.ajax({
            url: `/games/${id}`,
            type: 'PUT',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                nombre: $('#nameEdit').val(),
                fabricante: $('#fabEdit').val(),
                matematica: $('#mathEdit').val(),
                state: $('#stateEdit').val()
            },
            success: function(response) {
                loadMachines();
                $("#machine-table").empty();
                $('#editModal').addClass('hidden');
            }
        });
    });

    // Abrir modal de eliminación

    $("#viewM").on('click', '.deleteMachineBtn', function() {
        $('#confirmDeleteBtn').data('id', $(this).data('id'));
        $('#viewM').addClass('hidden');
            $("#datas").empty();
            $("#tr").empty();
        $('#deleteModal').removeClass('hidden');
    });

    // Cerrar modal de eliminación
    $('#closeDeleteModal').click(function() {
        $('#deleteModal').addClass('hidden');
    });

    // Confirmar eliminación con AJAX
    $('#confirmDeleteBtn').click(function() {
        let id = $(this).data('id');
        $.ajax({
            url: `/games/${id}`,
            type: 'DELETE',
            data: { _token: '<?php echo e(csrf_token()); ?>' },
            success: function(response) {
                $('#deleteModal').addClass('hidden');
                loadMachines();
                $("#machine-table").empty();
                $('#editModal').addClass('hidden');
            }
        });
    });

    loadMachines();*/

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/games.blade.php ENDPATH**/ ?>