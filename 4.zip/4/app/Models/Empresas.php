<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Empresas extends Model
{
    protected $fillable = ['nombre', 'direccion', 'telefono', 'geo', 'ia_picture', 'coins', 'last_recharge', 'share'];
}
