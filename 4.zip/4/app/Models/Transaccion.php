<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaccion extends Model
{
    protected $fillable = ['fecha', 'total_in ', 'total_out', 'total_balance', 'parcial_in', 'parcial_out', 'parcial_balance', 'percentage_pay', 'owner'];
}
