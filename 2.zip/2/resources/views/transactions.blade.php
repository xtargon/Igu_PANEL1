@extends('layouts.app')
@section('content')
<form method="GET" action="{{ route('transactions.filter') }}">
  <div>
    <label for="filter_option">Filtrar por:</label>
    <select name="filter_option" id="filter_option">
      <option value="today">Hoy</option>
      <option value="yesterday">Ayer</option>
      <option value="this_week">Esta Semana</option>
      <option value="this_month">Este Mes</option>
      <option value="last_month">Último Mes</option>
      <option value="custom">Fechas Personalizadas</option>
    </select>
  </div>

  <div id="custom_dates" style="display: none;">
    <label for="start_date">Fecha inicio:</label>
    <input type="date" name="start_date" id="start_date">
    <label for="end_date">Fecha fin:</label>
    <input type="date" name="end_date" id="end_date">
  </div>

  <button type="submit">Filtrar</button>
</form>

<script>
  // Muestra u oculta los inputs de fechas según la opción seleccionada
  document.getElementById('filter_option').addEventListener('change', function() {
    document.getElementById('custom_dates').style.display = this.value === 'custom' ? 'block' : 'none';
  });
</script>
@endsection