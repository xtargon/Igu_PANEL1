<style>
    .M_T{
        width: 80%;
        overflow-x:scroll;
    }
    .M_T::-webkit-scrollbar {
          width: 10px; /* Ancho de la barra */
        }

        /* Modificar el color y el aspecto de la parte que se mueve (thumb) */
        .M_T::-webkit-scrollbar-thumb {
          background-color: #202326d1; /* Color del thumb */
          border-radius: 10px; /* Bordes redondeados */
        }

        /* Modificar el color y el estilo del área de la barra (track) */
        .M_T::-webkit-scrollbar-track {
          background-color: #f1f1f1; /* Color del track */
          border-radius: 10px; /* Bordes redondeados */
        }

        /* Cambiar el color del thumb cuando se pasa el cursor */
        .M_T::-webkit-scrollbar-thumb:hover {
          background-color: #555; /* Color cuando se pasa el mouse */
        }



        .M_T_S::-webkit-scrollbar {
          width: 10px; /* Ancho de la barra */
        }

        /* Modificar el color y el aspecto de la parte que se mueve (thumb) */
        .M_T_S::-webkit-scrollbar-thumb {
          background-color: #202326d1; /* Color del thumb */
          border-radius: 10px; /* Bordes redondeados */
        }

        /* Modificar el color y el estilo del área de la barra (track) */
        .M_T_S::-webkit-scrollbar-track {
          background-color: #f1f1f1; /* Color del track */
          border-radius: 10px; /* Bordes redondeados */
        }

        /* Cambiar el color del thumb cuando se pasa el cursor */
        .M_T_S::-webkit-scrollbar-thumb:hover {
          background-color: #555; /* Color cuando se pasa el mouse */
        }
</style>

<!-- Modal de Ver Transacciones -->
<div id="viewTransactionsModal" style="
    height: 100%;
    overflow-y: scroll;
" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg">
        <h2 class="text-xl font-bold mb-4 text-center">Transacciones</h2>

        <!-- Contenedor de transacciones -->
        <div id="transactionsList" class="mb-4 max-h-60 overflow-y-auto border rounded-md p-3 bg-gray-50">
            <!-- Aquí se cargarán las transacciones dinámicamente -->
            <p class="text-gray-500 text-center">No hay transacciones disponibles.</p>
        </div>

        <!-- Botón de cierre -->
        <div class="flex justify-center">
            <button type="button" class="close-modal bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">
                Cerrar
            </button>
        </div>
    </div>
</div>

