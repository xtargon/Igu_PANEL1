<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;

class RegisteredUserController extends Controller
{
    public function create()
    {
        return view('auth.register');
    }

    public function store(Request $request)
    {
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'role' => "administrador",
            'company' => $request->company,
            'password' => Hash::make($request->password),
            'owner' => 1, 
        ]);

        return redirect()->route('login')->with('success', 'Usuario registrado con éxito.');
    }
}
