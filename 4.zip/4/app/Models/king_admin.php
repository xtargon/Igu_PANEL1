<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class king_admin extends Model
{
    protected $fillable = ['correo', 'contraseña'];
}
