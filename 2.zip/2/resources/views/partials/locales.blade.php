@foreach($locales as $local)
<div x-data="{ open: false }" class="local-item mb-6 border border-gray-200 rounded-lg shadow-sm">
  <!-- Header del local -->
  <div class="bg-gray-100 px-4 py-3 flex justify-between items-center cursor-pointer" @click="open = !open">
    <h2 class="text-lg font-semibold text-gray-800">
      {{ $local->nombre }} - <span class="font-normal">Total Local:</span> {{ $local->total_sum }}
    </h2>
    <svg x-show="!open" class="w-5 h-5 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
    </svg>
    <svg x-show="open" class="w-5 h-5 transform rotate-180 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
    </svg>
  </div>
  <!-- Contenido del local -->
  <div x-show="open" class="px-4 py-3" x-transition>
    @foreach($local->machines as $machine)
    <div x-data="{ machineOpen: false }" class="mb-4 border border-gray-100 rounded-lg shadow">
      <!-- Header de la máquina -->
      <div class="bg-white px-4 py-2 flex justify-between items-center cursor-pointer" @click="machineOpen = !machineOpen">
        <div>
          <span class="font-bold text-gray-800">{{ $machine->nombre }}</span>
          <span class="text-gray-600"> - Total Máquina: {{ $overallSumMachineTotal }}</span>
        </div>
        <button type="button" class="text-blue-500 focus:outline-none" @click.stop="machineOpen = !machineOpen">
          <span x-show="!machineOpen">Ver transacciones</span>
          <span x-show="machineOpen">Ocultar transacciones</span>
        </button>
      </div>
      <!-- Tabla de transacciones -->
      <div x-show="machineOpen" class="overflow-x-auto" x-transition>
        <table class="min-w-full divide-y divide-gray-200 mt-2">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total In</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Out</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parcial In</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parcial Out</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            @foreach($machine->transacciones as $transaction)
            <tr>
              <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">{{ $transaction->fecha }}</td>
              <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">{{ $transaction->total_in }}</td>
              <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">{{ $transaction->total_out }}</td>
              <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">{{ $transaction->parcial_in }}</td>
              <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">{{ $transaction->parcial_out }}</td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
    @endforeach
  </div>
</div>
@endforeach

<!-- Resumen General -->
<div class="mt-6 p-4 bg-blue-50 rounded-lg shadow">
  <h4 class="text-xl font-semibold text-blue-700 mb-4">Resumen General</h4>
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
    <div class="text-center">
      <p class="text-sm text-gray-600">Total In</p>
      <p class="text-lg font-bold text-gray-800">{{ $overallSum['total_in'] }}</p>
    </div>
    <div class="text-center">
      <p class="text-sm text-gray-600">Total Out</p>
      <p class="text-lg font-bold text-gray-800">{{ $overallSum['total_out'] }}</p>
    </div>
    <div class="text-center">
      <p class="text-sm text-gray-600">Parcial In</p>
      <p class="text-lg font-bold text-gray-800">{{ $overallSum['parcial_in'] }}</p>
    </div>
    <div class="text-center">
      <p class="text-sm text-gray-600">Parcial Out</p>
      <p class="text-lg font-bold text-gray-800">{{ $overallSum['parcial_out'] }}</p>
    </div>
  </div>
</div>