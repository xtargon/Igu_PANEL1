
<?php $__env->startSection('content'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.30.1/moment.min.js"></script>

    <?php if(auth()->user()->role === 'administrador'): ?>
        <label for="searchInput" class="block text-gray-700 text-lg font-medium" style="display:inline-block;">Geolocalizacion<a href="/cars" style="width:25%; float:right; margin-bottom: 5px; display:inline-block;" ><button id="openCreateModal" style="background: turquoise;" class="bg-blue-500 text-white px-4 py-2 rounded-md">REGISTRAR NUEVO AUTO</button></a></label>
    <?php endif; ?>
    <?php echo $__env->make('admin.mapLoclas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/location.blade.php ENDPATH**/ ?>