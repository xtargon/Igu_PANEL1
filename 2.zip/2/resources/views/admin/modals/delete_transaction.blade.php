<!-- Modal de Eliminar Transacción -->
<div style="
    height: 100%;
    overflow-y: scroll;
" id="deleteTransactionModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-xl font-bold mb-4 text-center">Eliminar Transacción</h2>
        <p class="mb-4 text-center text-gray-700">¿Estás seguro de que deseas eliminar esta transacción?</p>
        
        <form id="deleteTransactionForm" method="POST" class="space-y-4">
            @csrf
            @method('DELETE')
            <input type="hidden" name="transaction_id" id="deleteTransactionId">

            <!-- Botones -->
            <div class="flex justify-center space-x-4">
                <button type="button" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition close-modal">Cancelar</button>
                <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition">Eliminar</button>
            </div>
        </form>
    </div>
</div>
