<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Panel Slots'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/fav.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/cssTailPanel.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.1/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.1/dist/flowbite.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://cdn.tailwindcss.com"></script>

    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>" defer></script>

    <link rel="icon" href="favicon.ico">
    <link href="<?php echo e(asset('assets/css/cssTailPanel.css')); ?>" rel="stylesheet">
   
    </head>
    <script src="<?php echo e(asset('assets/js/ja.js')); ?>"></script>
    <script defer src="<?php echo e(asset('assets/js/bundle.js')); ?>"></script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"9125748e7e97a699","version":"2025.1.0","r":1,"serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"67f7a278e3374824ae6dd92295d38f77","b":1}' crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <meta charset="UTF-8">

</head>

<body x-data="{ page: 'ecommerce', 'loaded': true, 'darkMode': false, 'stickyMenu': false, 'sidebarToggle': false, 'scrollTop': true }" x-init="
         darkMode = JSON.parse(localStorage.getItem('darkMode'));
         $watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))" :class="{'dark bg-gray-900': darkMode === true}">
         <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    <main>
<div class="mx-auto max-w-screen-2xl p-4 md:p-6">
  <div class="relative flex flex-col flex-1">
      <style>
            #editModal{
                margin-top:60px !important;
            }
          
      </style>

        <?php echo $__env->yieldContent('content'); ?>
    
  </div>
</div></main>
</body>
<style>
    
#openCreateModal{
    background: turquoise!important;
    float:right!important;
}
@media (max-width: 768px) {
    #openCreateModal {
        background: turquoise;
        width: 35% !important;
        margin: 10px auto!important;
        float: right;
        margin-top: -10px!important;
        
    }
}
td,th{
    text-align: center!important;
}
</style>
</html>

<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>