@extends('layouts.app')
@section('content')
<style>
    .M_E_p::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
        .pagination-btn {
            transition: background-color 0.3s ease;
        }
        .pagination-btn:hover {
            background-color: #2563eb; /* Cambia el color al pasar el mouse */
        }
        .pagination-btn.bg-blue-700 {
            background-color: #1e40af; /* Color para el botón activo */
        }
        .state{
           
        }
</style>

<script>
    const empresaIA = @json($empresa);

    function refreshMachinesForLocal(localId) {
      const $body = $('#machines-body-' + localId);
      $body.fadeTo(150, 0.3);
      $.ajax({
        url: '/locals/' + localId + '/machines-table',
        type: 'GET',
        success(html) {
          $body.html(html).fadeTo(150, 1);
        },
        error() {
          alert('Error al recargar máquinas para el local ' + localId);
          $body.fadeTo(150, 1);
        }
      });
    }    
</script>

<div class="M_E_p">
   <div class="mb-4">
        <label for="searchInput" class="block text-gray-700 text-lg font-medium">MAQUINAS</label>
        <input style="color: #6b7c84 !important;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-3/5 h-8 px-4 py-2 mt-5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
        @if(auth()->user()->role === 'administrador')
            <button id="openCreateModal" style="background: turquoise;" class="bg-blue-500 text-white px-4 py-2 rounded-md">NUEVA MAQUINA</button>
        @endif
    </div>
<style>
#openCreateModal{
    background: turquoise!important;
    float:right!important;
}
@media (max-width: 768px) {
    #openCreateModal {
        background: turquoise;
        width: 35% !important;
        margin: 10px auto!important;
        float: right;
        margin-top: -10px!important;
        
    }
}
}
  .small-table {
      font-size: 12px; /* Reducir el tamaño de la fuente */
  }
  .small-table th, .small-table td {
      padding: 4px 8px; /* Reducir el padding */
  }
  .small-table th {
      white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
  }
  .small-table td {
      white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
  }
  .small-table {
      width: 100%; /* Ajustar el ancho de la tabla */
      overflow-x: auto; /* Permitir scroll horizontal si es necesario */
  }
  
  td{
      color: #6b7c84 !important;
  }
  
</style>

<div class="container mx-auto p-4">
    @foreach ($locales as $local)
        <div x-data="{ open: false }" class="dark:bg-gray-800 rounded-lg shadow-sm mb-4 bg-white overflow-hidden">
            <!-- Botón del Acordeón -->
            <button @click="open = !open"
                class="w-full justify-between items-center px-4 py-3 transition duration-200">
                <svg style="float:left !important;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="dark:text-gray-400 size-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 21v-7.5a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349M3.75 21V9.349m0 0a3.001 3.001 0 0 0 3.75-.615A2.993 2.993 0 0 0 9.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 0 0 2.25 1.016c.896 0 1.7-.393 2.25-1.015a3.001 3.001 0 0 0 3.75.614m-16.5 0a3.004 3.004 0 0 1-.621-4.72l1.189-1.19A1.5 1.5 0 0 1 5.378 3h13.243a1.5 1.5 0 0 1 1.06.44l1.19 1.189a3 3 0 0 1-.621 4.72M6.75 18h3.75a.75.75 0 0 0 .75-.75V13.5a.75.75 0 0 0-.75-.75H6.75a.75.75 0 0 0-.75.75v3.75c0 .414.336.75.75.75Z" />
                </svg>

                <span class="text-lg font-semibold dark:text-gray-400 text-gray-800">{{ $local->nombre }}</span>
            </button>

            <!-- Contenido del Acordeón -->
            <div x-show="open" x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 max-h-0"
                x-transition:enter-end="opacity-100 max-h-screen"
                x-transition:leave="transition ease-in duration-200"
                x-transition:leave-start="opacity-100 max-h-screen"
                x-transition:leave-end="opacity-0 max-h-0"
                class="dark:text-gray-400 dark:bg-gray-800 px-4 py-2 bg-white">

                <!-- Tabla de Máquinas con todos los campos -->
                <div class="overflow-x-auto">
                <table class="dark:text-gray-400 dark:bg-gray-800 min-w-full rounded-md overflow-hidden shadow-sm mt-2">
                    <thead>
                        <tr class="bg-gray-50 text-gray-700 text-xs uppercase tracking-wider">
                            <th class="px-3 py-2 ">Nombre</th>
                            <th class="px-3 py-2 ">Status</th>
                            <th class="px-3 py-2 ">Juego</th>
                            <th class="px-3 py-2 ">Codigo</th>
                            <th class="px-3 py-2 ">Balance</th>
                            <th class="px-3 py-2 ">IA BALANCE</th>
                            <th class="px-3 py-2 ">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="machines-body-{{ $local->id }}">
                        @include('partials.local_tbody', ['machines' => $local->machines])
                    </tbody>
                </table>
                </div>

            </div>
        </div>
    @endforeach
</div>
 <div id="pagination" class="flex justify-center mt-4"></div>

<script>

$(document).ready(function () {
    const rowsPerPage = 10; 
    const $rows = $('#machines-table tr.GGG'); 
    const totalRows = $rows.length; 
    const totalPages = Math.ceil(totalRows / rowsPerPage); 

    function showPage(page) {
        $rows.hide(); 
        $rows.slice((page - 1) * rowsPerPage, page * rowsPerPage).show(); 
    }

    function createPaginationButtons() {
        let buttons = '';
        for (let i = 1; i <= totalPages; i++) {
            buttons += `<button class="px-4 py-2 mx-1 bg-blue-500 text-white rounded-md pagination-btn" data-page="${i}">${i}</button>`;
        }
        $('#pagination').html(buttons);
    }

    showPage(1);
    createPaginationButtons();

    $('#pagination').on('click', '.pagination-btn', function () {
        const page = $(this).data('page'); 
        showPage(page); 

        $('.pagination-btn').removeClass('bg-blue-700').addClass('bg-blue-500');
        $(this).removeClass('bg-blue-500').addClass('bg-blue-700');
    });

    $("#searchInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#machines-table tr").filter(function() {
            $(this).toggle(
                $(this).find("td:nth-child(0)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(4)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(1)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(5)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(3)").text().toLowerCase().indexOf(value) > -1   
            );
        });
    });




    $('.close-modal').on('click', function () {
        $(this).closest('#editModal').addClass('hidden');
        $(this).closest('#deleteModal').addClass('hidden');
        $(this).closest('#viewTransactionsModal').addClass('hidden');
    });
});

function loadNames(){
    
    document.querySelectorAll(".local-name").forEach(function(cell) {
        const localId = cell.dataset.localId;
        
        fetch(`/localsName/${localId}`)
            .then(response => {
                if (!response.ok) throw new Error('Error al obtener el nombre');
                return response.json();
            })
            .then(data => {
                cell.textContent = data.name;
            })
            .catch(() => {
                cell.innerHTML = `<p style="text-align:center; color: orange;"><svg style="margin-left: 30%;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" /></svg>`;
            });
    });

    document.querySelectorAll(".game-name").forEach(function(cell) {
        const gameId = cell.dataset.gameId;

        fetch(`/gamesName/${gameId}`)
            .then(response => {
                if (!response.ok) throw new Error('Error al obtener el nombre del juego');
                return response.json();
            })
            .then(data => {
                cell.textContent = data.name;
            })
            .catch(() => {
                cell.textContent = 'Error al cargar';
            });
    });
    
}

loadNames();

</script>
@if($empresa->ia_picture === 'on')
<div id="modalOverlay" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
    <div id="modalContent" class="bg-white w-full max-w-md mx-4 rounded-2xl shadow-xl p-6 relative scale-90 opacity-0 transition-all duration-300" style="margin-top:30px !important;">
        <button id="closeModalBtnPic" class="absolute top-4 right-4 text-gray-600 hover:text-gray-800 transition duration-200">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
        <h2 class="text-xl font-semibold mb-4">Balaces por imagen</h2>
                <div>
                    <label for="image" class="block text-gray-700 font-medium">Selecciona una imagen:</label>
                    <input type="file" id="image" name="image" accept="image/*"
                        class="w-full border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-300">
                </div>
                <form id="uploadForm" enctype="multipart/form-data" class="space-y-4">

                <div>
                    <label for="t_in" class="block text-sm font-medium text-gray-700">Total IN</label>
                    <input type="number" id="t_inIMG" name="parcial_in" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
                </div>
    
                <div>
                    <label for="t_out" class="block text-sm font-medium text-gray-700">Total OUT</label>
                    <input type="number" id="t_outIMG" name="parcial_out" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
                </div>
        
                <input type="text" id="filtersMachineByPictureBalance" name="filtermachine" required 
                        class="hidden w-full border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-300">

                <button type="submit" id="regTransac" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-all">
                   Actualizar 
                </button>
            </form>
        <div id="loader" class="hidden flex justify-center mt-4">
            <div class="w-8 h-8 border-4 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
        <div id="result" class="hidden mt-4 bg-gray-100 p-4 rounded shadow"></div>
    </div>
</div>

<script>
     $(document).ready(function() {
    let currentModalData = {
        buttonData: null,
        paramsForSendTransaction: null
    };

    let imageUploadAjax = null;
    let transactionAjax = null;

    function sendTransaction(docData) {
        const $submitButton = $('#regTransac');
        $submitButton.prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Procesando...');

        if (transactionAjax) {
            transactionAjax.abort();
        }

        transactionAjax = $.ajax({
            url: 'https://iguentertainment.com/api_insert.php',
            type: 'GET',
            data: docData,
            beforeSend: function() {
                Swal.fire({
                    title: 'Enviando Transacción...',
                    text: 'Por favor, espera un momento.',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
            },
            success: function (response) {
                $('#image').val('');
                Swal.fire({
                    icon: 'success',
                    title: '¡Transacción Exitosa!',
                    text: 'Los datos se han guardado correctamente.',
                    timer: 2500,
                    timerProgressBar: true,
                    showConfirmButton: false
                });
                $('#uploadForm')[0].reset();
                $('#modalContent').removeClass('scale-100 opacity-100').addClass('scale-90 opacity-0');
                setTimeout(() => {
                    $('#modalOverlay').addClass('hidden');
                    $('#t_inIMG, #t_outIMG').val('');
                    $submitButton.prop('disabled', true).removeClass('opacity-50 cursor-not-allowed').text('Registrar Transacción');
                    currentModalData.paramsForSendTransaction = null;
                }, 300);
            },
            error: function (xhr, status, error) {
                if (status === 'abort') {
                    console.log('Envío de transacción abortado.');
                    return;
                }
                Swal.fire({
                    icon: 'error',
                    title: 'Error en la Transacción',
                    text: `No se pudieron guardar los datos. ${error || 'Error desconocido.'}`
                });
                $submitButton.prop('disabled', false).removeClass('opacity-50 cursor-not-allowed').text('Registrar Transacción');
            },
            complete: function() {
                transactionAjax = null;
            }
        });
    }

    $(document).on('click', '.openModalBtnss', function () {
        const $btn = $(this);
        currentModalData.buttonData = {
            machine_fil: $btn.data('machine-filter'),
            machine_p_p: $btn.data('machine-p_p'),
            machine_owner: $btn.data('machine-owner'),
            machine_local: $btn.data('machine-local')
        };

        $('#uploadForm')[0].reset();
        $('#t_inIMG, #t_outIMG').val('');
        $('#filtersMachineByPictureBalance').val(currentModalData.buttonData.machine_fil);
        $('#regTransac').prop('disabled', false).addClass('').text('Registrar Transacción');

        $('#modalOverlay').removeClass('hidden');
        setTimeout(() => {
            $('#modalContent').removeClass('scale-90 opacity-0').addClass('scale-100 opacity-100');
        }, 10);
    });

    $('#image').off('change').on('change', function () {
        const fileInput = this;
        const $submitButton = $('#regTransac');

        if (!currentModalData.buttonData || !currentModalData.buttonData.machine_fil) {
            Swal.fire('Error', 'Faltan datos de la máquina. Por favor, cierra y reabre el modal.', 'error');
            return;
        }

        if (fileInput.files && fileInput.files[0]) {
            const formData = new FormData();
            formData.append('image', fileInput.files[0]);
            formData.append('filter', currentModalData.buttonData.machine_fil);

            $submitButton.prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Procesando Imagen...');

            if (imageUploadAjax) {
                imageUploadAjax.abort();
            }

            imageUploadAjax = $.ajax({
                url: '/apis.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    Swal.fire({
                        title: 'Procesando Imagen...',
                        text: 'Esto puede tardar unos segundos.',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function (data) {
                    Swal.close();
                    if (data && data.news && data.diferencias) {
                        $('#t_inIMG').val(data.news.newIn);
                        $('#t_outIMG').val(data.news.newOut);

                        currentModalData.paramsForSendTransaction = {
                            machine_id:      currentModalData.buttonData.machine_fil,
                            parcial_balance: data.diferencias.balance,
                            parcial_in:      data.diferencias.in,
                            parcial_out:     data.diferencias.out,
                            percentage_pay:  currentModalData.buttonData.machine_p_p,
                            owner:           currentModalData.buttonData.machine_owner,
                            local_id:        currentModalData.buttonData.machine_local,
                            total_in:        data.news.newIn,
                            total_out:       data.news.newOut,
                            total_balance:   data.news.newIn - data.news.newOut,
                        };
                        $submitButton.prop('disabled', false).removeClass('opacity-50 cursor-not-allowed').text('Registrar Transacción');
                        Swal.fire('¡Imagen Procesada!', 'Los datos de la imagen se han cargado correctamente.', 'success');
                    } else {
                        Swal.fire('Error de Respuesta', 'El servidor devolvió datos inesperados al procesar la imagen.', 'error');
                        $submitButton.prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Registrar Transacción');
                        currentModalData.paramsForSendTransaction = null;
                    }
                },
                error: function (xhr, status, error) {
                    Swal.close();
                    if (status === 'abort') {
                        console.log('Subida de imagen abortada.');
                        return;
                    }
                    Swal.fire('Error al Cargar Imagen', `No se pudo procesar la imagen. ${error || 'Error desconocido.'}`, 'error');
                    $submitButton.prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Registrar Transacción');
                    currentModalData.paramsForSendTransaction = null;
                },
                complete: function() {
                    imageUploadAjax = null;
                }
            });
        } else {
            $('#t_inIMG, #t_outIMG').val('');
            $submitButton.prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Registrar Transacción');
            currentModalData.paramsForSendTransaction = null;
        }
    });

    $('#uploadForm').off('submit').on('submit', function(e) {
        e.preventDefault();

        if (currentModalData.paramsForSendTransaction) {
            sendTransaction(currentModalData.paramsForSendTransaction);
        } else {
            const t_in = $('#t_inIMG').val();
            const t_out = $('#t_outIMG').val();
            const balance = t_in - t_out;
            const machine_id = $('#filtersMachineByPictureBalance').val();

            if (t_in && t_out && balance && machine_id) {
                const manualData = {
                    machine_id: machine_id,
                    parcial_balance: balance,
                    parcial_in: t_in,
                    parcial_out: t_out,
                    percentage_pay: currentModalData.buttonData?.machine_p_p || 0,
                    owner: currentModalData.buttonData?.machine_owner || '',
                    local_id: currentModalData.buttonData?.machine_local || '',
                    total_in: t_in,
                    total_out: t_out,
                    total_balance: t_in - t_out
                };
                sendTransaction(manualData);
            } else {
                Swal.fire({
                    icon: 'warning',
                    title: 'Datos incompletos',
                    text: 'Por favor, completa manualmente los campos IN, OUT y Balance o carga una imagen.'
                });
            }
        }
    });

    $('#closeModalBtnPic').off('click').on('click', function () {
        $('#modalContent').removeClass('scale-100 opacity-100').addClass('scale-90 opacity-0');
        setTimeout(() => {
            $('#modalOverlay').addClass('hidden');
            $('#uploadForm')[0].reset();
            $('#t_inIMG, #t_outIMG').val('');
            $('#regTransac').prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Registrar Transacción');
            currentModalData = { buttonData: null, paramsForSendTransaction: null };

            if (imageUploadAjax) {
                imageUploadAjax.abort();
                imageUploadAjax = null;
            }
            if (transactionAjax) {
                transactionAjax.abort();
                transactionAjax = null;
            }
        }, 300);
    });
});
</script>
@endif

@include('admin.modals.edit_machine')
@include('admin.modals.create_machine')
@include('admin.modals.delete')
@include('admin.modals.view-transactions')
@include('admin.modals.delete_transaction')

@endsection
