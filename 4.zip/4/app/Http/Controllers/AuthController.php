<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Carbon\Carbon;
use App\Models\Empresas;

class AuthController extends Controller
{
        public function showLogin()
        {   
            if (auth()->check()) {
                if(auth()->user()->created === 23){
                    return redirect('/admin');
                }else{
                    return redirect('/dashboard');
                }
            }
            return view('auth.login');
        }


    public function login(Request $request)
    {
        // Validar las credenciales
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {

            $user = Auth::user();
            $company = Empresas::where('id', Auth::user()->company_id)->first();

            $request->session()->regenerate();
            $token = encrypt($user->id);
            Cookie::queue('custom_auth', $token, 1940);

            return redirect()->intended('dashboard');
        }
        else{
            return response()->json([
                'log' => 'no'
            ]);
        }
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        Cookie::queue(Cookie::forget('custom_auth'));
        return redirect()->route('login');
    }
}
