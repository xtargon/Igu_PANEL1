
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<div id="editModal" style="
    height: 100%;
    overflow-y: scroll;
" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center p-4">
    <div style="
    height: 88%;
    overflow-y: scroll;
     margin-top:-35px;"
    class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-xl font-bold mb-4 text-center">Configurar Maquina</h2>

        <form id="editMachineForm" class="space-y-4">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" id="editMachineId" name="machine_id">

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700">Nombre</label>
                <input type="text" id="name" name="nombre" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
            </div>

            <div>
                <label class="block text-gray-700">Local</label>
                <select name="local" id="localAdd2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    
                </select>
            </div>

            <div>
                <label for="p_p" class="block text-sm font-medium text-gray-700">Porcentage de pago</label>
                <input type="number" id="p_p" name="p_p" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm px-3 py-2">
            </div>

            <div>
                <label class="block text-gray-700">Acumulado 1</label>
                <input style="margin:5px;" type="number" id="acumulated1" name="acumulated1_1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 inicial" required>
                <input style="margin:5px;" type="number" id="acumulated1_2" name="acumulated1_2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 actual" required>
                <input style="margin:5px;" type="number" id="acumulated1_3" name="acumulated1_3" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 maximo" required>
                <input style="margin:5px;" type="number" id="acumulated1_4" name="acumulated1_4" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 aumento %" required>
                <input style="margin:5px;" type="number" id="acumulated1_5" name="acumulated1_5" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 1 ganancia para pagar" required>
            </div>
            
            <div>
                <label class="block text-gray-700">Acumulado 2</label>
                <input style="margin:5px;" type="number" id="acumulated2" name="acumulated2_1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 inicial" required>
                <input style="margin:5px;" type="number" id="acumulated2_2" name="acumulated2_2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 actual" required>
                <input style="margin:5px;" type="number" id="acumulated2_3" name="acumulated2_3" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 maximo" required>
                <input style="margin:5px;" type="number" id="acumulated2_4" name="acumulated2_4" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 aumento %" required>
                <input style="margin:5px;" type="number" id="acumulated2_5" name="acumulated2_5" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 2 ganancia para pagar" required>
            </div>
            
            <div>
                <label class="block text-gray-700">Acumulado 3</label>
                <input style="margin:5px;" type="number" id="acumulated3" name="acumulated3_1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 inicial" required>
                <input style="margin:5px;" type="number" id="acumulated3_2" name="acumulated3_2" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 actual" required>
                <input style="margin:5px;" type="number" id="acumulated3_3" name="acumulated3_3" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 maximo" required>
                <input style="margin:5px;" type="number" id="acumulated3_4" name="acumulated3_4" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 aumento %" required>
                <input style="margin:5px;" type="number" id="acumulated3_5" name="acumulated3_5" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="jackpot 3 ganancia para pagar" required>
            </div>
            
            <button id="btn-reset" class="bg-blue-500 hover:from-blue-600 hover:blue-800 text-white font-bold py-2 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor"
                                    class="icon-move size-6 transition-all duration-300">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5.636 5.636a9 9 0 1 0 12.728 0M12 3v9" />
                                </svg>

                              <span class="text-fade ml-2 transition-all duration-300">Resetear maquina</span>
            </button>            
            
            <hr>
            <input type="number" id="filters" name="filters" class="hidden" disabled required>

            <!-- Botones -->
            <div class="flex justify-center space-x-4">
                <button type="button" class="close-modal bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>

    </div>
</div>
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/modals/edit_machine.blade.php ENDPATH**/ ?>