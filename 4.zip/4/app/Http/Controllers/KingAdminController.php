<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

use App\Models\Transaction;
use App\Models\king_admin;
use App\Models\User;
use App\Models\Machine;
use App\Models\Local;
use App\Models\Log;
use App\Models\Game;
use App\Models\Empresas;

class KingAdminController extends Controller
{
    public function index()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if(auth()->user()->created !== 23){
            return redirect('/dashboard');
        }

        if( auth()->user()->created === 23){
            //$locals = Local::where('owner', auth()->user()->company_id)->get();
            //$totalLocals = $locals->count();
            $users = User::where('role', 'administrador')->get();
            return view('admin.index', compact('users'));
        }
        
    }

    public function getUsers()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->created !== 23){
            return redirect('/users');
        }
        $users = User::all();
        return view('admin.users_admin', compact('users'));
    }

    public function getGames()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->created !== 23){
            return redirect('/games');
        }
        $games = Game::all();
        return view('admin.games_admin', compact('games'));
    }

    public function getMachines()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->created !== 23){
            return redirect('/machines');
        }
        $machines = Machine::all();
        return view('admin.machines_admin', compact('machines'));
    }

    public function getLocals()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->created !== 23){
            return redirect('/locals');
        }
        $locals = Local::all();
        return view('admin.locals_admin', compact('locals'));
    }

    public function getLogs()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->created !== 23){
            return redirect('/logs');
        }
        $logs = Log::all();
        return view('admin.logs_admin', compact('logs'));
    }

    public function createUser(Request $request)
    {
        if($request->address !== ''){
            $company = Empresas::create([
                'nombre' => $request->company,
                'telefono' => $request->telefono,
                'direccion' => $request->address,
                'share' => $request->share,
                'last_recharge' => Carbon::today()->format('Y-m-d'),
            ]);
        }else{
            $company = Empresas::create([
                'nombre' => $request->company,
                'telefono' => $request->telefono,
                'direccion' => '',
                'share' => $request->share,
                'last_recharge' => Carbon::today()->format('Y-m-d'),
            ]);
        }
        // Actualizar el campo company_id
        $eID = $company->id;
        
        if(auth()->user()->created === 23){
            $us = User::create([
                'name' => $request->name,
                'local' => null,
                'company_id' => $eID,
                'email' => $request->email,
                'role' => 'administrador',
                'company' => $request->company,
                'password' => $request->password,
                'owner' => Auth::user()->id,
                'created' => 1,
                'phone' => $request->telefono,
                'last_recharge' => Carbon::today()->format('Y-m-d'),
            ]);
        }
        return response()->json(['success' => true, 'client' => $us, 'company' => $company]);
    }

    public function updateCoins(Request $request)
    {
        $company = Empresas::find($request->company_id);
    
        if (!$company) {
            return response()->json(['error' => 'Compañía no encontrada'], 404);
        }
    
        $original = $company->coins;
        $company->coins += $request->value;
        $company->save();
    
        return response()->json([
            'success' => true,
            'message' => 'Monedas actualizadas correctamente',
            'original_coins' => $original,
            'new_coins' => $company->coins,
            'change' => $request->value,
            'type' => $request->value >= 0 ? 'suma' : 'resta'
        ]);
    }

    public function updateUser(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $company = Empresas::findOrFail($user->company_id);
        
        
        if($request->password === null){
            $company->update($request->only('geo', 'direccion', 'ia_picture', 'share', 'coins'));
            $user->update($request->only('name', 'email', 'role'));
        }else{
           $company->update($request->only('geo', 'direccion', 'ia_picture', 'share', 'coins'));
           $user->update($request->only('name', 'email', 'role', 'password'));
        }
        
        return response()->json(['success' => true, 'client' => $user]);
    }
    public function getMe()
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        $user = User::where('id', auth()->user()->id);
        return view('admin.user_me_admin', compact('user'));
    }
    public function updateUser_me(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $user->update($request->all());
        return response()->json($user);
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return response()->json(['success' => true]);
    }

    public function getTransfers()
    {
        return response()->json(Transferencia::all());
    }

    public function getMovements()
    {
        return response()->json(Movimiento::all());
    }
}
