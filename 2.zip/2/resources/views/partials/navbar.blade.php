<nav style="background: #0b340d69;color: floralwhite;"  class="fixed top-0 z-50 w-full border-b border-gray-200 dark:bg-gray-800 dark:border-gray-700">
    <div class="px-3 py-3 lg:px-5 lg:pl-3">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" 
                    aria-controls="logo-sidebar" type="button" 
                    class="inline-flex items-center p-2 text-sm text-gray-500 rounded-lg sm:hidden 
                    hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 
                    dark:hover:bg-gray-700 dark:focus:ring-gray-600">
                </button>
                <a href="#" class="flex ms-2 md:me-24">
                    <span class="self-center text-xl font-semibold sm:text-2xl whitespace-nowrap dark:text-white">Control - Panel</span>
                </a>
            </div>
            <div class="flex items-center">
                <div class="flex items-center ms-3">
                    <div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>

