<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;


class UserController extends Controller
{
    public function store(Request $request)
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->role !== 'administrador'){
            return redirect('/dashboard');
        }

        if(auth()->user()->created === 1){
               if($request->role === "usuario"){
                    $us = User::create([
                    'name' => $request->name,
                    'local' => $request->locals,
                    'email' => $request->email,
                    'company_id' => Auth::user()->company_id,
                    'role' => $request->role,
                    'company' => Auth::user()->company,
                    'password' => $request->password,
                    'owner' => Auth::user()->owner,
                    'created' => 0,
                    'last_recharge' => Carbon::today()->format('Y-m-d'),
                ]);
            }else{
                $us = User::create([
                    'name' => $request->name,
                    'local' => $request->locals,
                    'email' => $request->email,
                    'company_id' => Auth::user()->company_id,
                    'role' => $request->role,
                    'company' => Auth::user()->company,
                    'password' => $request->password,
                    'owner' => Auth::user()->owner,
                    'created' => 1,
                    'last_recharge' => Carbon::today()->format('Y-m-d'),
                ]);
            }
        }
        if(auth()->user()->created === 23){
            $us = User::create([
                'name' => $request->name,
                'local' => $request->locals,
                'company_id' => Auth::user()->company_id,
                'email' => $request->email,
                'role' => $request->role,
                'company' => Auth::user()->company,
                'password' => $request->password,
                'owner' => Auth::user()->id,
                'created' => 1,
                'last_recharge' => Carbon::today()->format('Y-m-d'),
            ]);
        }
        return response()->json(['success' => true, 'user' => $us, 'user_id' => Auth::user()->id]);
    }

    public function index(Request $request)
    {
        if (!auth()->check()) {
            return redirect('/');
        }
        if(auth()->user()->company_id === null){
            return redirect('/company');
        }
        if(auth()->user()->role !== 'administrador'){
            return redirect('/dashboard');
        }

        $users = User::where('company_id', Auth::user()->company_id)->get();
        return view('users', compact('users'));
    }

    public function index_me(Request $request)
    {
        $users = User::where('id', Auth::user()->id)->get();
        return view('user_me', compact('users'));
    }

    public function getting(Request $request)
    {
        if( auth()->user()->created === 23){
            $users_all = User::all();
            return response()->json($users_all);            
        }
        if(Auth::user()->created === 1){
            $users = User::whereNot('created', 23)->where('company_id', auth()->user()->company_id)->get();
            return response()->json($users);
        }else{
            $users = User::where('company_id', Auth::user()->company_id)->whereNot('created', 23)->get();
            return response()->json($users);
        }

    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);
        if($request->password === null){
            $user->update($request->only('name', 'email', 'role', 'phone', 'local' ));
        }
        else{
           $user->update($request->only('name', 'email', 'role', 'local', 'phone', 'password'));
        }
        return response()->json(['user' => $user]);
    }

    public function gettingUpdate($id)
    {
        $user = User::findOrFail($id);
        
        if($user){
            return response()->json(['user' => $user]);
        }
        else{
            return response()->json(['message' => 'Usuario no encontrado'], 404);
        }
    }

    public function update_me(Request $request)
    {
        $user = User::find(Auth::user()->id);

        if (!$user) {
            return response()->json(['message' => 'Usuario no encontrado'], 404);
        }

        $user->update($request->all());

        return response()->json(['user' => $user]);
    }

    public function find(Request $request)
    {

        $user = \App\Models\User::find($request->idUser)->makeVisible('password');

        return response()->json($user);
    }

    public function show(Request $request)
    {
        $user = User::find(Auth::user()->id);

        if (!$user) {
            return response()->json(['message' => 'Usuario no encontrado'], 404);
        }

        return response()->json($user);
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return response()->json(['success' => true]);
    }


    
}


