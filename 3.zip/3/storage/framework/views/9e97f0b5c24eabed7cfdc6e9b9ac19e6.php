
<?php $__env->startSection('content'); ?>
<style>
    .M_E_p::-webkit-scrollbar {
          width: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb {
          background-color: #202326d1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-track {
          background-color: #f1f1f1; 
          border-radius: 10px; 
        }

        .M_E_p::-webkit-scrollbar-thumb:hover {
          background-color: #555; 
        }
        .pagination-btn {
            transition: background-color 0.3s ease;
        }
        .pagination-btn:hover {
            background-color: #2563eb; /* Cambia el color al pasar el mouse */
        }
        .pagination-btn.bg-blue-700 {
            background-color: #1e40af; /* Color para el botón activo */
        }
</style>

<div class="M_E_p" style="overflow-x:scroll;">
   <div class="mb-4">
        <label for="searchInput" class="block text-gray-700 text-lg font-medium">Maquinas</label>
        <input style=" width:60%;height:8;" type="text" id="searchInput" placeholder="Buscar..." name="local" class="w-full px-4 py-5 mt-5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required="">
        <?php if(auth()->user()->role === 'administrador'): ?>
            <button id="openCreateModal" style="background: turquoise; width:25%; margin-top:22px; float:right;" class="bg-blue-500 text-white px-4 py-2 rounded-md">Nueva maquina</button>
        <?php endif; ?>
    </div>
    <style>
    .small-table {
        font-size: 12px; /* Reducir el tamaño de la fuente */
    }
    .small-table th, .small-table td {
        padding: 4px 8px; /* Reducir el padding */
    }
    .small-table th {
        white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
    }
    .small-table td {
        white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
    }
    .small-table {
        width: 100%; /* Ajustar el ancho de la tabla */
        overflow-x: auto; /* Permitir scroll horizontal si es necesario */
    }
</style>

<table class="small-table" style=" width:100%; min-width:100px;" class="min-w-full leading-normal">
    <thead>
        <tr>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nombre</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">local</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">transactions</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">filters</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">state</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">juego</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">%Pago</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">parcial in</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">parcial out</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">total in</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">total out</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">balance</th>
            <th class="px-2 py-1 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
        </tr>
    </thead>
    <tbody id="machines-table">
        <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="GGG" data-machine-id="<?php echo e($machine->id); ?>">
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->nombre); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->local); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->transactions); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->filters); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->state); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->juego); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->p_p); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->parcial_in); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->parcial_out); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->total_in); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->total_out); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <?php echo e($machine->balance); ?>

        </td>
        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
            <!-- Botones de acciones -->
            <button style="//margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md edit-btn" data-machine-filters="<?php echo e($machine->filters); ?>" data-machine-balance="<?php echo e($machine->balance); ?>" data-machine-total_out="<?php echo e($machine->total_out); ?>" data-machine-total_in="<?php echo e($machine->total_in); ?>" data-machine-parcial_out="<?php echo e($machine->parcial_out); ?>" data-machine-parcial_in="<?php echo e($machine->parcial_in); ?>" data-machine-local="<?php echo e($machine->local); ?>"  data-machine-state="<?php echo e($machine->state); ?>" data-machine-name="<?php echo e($machine->nombre); ?>" data-machine-id="<?php echo e($machine->id); ?>"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" /></svg></button>
            <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md delete-btn" data-machine-id="<?php echo e($machine->id); ?>"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" /></svg></button>
            <button style="margin-top:3px;" class="bg-green-500 text-white px-3 py-1 rounded-md view-transactions-btn" data-local-id="<?php echo e($machine->local); ?>"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" /></svg></button>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
 </div>
 <div id="pagination" class="flex justify-center mt-4"></div>

<?php echo $__env->make('admin.modals.edit_machine', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modals.create_machine', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modals.view-transactions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modals.delete_transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script>
$(document).ready(function () {

    const rowsPerPage = 10; 
    const $rows = $('#machines-table tr.GGG'); 
    const totalRows = $rows.length; 
    const totalPages = Math.ceil(totalRows / rowsPerPage); 

    function showPage(page) {
        $rows.hide(); 
        $rows.slice((page - 1) * rowsPerPage, page * rowsPerPage).show(); 
    }

    function createPaginationButtons() {
        let buttons = '';
        for (let i = 1; i <= totalPages; i++) {
            buttons += `<button class="px-4 py-2 mx-1 bg-blue-500 text-white rounded-md pagination-btn" data-page="${i}">${i}</button>`;
        }
        $('#pagination').html(buttons);
    }

    showPage(1);
    createPaginationButtons();

    $('#pagination').on('click', '.pagination-btn', function () {
        const page = $(this).data('page'); 
        showPage(page); 

        $('.pagination-btn').removeClass('bg-blue-700').addClass('bg-blue-500');
        $(this).removeClass('bg-blue-500').addClass('bg-blue-700');
    });

    $("#searchInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#machines-table tr").filter(function() {
            $(this).toggle(
                $(this).find("td:nth-child(0)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(4)").text().toLowerCase().indexOf(value) > -1 ||
                $(this).find("td:nth-child(1)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(5)").text().toLowerCase().indexOf(value) > -1 || 
                $(this).find("td:nth-child(3)").text().toLowerCase().indexOf(value) > -1   
            );
        });
    });

    $('.GGG').on('click', '.edit-btn', function () {
        const machineId = $(this).data('machine-id');
        const name = $(this).data('machine-name');
        const state = $(this).data('machine-state');
        const parcial_in = $(this).data('machine-parcial_in');
        const parcial_out = $(this).data('machine-parcial_out');
        const total_in = $(this).data('machine-total_in');
        const total_out = $(this).data('machine-total_out');
        const filters = $(this).data('machine-filters');
        const balance = $(this).data('machine-balance');


        $('#editModal').removeClass('hidden');
        $('#name').val(name);
        $('#editMachineId').val(machineId);
        $('#state').val(state);
        $('#p_in').val(parcial_in);
        $('#p_out').val(parcial_out);
        $('#t_in').val(total_in);
        $('#t_out').val(total_out);
        $('#filters').val(filters);
        $('#balance').val(balance);

    });

    $('#editMachineForm').on('submit', function (e) {
        e.preventDefault();
        const machineId = $('#editMachineId').val();

        $.ajax({
            url: `/machines/${machineId}`,
            method: 'PUT',
            data: $(this).serialize(),
            success: function (res) {
                $('#editModal').addClass('hidden');

                $(`tr[data-machine-id="${machineId}"]`).html(`
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.nombre}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.local}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.transactions}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.filters}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.state}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.juego}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.p_p}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.parcial_in}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.parcial_out}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.total_in}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.total_out}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">${res.machine.balance}</td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <button class="bg-blue-500 text-white px-3 py-1 rounded-md mr-2 edit-btn" data-machine-filters="${ res.machine.filters }" data-machine-balance="${ res.machine.balance }" data-machine-total_out="${ res.machine.total_out }" data-machine-total_in="${ res.machine.total_in }" data-machine-parcial_out="${ res.machine.parcial_out }" data-machine-parcial_in="${ res.machine.parcial_in }" data-machine-local="${ res.machine.local }"  data-machine-state="${ res.machine.state }" data-machine-name="${ res.machine.nombre }" data-machine-id="${ res.machine.id }">Editar</button>
                        <button class="bg-red-500 text-white px-3 py-1 rounded-md mr-2 delete-btn" data-machine-id="${res.machine.id}">Eliminar</button>
                        <button class="bg-green-500 text-white px-3 py-1 rounded-md view-transactions-btn" data-local-id="${res.machine.local}">Ver Transacciones</button>
                    </td>
                `);
            },
            error: function (xhr) {
            }
        });
    });

    $('.GGG').on('click', '.delete-btn', function () { 
        const machineId = $(this).data('machine-id');
        $('#deleteModal').removeClass('hidden');
        $('#deleteUserId').val(machineId);
    });

    $('#deleteUserForm').on('submit', function (e) {
        e.preventDefault();
        const machineId = $('#deleteUserId').val();

        $.ajax({
            url: `/machines/${machineId}`,
            method: 'DELETE',
            data: $(this).serialize(),
            success: function (response) {
                $('#deleteModal').addClass('hidden');
                $(`tr[data-machine-id="${machineId}"]`).remove();

            },
            error: function (xhr) {
            }
        });
    });

    $('.view-transactions-btn').on('click', function () {
        var localId = $(this).data('local-id');
        var URLs = `/machines/local/${localId}/`;

        $('#viewTransactionsModal').removeClass('hidden');

        function loadTransactions(M){
          console.log(M[0].id)
          var URLsM = `/transactions/${M[0].id}/`;

         $.ajax({
              url: URLsM,
              method: 'GET',
              success: function (res) {
                  if (res.transaction && res.transaction.length > 0) {
                      $('#transactionsList').html('');

                      let table = `
                          <table class="min-w-full bg-white">
                              <thead>
                                  <tr>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">ID</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Total IN</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Total OUT</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Balance Total</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Balance Parcial</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">IN Parcial</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">OUT Parcial</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">% Pago</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha</th>
                                      <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
                                  </tr>
                              </thead>
                              <tbody>
                      `;

                      res.transaction.forEach(function (transaction) {
                          table += `
                              <tr>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.id}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.total_in}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.total_out}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.total_balance}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_balance}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_in}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_out}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.percentage_pay}%</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.fecha}</td>
                                  <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">
                                      <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-transaction-btn" data-transaction-id="${transaction.id}">Eliminar</button>
                                  </td>
                              </tr>
                          `;
                      });

                      table += `
                              </tbody>
                          </table>
                      `;

                      $('#transactionsList').html(table);

                      $('.delete-transaction-btn').on('click', function () {
                          const transactionId = $(this).data('transaction-id');
                          $('#deleteTransactionModal').removeClass('hidden');
                          $('#deleteTransactionId').val(transactionId); 
                      });
                  } else {
                      $('#transactionsList').html('<p class="text-gray-600">No hay transacciones para esta maquina.</p>');
                  }
              },
              error: function (xhr) {
                $('#transactionsList').html('<p class="text-gray-600">No hay transacciones para el local de esta maquina</p>');
            }
          });

            $('#deleteTransactionForm').on('submit', function (e) {
              e.preventDefault();
                const transactionId = $('#deleteTransactionId').val();

                $.ajax({
                    url: `/transactions/${transactionId}`,
                    method: 'DELETE',
                    data: $(this).serialize(),
                    success: function (response) {
                        alert('Transacción eliminada correctamente.');
                        $('#deleteTransactionModal').addClass('hidden');
                        location.reload(); 
                    },
                    error: function (xhr) {
                        alert('Error al eliminar la transacción.');
                    }
                });
            });


        }

        $.ajax({
            url: URLs,
            method: 'GET',
            success: function (res) {
                $('#transactionsList').html(res);
                loadTransactions(res);
            },
            error: function (xhr) {
            }
        });
    });

    $('.close-modal').on('click', function () {
        $(this).closest('#editModal').addClass('hidden');
        $(this).closest('#deleteModal').addClass('hidden');
        $(this).closest('#viewTransactionsModal').addClass('hidden');
    });
});
</script>

<?php $__env->stopSection(); ?>

<script>
   /* $(document).ready(function() {
        $("#searchInput").on("keyup", function() {
            var value = $(this).val().toLowerCase(); // Obtener el texto de búsqueda y convertirlo a minúsculas
            $("#machine-table tr").filter(function() {
                // Buscar dentro del ID, Local y Estado
                $(this).toggle(
                    $(this).find("td:nth-child(4)").text().toLowerCase().indexOf(value) > -1 ||
                    $(this).find("td:nth-child(1)").text().toLowerCase().indexOf(value) > -1 || 
                    $(this).find("td:nth-child(2)").text().toLowerCase().indexOf(value) > -1 || 
                    $(this).find("td:nth-child(3)").text().toLowerCase().indexOf(value) > -1   
                );
            });
        });

        // Abrir el modal
        $('#open-modal-machine').click(function() {
            let createInput1 = $("#localAdd");
            let createInput2 = $("#gameAdd");
            $.get('/locals_getting', function (data) {
                data.forEach(loc => { 
                     let rowLocal = `<option value="${loc.id}">${loc.nombre}</option>`;
                     createInput1.append(rowLocal);
                });
            });
            $.get('/games_getting', function (data) {
                data.games.forEach(loc => { 
                     let rowGame = `<option value="${loc.id}">${loc.nombre}</option>`;
                     createInput2.append(rowGame);
                });
            });


        });

        // Cerrar el modal
        $('#closeModal').click(function() {
            $('#modal').addClass('hidden opacity-0').removeClass('opacity-100');
            $('#modal .transform').removeClass('scale-100').addClass('scale-95');
        });

        // Cerrar el modal al hacer clic fuera del modal
        $('#modal').click(function(e) {
            if ($(e.target).closest('.transform').length === 0) {
                $('#modal').addClass('hidden opacity-0').removeClass('opacity-100');
                $('#modal .transform').removeClass('scale-100').addClass('scale-95');
            }
        });

        $('#createMachineForm').on('submit', function(e) {
            e.preventDefault();

            let formData = $(this).serialize(); 
            $('#submitBtn').attr('disabled', true); 

            $.ajax({
                url: '<?php echo e(route('machines.store')); ?>',
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        
                        loadMachines();
                        $('#modal').addClass('hidden opacity-0').removeClass('opacity-100');
                        $('#modal .transform').removeClass('scale-100').addClass('scale-95');
                        $('#createMachineForm')[0].reset();
                        $('#submitBtn').attr('disabled', false);
                        $("#machine-table").empty();
                        $('#modal .transform').removeClass('scale-100').addClass('scale-95');
                    } else {
                        alert('Hubo un error. Intenta nuevamente.');
                        $('#submitBtn').attr('disabled', false);
                    }
                },
                error: function(xhr, status, error) {
                    alert('Debes crear un local y un juego primero');
                    $('#submitBtn').attr('disabled', false);
                }
            });
        });
    });


    function loadMachines() {
        $.get('/machine', function (data) {
            console.log(data.machine); 
            let tableBody = $("#machine-table");

                if (data.length === 0) {
                    tableBody.append("<tr><td colspan='4'>No se encontraron resultados</td></tr>");
                } else {
                    var machines = data.machine;
                    $("#numT").text(machines.length)
                    machines.forEach(doc => {  
                        console.log(doc.local)
                        let row = `
                            <tr data-id=${doc.id} class="assemble">
                                <td class="py-4 text-sm text-gray-600 flex flex-row items-center text-left">
                                    <div class="w-8 h-8 overflow-hidden mr-3">
                                        <img src="<?php echo e(asset("/img/icon-connect.svg")); ?>" class="object-cover">
                                    </div>
                                     ${doc.local} 
                                </td>
                                <td class="py-4 text-xs text-gray-600">${doc.filters}<span class="num-3"></span></td>
                                <td class="py-4 text-xs text-gray-600">${doc.state}<span class="num-3"></span></td>
                                <td class="py-4 text-xs text-gray-600">${doc.id}</td>
                            </tr> `;
                        tableBody.append(row);
                    });
                }
        });
    }

    $("#machine-table").on('click', '.assemble', function() {
        function printDetails(nameGame, id){
            console.log("ID del local "+id);
                $.ajax({
                url: `/locals/find`,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    idUser: id
                },
                success: function(doc) {
                    let thisPrint = `
                        <li style="margin-top: 17px; list-style: none;" class="">
                            <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-gamepad"></i> ${nameGame}</p>
                        </li> 
                        <li style="margin-top: 17px; list-style: none;" class="">
                            <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-store"></i> ${doc[0].nombre}</p>
                        </li>     
                    `;
                    $("#itemsPrint").append(thisPrint);
                }
            });
        }


        var machID = $(this).data('id');
        $('#viewM').removeClass('hidden').addClass('scale-95');
        $.get(`/machines/${machID}`, function (doc) {
          console.log(doc.local); 
          let view2 = `
            <p style="padding:7px; text-align: end; float:right;">
                <button 
                data-filters="${doc.filters}" 
                    data-transactions="${doc.transactions}" 
                    data-state="${doc.state}" 
                    data-local="${doc.local}" 
                    data-id="${doc.id}"
                    data-nombre="${doc.name}"
                    id="userEditBtn"
                    class="userEditBtn rounded-full text-white badge bg-teal-400 text-xs"
                    style="background: #42a071;" 
                    type="button">
                    <i class="fad fa-cogs"></i> editar
                </button>

                <a href="/transactions/${doc.id}" 
                    class="hrefMachineBtn rounded-full text-white badge bg-red-400 text-xs"
                    style="background:rgb(62, 140, 157);" 
                    type="button">
                    <i class="fas fa-money-check-edit-alt"></i> Transacciones
                </a>

              <button 
                  data-id="${doc.id}" 
                  class="deleteMachineBtn rounded-full text-white badge bg-red-400 text-xs"
                  style="background: #c75b5b;" 
                  type="button">
                  <i class="fad fa-trash-restore"></i> Eliminar
              </button>

            </p>
                 <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fad fa-desktop"></i> ${doc.nombre}</p>
                 </li> 
                 
                 <div id="itemsPrint"></div>

                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-envelope-open-dollar"></i> ${doc.transactions}</p>
                  </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-filter"></i> ${doc.filters}</p>
                  </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-toggle-on"></i> ${doc.state}</p>
                  </li>

                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-percentage"></i> ${doc.p_p}</p>
                  </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-arrow-alt-circle-down"></i> ${doc.total_in}</p>
                  </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-hand-holding-usd"></i> ${doc.total_out}</p>
                  </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-coins"></i> ${doc.parcial_in}</p>
                  </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-align-left"></i> ${doc.parcial_out}</p>
                  </li> 
                  <li style="margin-top: 17px; list-style: none;" class="">
                    <p><i style="display:inline-block;margin-right:10px;  padding:13px; border-radius:100%;" class="bg-teal-200 text-teal-700 border-teal-300 border rounded-full fas fa-balance-scale"></i> ${doc.balance}</p>
                  </li>`;
          $("#datas").append(view2);

          $.ajax({
            url: `/games/find`,
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                idUser: doc.juego
            },
            success: function(game) {printDetails(game[0].nombre, doc.local);}
          });

        });
        $('#closeViewModal').click(function() {
            $('#viewM').addClass('hidden');
            $("#datas").empty();
            $("#tr").empty();
        });
      })


    $("#viewM").on('click', '.editMachineBtn', function() {
      $('#viewM').addClass('hidden');
            $("#datas").empty();
            $("#tr").empty();
        $('#editMachineId').val($(this).data('id'));
        $('#editLocal').val($(this).data('local'));
        $('#editTransactions').val($(this).data('transactions'));
        $('#editFilters').val($(this).data('filters'));
        $('#editState').val($(this).data('state'));
        $('#editModal').removeClass('hidden');
    });

    // Cerrar modal de edición
    $('#closeEditModal').click(function() {
        $('#editModal').addClass('hidden');
    });

    // Enviar formulario de edición con AJAX
    $('#editMachineForm').submit(function(e) {
        e.preventDefault();
        let id = $('#editMachineId').val();
        $.ajax({
            url: `/machines/${id}`,
            type: 'PUT',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                local: $('#editLocal').val(),
                transactions: $('#editTransactions').val(),
                filters: $('#editFilters').val(),
                state: $('#editState').val()
            },
            success: function(response) {
                alert('Máquina actualizada con éxito');
                loadMachines();
                $("#machine-table").empty();
                $('#editModal').addClass('hidden');
            }
        });
    });

    // Abrir modal de eliminación

    $("#viewM").on('click', '.deleteMachineBtn', function() {
        $('#confirmDeleteBtn').data('id', $(this).data('id'));
        $('#viewM').addClass('hidden');
            $("#datas").empty();
            $("#tr").empty();
        $('#deleteModal').removeClass('hidden');
    });

    // Cerrar modal de eliminación
    $('#closeDeleteModal').click(function() {
        $('#deleteModal').addClass('hidden');
    });

    // Confirmar eliminación con AJAX
    $('#confirmDeleteBtn').click(function() {
        let id = $(this).data('id');
        $.ajax({
            url: `/machines/${id}`,
            type: 'DELETE',
            data: { _token: '<?php echo e(csrf_token()); ?>' },
            success: function(response) {
                $('#deleteModal').addClass('hidden');
                loadMachines();
                $("#machine-table").empty();
                $('#editModal').addClass('hidden');
            }
        });
    });

    loadMachines();*/

</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/machines_admin.blade.php ENDPATH**/ ?>