  <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" crossorigin=""></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
        
  <style>
    /* Define el tama�0�9o del mapa */
    #map {
      width: 750px;
      height: 400px;
      margin: 20px 0;
    }
    
    #mapEdit {
      width: 750px;
      height: 400px;
      margin: 20px 0;
    }
  </style>

<div id="createLocalModal" class="fixed inset-0 hidden bg-gray-800 bg-opacity-50 flex justify-center items-center p-4" style="
    height: 100%;
        margin-top:45px;
">
    <div class="bg-white p-6 rounded-lg shadow-lg " style="
    z-index:1000;
    height: 90%;
    margin-left:15%;
    overflow-y: scroll;">
        <h2 class="text-xl font-bold mb-4 text-center">Crear Nuevo Local</h2>
        <form id="createLocalForm" class="space-y-4">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            
            <div>
                <label class="block text-gray-700">Nombre</label>
                <input type="text" name="nombre" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            
            <div>
                <label class="block text-gray-700">Estado</label>
                <input type="text" name="estado" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>


                <label class="block mb-2 font-semibold text-gray-700">Telefono</label>
                <div class="flex items-center space-x-2">
                  <img id="flag" src="https://flagcdn.com/24x18/us.png"
                       alt="Bandera" class="w-6 h-4 rounded-sm border" />
            
                  <select id="country-code" 
                          class="flex rounded-lg border-gray-300 w-1 shadow-sm focus:ring focus:ring-blue-200 p-2 text-sm" style="width: 10%;">
                  </select>
            
                  <input type="tel" id="phone"
                         placeholder="123 456 789"
                         class="flex-1 rounded-lg border-gray-300 shadow-sm focus:ring focus:ring-blue-200 p-2" />
                </div>

                <input type="hidden" id="full_phone" name="phone" value="" />

              <script>
                const countries = [
                  { code: "AF", dial_code: "+93" },
                  { code: "DE", dial_code: "+49" },
                  { code: "SA", dial_code: "+966" },
                  { code: "AR", dial_code: "+54" },
                  { code: "AU", dial_code: "+61" },
                  { code: "BD", dial_code: "+880" },
                  { code: "BO", dial_code: "+591" },
                  { code: "BR", dial_code: "+55" },
                  { code: "CA", dial_code: "+1" },
                  { code: "CL", dial_code: "+56" },
                  { code: "CN", dial_code: "+86" },
                  { code: "CO", dial_code: "+57" },
                  { code: "KR", dial_code: "+82" },
                  { code: "CR", dial_code: "+506" },
                  { code: "CU", dial_code: "+53" },
                  { code: "DK", dial_code: "+45" },
                  { code: "EC", dial_code: "+593" },
                  { code: "EG", dial_code: "+20" },
                  { code: "SV", dial_code: "+503" },
                  { code: "AE", dial_code: "+971" },
                  { code: "ES", dial_code: "+34" },
                  { code: "US", dial_code: "+1" },
                  { code: "PH", dial_code: "+63" },
                  { code: "FI", dial_code: "+358" },
                  { code: "FR", dial_code: "+33" },
                  { code: "GR", dial_code: "+30" },
                  { code: "GT", dial_code: "+502" },
                  { code: "HT", dial_code: "+509" },
                  { code: "HN", dial_code: "+504" },
                  { code: "IN", dial_code: "+91" },
                  { code: "ID", dial_code: "+62" },
                  { code: "IR", dial_code: "+98" },
                  { code: "IE", dial_code: "+353" },
                  { code: "IL", dial_code: "+972" },
                  { code: "IT", dial_code: "+39" },
                  { code: "JP", dial_code: "+81" },
                  { code: "KE", dial_code: "+254" },
                  { code: "MX", dial_code: "+52" },
                  { code: "MA", dial_code: "+212" },
                  { code: "NI", dial_code: "+505" },
                  { code: "NG", dial_code: "+234" },
                  { code: "NO", dial_code: "+47" },
                  { code: "NZ", dial_code: "+64" },
                  { code: "PK", dial_code: "+92" },
                  { code: "PA", dial_code: "+507" },
                  { code: "PY", dial_code: "+595" },
                  { code: "NL", dial_code: "+31" },
                  { code: "PE", dial_code: "+51" },
                  { code: "PL", dial_code: "+48" },
                  { code: "PT", dial_code: "+351" },
                  { code: "GB", dial_code: "+44" },
                  { code: "DO", dial_code: "+1" },
                  { code: "RU", dial_code: "+7" },
                  { code: "SE", dial_code: "+46" },
                  { code: "CH", dial_code: "+41" },
                  { code: "ZA", dial_code: "+27" },
                  { code: "TH", dial_code: "+66" },
                  { code: "TR", dial_code: "+90" },
                  { code: "UA", dial_code: "+380" },
                  { code: "UY", dial_code: "+598" },
                  { code: "VE", dial_code: "+58" },
                  { code: "VN", dial_code: "+84" }
                ];
            
                  countries.forEach(c => {
                    $('#country-code').append(`
                      <option value="${c.dial_code}" data-flag="${c.code.toLowerCase()}">
                        ${c.dial_code}
                      </option>
                    `);
                  });
            
                  function updateFlag() {
                    const selected = $('#country-code option:selected');
                    const code = selected.data('flag'); 
                    const flagUrl = `https://flagcdn.com/24x18/${code}.png`;
                    $('#flag').attr('src', flagUrl);
                    $('#flag').attr('alt', `Bandera de ${code.toUpperCase()}`);
                  }
            
                  $('#country-code').on('change', updateFlag);
            
                  updateFlag();
              </script>

            <div>
                <label class="block text-gray-700">Estado</label>
                <select name="state" id="localAdd" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                </select>
            </div>
            
                        <div>
                            <div>
                                <label for="city" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                  Pais
                                </label>
                                <select id="city" placeholder="Escoje la ciudad" required name="ciudad"
                                        class="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 shadow-sm focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-500 focus:border-blue-400 dark:focus:border-blue-500 outline-none transition-all duration-300">
                                  <option value="Spain">Spain</option>
                                  <option value="United States">Estados Unidos</option>
                                  <option value="Mexico">M��xico</option>
                                  <option value="Argentina">Argentina</option>
                                  <option value="Colombia">Colombia</option>
                                  <option value="Chile">Chile</option>
                                  <option value="Peru">Per��</option>
                                  <option value="Venezuela">Venezuela</option>
                                  <option value="Ecuador">Ecuador</option>
                                  <option value="Uruguay">Uruguay</option>
                                  <option value="Paraguay">Paraguay</option>
                                  <option value="Bolivia">Bolivia</option>
                                  <option value="Brazil">Brasil</option>
                                  <option value="Cuba">Cuba</option>
                                  <option value="Dominican Republic">Dominican Republic</option>
                                  <option value="Puerto Rico">Puerto Rico</option>
                                  <option value="Costa Rica">Costa�0�2Rica</option>
                                  <option value="Panama">Panam��</option>
                                  <option value="Guatemala">Guatemala</option>
                                  <option value="Honduras">Honduras</option>
                                  <option value="El Salvador">El�0�2Salvador</option>
                                  <option value="Nicaragua">Nicaragua</option>
                                  <option value="Belize">Belice</option>
                                  <option value="Jamaica">Jamaica</option>
                                  <option value="Haiti">Hait��</option>
                                  <option value="Trinidad and Tobago">Trinidad�0�2y�0�2Tobago</option>
                                  <option value="Suriname">Surinam</option>
                                  <option value="Guyana">Guyana</option>
                                  <option value="French Guiana">Guayana�0�2Francesa</option>
                                  <option value="Barbados">Barbados</option>
                                  <option value="St. Lucia">Santa�0�2Luc��a</option>
                                  <option value="St. Vincent and the Grenadines">San�0�2Vicente�0�2y�0�2las�0�2Granadinas</option>
                                  <option value="Grenada">Granada</option>
                                  <option value="Antigua and Barbuda">Antigua�0�2y�0�2Barbuda</option>
                                  <option value="Dominica">Dominica</option>
                                  <option value="Bahamas">Las�0�2Bahamas</option>
                                  <option value="Bermuda">Bermudas</option>
                                  <option value="Brazil - Acre">Brasil�0�2�C�0�2Acre</option>
                                  <option value="Brazil - Campo Grande">Brasil�0�2�C�0�2Campo�0�2Grande</option>
                                  <option value="Brazil - Manaus">Brasil�0�2�C�0�2Manaus</option>
                                  <option value="Brazil - Cuiaba">Brasil�0�2�C�0�2Cuiab��</option>
                                  <option value="Brazil - Fortaleza">Brasil�0�2�C�0�2Fortaleza</option>
                                  <option value="Argentina - Cordoba">Argentina�0�2�C�0�2C��rdoba</option>
                                  <option value="Argentina - Mendoza">Argentina�0�2�C�0�2Mendoza</option>
                                  <option value="Chile - Punta Arenas">Chile�0�2�C�0�2Punta�0�2Arenas</option>
                                  <option value="Mexico - Hermosillo">M��xico�0�2�C�0�2Hermosillo</option>
                                  <option value="Ecuador - Galapagos">Ecuador�0�2�C�0�2Gal��pagos</option>
                                  <option value="Brazil - Belem">Brasil�0�2�C�0�2Bel��m</option>
                                  <option value="Argentina - La Rioja">Argentina�0�2�C�0�2La�0�2Rioja</option>
                                  <option value="Chile - Easter Island">Chile�0�2�C�0�2Isla�0�2de�0�2Pascua</option>
                                </select>                  
                            </div>
                          
                             <div id="map"></div>
                             <input type="hidden" name="lat" id="latedit">
                             <input type="hidden" name="lon" id="lngedit">
                        </div>
            
            
            <div class="flex justify-end space-x-2">
                <button type="button" id="closeCreateModal" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">Cancelar</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Guardar</button>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function () {
    var map, mapx, marker, markerit;

    function initMap() {
        if (!map) {
            map = L.map('map').setView([19.4326, -99.1332], 10);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
              attribution: '�0�8 OpenStreetMap contributors'
            }).addTo(map);
            
            map.on('click', function(e) {
                var lat = e.latlng.lat;
                var lng = e.latlng.lng;
        
                if (marker) {
                    marker.setLatLng(e.latlng);
                } else {
                    marker = L.marker(e.latlng).addTo(map);
                }
                $('#lat').val(lat);
                $('#lng').val(lng);
            });
        }
    }

    function initEditMap() {
        if (!mapx) {
            mapx = L.map('mapEdit').setView([19.4326, -99.1332], 10);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
              attribution: '�0�8 OpenStreetMap contributors'
            }).addTo(mapx);
        }
    }

    function findC(city) {
        var url = "https://nominatim.openstreetmap.org/search?format=json&q=" + encodeURIComponent(city);
        fetch(url)
          .then(response => response.json())
          .then(data => {
              if (data && data.length > 0) {
                  var lat = parseFloat(data[0].lat);
                  var lng = parseFloat(data[0].lon);
                  map.setView([lat, lng], 10);
              }
          })
          .catch(err => console.error("Error al geocodificar la ciudad:", err));
    }
    
    // Funci��n debounce para limitar llamadas a la API
    function debounce(func, delay) {
      let timeout;
      return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), delay);
      };
    }

    initMap();
    initEditMap();

    /*$('#city').on('input', debounce(function() {
        var city = $(this).val().trim();
        if (city !== "") {
            findC(city);
        }
    }, 500));*/


    $(document).on('click', '#openCreateModal', function () {
        $("#createLocalModal").removeClass('hidden');
        setTimeout(function() {
            map.invalidateSize();
        }, 200);
    })
    
    // Delegated event handler para bot��n de editar
    $(document).on('click', '.edit-btn', function () {
        const localId = $(this).data('local-id');
        const nombre = $(this).data('local-nombre');
        const state = $(this).data('local-state');
        const ciudad = $(this).data('local-ciudad');
        const estado = $(this).data('local-estado');
        const lat = $(this).data('local-lat');
        const lon = $(this).data('local-lon');
        const phone = $(this).data('local-phone');

        $('#editModal').removeClass('hidden');
        
        $('#editLocalId').val(localId);
        $('#nombre').val(nombre);
        $('#estado').val(estado);
        $('#state').val(state);
        $('#cityEdit').val(ciudad);
        $('#latedit').val(lat);
        $('#lngedit').val(lon);
        $('#phoneEdit').val(phone);
        if(lat !== ""){
            $("#bgWhite").css('width', '770px');
            $('#mapEdit').removeClass('hidden');
            console.log("--> " + lat);

            mapx.setView([lat, lon], 10);
            
            if (markerit) {
                markerit.setLatLng([lat, lon]);
                markerit.bindPopup(nombre).openPopup();
            } else {
                markerit = L.marker([lat, lon]).addTo(mapx)
                              .bindPopup(nombre)
                              .openPopup();
            }
            
            mapx.off('click'); 
            mapx.on('click', function(e) {
                var lat = e.latlng.lat;
                var lng = e.latlng.lng;
                
                if (markerit) {
                    markerit.setLatLng(e.latlng);
                } else {
                    markerit = L.marker(e.latlng).addTo(mapx);
                }
                $('#latedit').val(lat);
                $('#lngedit').val(lng);
            });
        } else {
            var url = "https://nominatim.openstreetmap.org/search?format=json&q=" + encodeURIComponent(ciudad);
            fetch(url)
              .then(response => response.json())
              .then(data => {
                  if (data && data.length > 0) {
                    var latx = parseFloat(data[0].lat);
                    var lngx = parseFloat(data[0].lon);
                    console.log("latx"+latx)
                    console.log("lngx"+lngx)
                    
                    mapx.setView([latx, lngx], 10);
                    if (markerit) {
                        markerit.setLatLng([latx, lngx]);
                        markerit.bindPopup(nombre).openPopup();
                    } else {
                        markerit = L.marker([latx, lngx]).addTo(mapx)
                                      .bindPopup(nombre)
                                      .openPopup();
                    }
                  }
                  
              })
              .catch(err => console.error("Error al geocodificar la ciudad:", err));
            
        }

        setTimeout(function() {
            mapx.invalidateSize();
        }, 200);
        
    });

    // Delegated event handler para bot��n de eliminar local
    $(document).on('click', '.delete-btn', function () {
        const localId = $(this).data('local-id');
        $('#deleteModal').removeClass('hidden');
        $('#deleteUserId').val(localId);
    });
    
    
    
    $(document).on('click', '#closeCreateModal', function () {
        $("#createLocalModal").addClass('hidden');
    });
    
    $(document).on('click', '.close-modal', function () {
        $('#editModal').addClass('hidden');
        $('#deleteModal').addClass('hidden');
    });

    // Delegated event handler para bot��n de ver transacciones
    $(document).on('click', '.view-transactions-btn', function () {
        var localId = $(this).data('local-id');
        var URLs = `/machines/local/${localId}/`;

        $('#viewTransactionsModal').removeClass('hidden');

        function loadTransactions(M){
            console.log(M[0].id);
            var URLsM = `/transactions/${M[0].id}/`;

            $.ajax({
                url: URLsM,
                method: 'GET',
                success: function (res) {
                    if (res.transaction && res.transaction.length > 0) {
                        $('#transactionsList').html('');

                        let table = `
                            <table class="min-w-full bg-white">
                                <thead>
                                    <tr>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">ID</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">IN Parcial</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">OUT Parcial</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha</th>
                                        <th class="px-4 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                        `;

                        res.transaction.forEach(function (transaction) {
                            table += `
                                <tr>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.id}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_in}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.parcial_out}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.percentage_pay}%</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">${transaction.fecha}</td>
                                    <td class="px-4 py-2 border-b border-gray-200 bg-white text-sm">
                                        <button class="bg-red-500 text-white px-3 py-1 rounded-md delete-transaction-btn" data-transaction-id="${transaction.id}">Eliminar</button>
                                    </td>
                                </tr>
                            `;
                        });

                        table += `
                                </tbody>
                            </table>
                        `;

                        $('#transactionsList').html(table);
                    } else {
                        $('#transactionsList').html('<p class="text-gray-600">No hay transacciones para este usuario.</p>');
                    }
                },
                error: function (xhr) {
                    alert('Error al cargar las m��quinas.');
                }
            });
        }

        $.ajax({
            url: URLs,
            method: 'GET',
            success: function (res) {
                $('#transactionsList').html(res);
                loadTransactions(res);
            },
            error: function (xhr) {
                alert('Error al cargar las m��quinas.');
            }
        });
    });

    // Formulario para crear un local
    $('#createLocalForm').on('submit', function (e) {
        e.preventDefault();
        
        let dialWithPlus = $('#country-code').val();  
        let dialWithoutPlus = dialWithPlus.substring(1); 

        let partialNumber = $('#phone').val(); 

        let fullNumber = dialWithoutPlus + partialNumber; 

        $('#full_phone').val(fullNumber);        
        
        $.ajax({
            url: '/locals', 
            type: 'POST',
            data: $(this).serialize(),
            success: function (resl) {
                $('#createLocalModal').addClass('hidden');
                
                let newRow = `
                    <tr data-local-id="${resl.local.id}">
                        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${resl.local.nombre}</td>
                        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${resl.local.estado}</td>
                        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${resl.local.state}</td>
                        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${resl.local.ciudad}</td>
                        <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm"></td>
                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                            <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md mr-2 edit-btn" 
                                data-local-lon="${resl.local.lon}" 
                                data-local-lat="${resl.local.lat}" 
                                data-local-nombre="${resl.local.nombre}" 
                                data-local-estado="${resl.local.estado}" 
                                data-local-state="${resl.local.state}" 
                                data-local-owner="${resl.local.owner}" 
                                data-local-ciudad="${resl.local.ciudad}" 
                                data-local-phone="${resl.local.phone}" 
                                data-local-company_id="${resl.local.company_id}" 
                                data-local-id="${resl.local.id}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                              </svg>
                            </button>
                            <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md mr-2 delete-btn" data-local-id="${resl.local.id}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                              </svg>
                            </button>
                            <button style="margin-top:3px;" class="bg-green-500 text-white px-3 py-1 rounded-md view-transactions-btn" data-local-id="${resl.local.id}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" />
                              </svg>
                            </button>
                        </td>
                    </tr>
                `;
               
                $('#locals-table').append(newRow);
                // No es necesario volver a asignar listeners, ya que se usan delegated events.
            },
            error: function (xhr) {
                alert('Error al crear el local');
            }
        });
    });

    // Formulario para editar un local
    $('#editLocalForm').on('submit', function (e) {
        e.preventDefault();
        const localId = $('#editLocalId').val();
        
        $.ajax({
            url: `/locals/${localId}`,
            method: 'PUT',
            data: $(this).serialize(),
            success: function (res) {
                $('#editModal').addClass('hidden');

                $(`tr[data-local-id="${localId}"]`).html(`
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${res.local.nombre}</td>
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${res.local.estado}</td>
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${res.local.state}</td>
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">${res.local.ciudad}</td>
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm"></td>
                    <td class="px-2 py-2 border-b border-gray-200 bg-white text-sm">
                        <button style="margin-top:3px;" class="bg-blue-500 text-white px-3 py-1 rounded-md mr-2 edit-btn" 
                            data-local-lon="${res.local.lon}" 
                            data-local-lat="${res.local.lat}" 
                            data-local-nombre="${res.local.nombre}" 
                            data-local-estado="${res.local.estado}" 
                            data-local-state="${res.local.state}" 
                            data-local-owner="${res.local.owner}" 
                            data-local-ciudad="${res.local.ciudad}" 
                            data-local-company_id="${res.local.company_id}" 
                            data-local-phone="${res.local.phone}" 
                            data-local-id="${res.local.id}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                              </svg>
                        </button>
                        <button style="margin-top:3px;" class="bg-red-500 text-white px-3 py-1 rounded-md mr-2 delete-btn" data-local-id="${res.local.id}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                              </svg>
                        </button>
                        <button style="margin-top:3px;" class="bg-green-500 text-white px-3 py-1 rounded-md view-transactions-btn" data-local-id="${res.local.id}">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" />
                              </svg>
                        </button>
                    </td>
                `);
            },
            error: function (xhr) {
                alert('Error al actualizar el local');
            }
        });
    });

    // Formulario para eliminar un local
    $('#deleteUserForm').on('submit', function (e) {
        e.preventDefault();
        const localId2 = $('#deleteUserId').val();

        $.ajax({
            url: `/locals/${localId2}`,
            method: 'DELETE',
            data: $(this).serialize(),
            success: function (response) {
                $('#deleteModal').addClass('hidden');
                $(`tr[data-local-id="${localId2}"]`).remove();
            },
            error: function (xhr) {
                alert('Error al eliminar el local');
            }
        });
    });
    
    // Formulario para eliminar una transacci��n
    $('#deleteTransactionForm').on('submit', function (e) {
        e.preventDefault();
        const transactionId = $('#deleteTransactionId').val();

        $.ajax({
            url: `/transactions/${transactionId}`,
            method: 'DELETE',
            data: $(this).serialize(),
            success: function (response) {
                alert('Transacci��n eliminada correctamente.');
                $('#deleteTransactionModal').addClass('hidden');
            },
            error: function (xhr) {
                alert('Error al eliminar la transacci��n.');
            }
        });
    });
});
</script>
<?php /**PATH /home/evucsheq/iguentertainment.com/resources/views/admin/modals/create_local.blade.php ENDPATH**/ ?>